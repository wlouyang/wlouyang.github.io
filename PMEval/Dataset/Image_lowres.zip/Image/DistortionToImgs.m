% This code changes the input images into blurred/compressed images

%% Specify the parameters
%************Please change basePath to your environment!!!!************
% basePath is where the input images are stored
basePath = 'You have to change me!!';
%************Please change basePath to your environment!!!!************

% 'Noise': Guassian noise; 
% 'Blur': Guassian low pass; 
% 'JPEG': JPEG compression
DistortionType = 'Noise'; 

imType = 'bmp';         % format of input image
imTargetType = 'bin';   % file name extension
% For example, if your input is in "D:\Images\Template matching\data\1280\"
% then the output will be in "D:\Images\Template matching\data\1280\Noise_Data"
% with extesion "*.bin".

%% Used for reading images from the basePath
path = basePath;
f = filesep;
path2 = fullfile(basePath,[db f]);
di = dir(fullfile(path,['I*_0.' imType]));
M = length(di); % number of images

% Decide the directory that stores the distorted images
switch DistortionType
    case 'JPEG'
        db = 'JPEG_Data';      
        im2Type = 'jpg';        % only used for JPEG compression
    case 'Noise'
        db = 'Noise_Data';     
        NoiseTable = [325 650 1300 2600]; % only used for Guassian noise
        NoiseTable = NoiseTable ./(255*255);
    case 'Blur'
        db = 'filter_data';
end;
        
%% Start the job
for i=1:M
    FileName = fullfile(path,di(i).name);
    name2 = [path db f di(i).name(1:end-4) '.' imTargetType];
    ImgFileName2 = name2;
    ImgFileName2(end-2:end) = im2Type;
    iminput = imread(FileName,imType);
    switch DistortionType
% generate image of different compression qualities: 90 70 50 30 10
        case 'JPEG'
            for Q=0:4
                ImgFileName2(end-4) = num2str(Q);
                name2(end-4) = num2str(Q);
                imwrite(iminput, ImgFileName2, im2Type, 'Quality', 90-20*Q);
                im = imread(ImgFileName2);
          %      imshow(im);
                fid = fopen(name2, 'wb');
                fwrite(fid, im', 'uint8');
                fclose(fid);
            end;
%generate image of different gaussian noise:
        case 'Noise'
             for Q=0:4
                ImgFileName2(end-4) = num2str(Q);
                name2(end-4) = num2str(Q);
                if(Q~=0)
                    Noise = NoiseTable(Q);
                    im=imnoise(iminput,'gaussian', 0, Noise);
                else
                    im = iminput;
                end;
                 im = uint8(im);
                fid = fopen(name2, 'wb');
                fwrite(fid, im', 'uint8');
                fclose(fid);
            end;  
% generate image of different blur: sigma1 controls the blur condition
        case 'Blur'
             for Q=0:4
                ImgFileName2(end-4) = num2str(Q);
                name2(end-4) = num2str(Q);
                sigma1=0.2+Q*0.7; %standard deviation of the filter
                filter1 = fspecial('gaussian', 10, sigma1);%Len: 10, std. var: sigma1
                im=conv2(double(iminput),filter1,'same');
                im = uint8(im);
                fid = fopen(name2, 'wb');
                fwrite(fid, im', 'uint8');
                fclose(fid);
            end;  
    end;
end;
