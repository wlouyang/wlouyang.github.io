Matlab files
DistortionToImgs.m: 
The Matlab file used for generating distortion to images

Showimage.m:				
The generated images are ".bin" files, this matlab file can be used to see what images are generated. 
You can try to run this code directly to see the result.


folder: 
160:        160x120 images
320:        320x240 images
640:        640x480 images

You can also put the 1280 and 2560 images downloaded from our web into this folder.