%This code is used for showing the distorted images in .bin files
%% Specify the filename and image size
Filename = 'I1_0.bin'; % the file that you want to see
height = 640; 
width = 480;   

%% read the data and show the image
fid = fopen(Filename, 'rb');
T1_0 = uint8(fread(fid, [height width], 'uint8'));
fclose(fid);
imshow(T1_0');
