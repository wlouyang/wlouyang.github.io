
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "BoxFilter.h"

void SatSum(unsigned char *Image, int ImageWidth, int ImageHeight, int *ResultImage){

int i, j;
int temp;

ResultImage[0] = Image[0];
for(i=1; i<ImageWidth; i++)
	ResultImage[i] = Image[i] + ResultImage[i-1];
	
for(j=1; j<ImageHeight; j++){
	temp = Image[j*ImageWidth];
	ResultImage[j*ImageWidth] = temp + ResultImage[(j-1)*ImageWidth];
	
	for(i=1; i<ImageWidth; i++){
		temp += Image[j*ImageWidth+i];
		ResultImage[j*ImageWidth+i] = temp + ResultImage[(j-1)*ImageWidth+i];
	}
}

}



void BoxFilteringSum(unsigned char *Image, int ImageWidth, int ImageHeight, int TemplateWidth, int TemplateHeight, int *ResultImage){

 int iT, jT, i, j;		
 int prodottoParziale, valorePixel;		
 int indice1, indice2;	
 int DeltaWidth    = ImageWidth - TemplateWidth ;
 int DeltaHeight	  = ImageHeight - TemplateHeight;

 int Q;

 int SCM[2560] = {0};			// const MaxImageWidth = 768;
 int SRN[2560] = {0};			// const MaxImageHeight = 576;
 
 ResultImage[0] = 0;
 for (iT = 0; iT < TemplateHeight; iT++){	
	prodottoParziale = iT * ImageWidth;	
	for (jT = 0; jT < TemplateWidth; jT++){
		valorePixel = (int)(Image[prodottoParziale + jT]);
		SCM[jT] = SCM[jT] + valorePixel;
		SRN[iT] = SRN[iT] + valorePixel;
	}
	ResultImage[0] = ResultImage[0] + SRN[iT];
 }

 for (jT = 1; jT <= (DeltaWidth); jT++){
	indice1 = jT + TemplateWidth - 1;
	for (iT = 0; iT < TemplateHeight; iT++)
		SCM[indice1] = SCM[indice1] + (int)(Image[iT * ImageWidth + indice1]);
	ResultImage[jT] = ResultImage[jT - 1] + SCM[indice1] - SCM[jT - 1];		
 }

 for (i = 1; i <= (DeltaHeight); i++){
	indice2 = i + TemplateHeight - 1; 
	for (jT = 0; jT < TemplateWidth; jT++)
		SRN[indice2] = SRN[indice2] + (int)(Image[indice2 * ImageWidth + jT]);

	ResultImage[i * ImageWidth] = ResultImage[(i - 1) * ImageWidth] + SRN[indice2] - SRN[i - 1];
	Q = SRN [indice2] - SRN [i - 1];

	for (j = 1; j <= DeltaWidth; j++){
		Q = Q + (int)(Image [indice2 * ImageWidth + j + TemplateWidth - 1]) 
			  - (int)(Image [indice2 * ImageWidth + j - 1])
			  - (int)(Image [(i - 1) * ImageWidth + j + TemplateWidth - 1])
			  + (int)(Image [(i - 1) * ImageWidth + j - 1]);
		ResultImage[i * ImageWidth + j] = ResultImage[(i - 1) * ImageWidth + j] + Q;
	}
 }

return;

}

void BoxFilteringSum2(int *ImageSum, int wStart, int hStart, int wEnd, int hEnd, int ImageWidth, int ImageHeight, int TemplateWidth, int TemplateHeight, int *ResultImage){

 int i, j;		
// int prodottoParziale, valorePixel;		
 int DeltaWidth    = ImageWidth - TemplateWidth ;
 int DeltaHeight	  = ImageHeight - TemplateHeight;

// int Q;

 int SCM[2560] = {0};			// const MaxImageWidth = 768;
 int SRN[2560] = {0};			// const MaxImageHeight = 576;
 
 for (i = hStart; i < (wEnd); i++){
	 for (j = wStart; j < hEnd; j++){
				ResultImage[i*ImageWidth+j] = ImageSum[(i+TemplateHeight)*ImageWidth+(TemplateWidth+j)] + 
					ImageSum[i*ImageWidth+j] - 
					ImageSum[(i+TemplateHeight)*ImageWidth+j] 
					- ImageSum[i*ImageWidth+TemplateWidth+j];	
	 }
 }
 return;

}










void BoxFilteringSquareNorm(unsigned char *Image, int ImageWidth, int ImageHeight, int TemplateWidth, int TemplateHeight, float *ResultImageSqrt){

	int* ResultImage;
	
	int iT, jT, i, j;				
						
	int prodottoParziale, valorePixel;		
	int indice1, indice2;			
	int DeltaWidth    = ImageWidth - TemplateWidth ;
	int DeltaHeight	  = ImageHeight - TemplateHeight ;

	 int Q;
	int SCM[2560] = {0};		
	int SRN[2560] = {0};			

 ResultImage = (int *) malloc(ImageWidth * ImageHeight * sizeof(int) );
 ResultImage[0] = 0;

 for (iT = 0; iT < TemplateHeight; iT++){	
	prodottoParziale = iT * ImageWidth;	
	for (jT = 0; jT < TemplateWidth; jT++){
		valorePixel = ((int)(Image[prodottoParziale + jT]*Image[prodottoParziale + jT]));
		SCM[jT] = SCM[jT] + valorePixel;
		SRN[iT] = SRN[iT] + valorePixel;
	}
	
	ResultImage[0] = ResultImage[0] + SRN[iT];
	ResultImageSqrt [0] = (float)(sqrt(1.0 * ResultImage[0]));
 }

 for (jT = 1; jT <= (DeltaWidth); jT++){
	indice1 = jT + TemplateWidth - 1;

	for (iT = 0; iT < TemplateHeight; iT++)
		SCM[indice1] = SCM[indice1] + ((int)(Image[iT * ImageWidth + indice1]*Image[iT * ImageWidth + indice1]));

	ResultImage[jT] = ResultImage[jT - 1] + SCM[indice1] - SCM[jT - 1];
	ResultImageSqrt [jT] = (float)(sqrt(1.0 * ResultImage[jT]));		
 }

 for (i = 1; i <= (DeltaHeight); i++){
	indice2 = i + TemplateHeight - 1; 
	for (jT = 0; jT < TemplateWidth; jT++)
		SRN[indice2] = SRN[indice2] + ((int)(Image[indice2 * ImageWidth + jT]*Image[indice2 * ImageWidth + jT]));

	ResultImage[i * ImageWidth] = ResultImage[(i - 1) * ImageWidth] + SRN[indice2] - SRN[i - 1];
	ResultImageSqrt[i*ImageWidth] = (float)(sqrt(1.0 * ResultImage[i*ImageWidth]));

	Q = SRN [indice2] - SRN [i - 1];

	for (j = 1; j <= DeltaWidth; j++){
		Q = Q + ((int)(Image [indice2 * ImageWidth + j + TemplateWidth - 1]*Image [indice2 * ImageWidth + j + TemplateWidth - 1])) 
			  - ((int)(Image [indice2 * ImageWidth + j - 1]*Image [indice2 * ImageWidth + j - 1]))
			  - ((int)(Image [(i - 1) * ImageWidth + j + TemplateWidth - 1]*Image [(i - 1) * ImageWidth + j + TemplateWidth - 1]))
			  + ((int)(Image [(i - 1) * ImageWidth + j - 1]*Image [(i - 1) * ImageWidth + j - 1]));

		ResultImage[i * ImageWidth + j] = ResultImage[(i - 1) * ImageWidth + j] + Q;
		ResultImageSqrt[i*ImageWidth + j] = (float)(sqrt(1.0 * ResultImage[i*ImageWidth+j]));
	}
 }

free(ResultImage);
 
return;
}

void BoxFilteringSquareNorm2(unsigned char *img, int w, int h, int tw, int th, double *out){


int x,y,i,j;
int acc, row1, row2, pos0;
int *V = (int *)calloc(w, sizeof(int));

int n = tw; //assumption: tw=th
int sqn = n*n;

	//############### PRIMA RIGA #################
	//FASE "0": PRIMA POSIZIONE A SX
	V[0]=0;
	for(j=0; j<n; j++)
		V[0] += img[j*w]*img[j*w];
	acc=V[0];

	for(i=1; i<n; i++)
		for(j=0; j<n; j++)
			acc += img[j*w+i]*img[j*w+i];
	out[0] = (float) (sqrt(1.0*acc));
	pos0 = acc;


	//FASE 1: calcolo colonne da aggiungere/togliere, aggiorno acc 
	for(x=1; x<n; x++){
		V[x+n-1]=0;
		for(j=0; j<n; j++)
			V[x+n-1] += img[j*w+x+n-1]*img[j*w+x+n-1];

		acc = acc + V[x+n-1] - V[x-1];
		out[x] = sqrt(1.0*acc);

		V[x]=0;
		for(j=0; j<n; j++)
			V[x] += img[j*w+x]*img[j*w+x];
	}//x

//FASE 2: calcolo solo colonne da aggiungere (le altre le ho tutte)
for(x=n; x<=w-n; x++){

		V[x+n-1]=0;
		for(j=0; j<n; j++)
			V[x+n-1] += img[j*w+x+n-1]*img[j*w+x+n-1];

		acc = acc + V[x+n-1] - V[x-1];
		out[x] = sqrt(1.0*acc);
	}//x

	//######## TUTTE LE RIGHE oltre alla prima ############

	for(y=1; y<=h-n; y++){

	//FASE "0": PRIMA POSIZIONE A SX
	//qui si pu� ottimizzare il calcolo del primo acc rendendolo incrementale con posizione soprastante
		V[0] = V[0] - img[(y-1)*w]*img[(y-1)*w] + img[(y+n-1)*w]*img[(y+n-1)*w];

		row1 = 0;
		for(i=0; i<n; i++)
			row1 += img[(y-1)*w+i];
		row2 = 0;
		for(i=0; i<n; i++)
			row2 += img[(y+n-1)*w+i];
		acc = pos0 - row1 + row2;
		pos0 = acc;

		out[y*w] = sqrt(1.0*acc);

		//FASE 1: calcolo colonne da aggiungere/togliere, aggiorno acc 
		for(x=1; x<n; x++){
			V[x+n-1] = V[x+n-1] - img[(y-1)*w+x+n-1]*img[(y-1)*w+x+n-1] + img[(y+n-1)*w+x+n-1]*img[(y+n-1)*w+x+n-1];
			acc = acc + V[x+n-1] - V[x-1];
			out[y*w+x] = sqrt(1.0*acc);
			V[x] = V[x] - img[(y-1)*w+x]*img[(y-1)*w+x] + img[(y+n-1)*w+x]*img[(y+n-1)*w+x];
		}//x

		//FASE 2: calcolo solo colonne da aggiungere (le altre le ho tutte)	
		for(x=n; x<=w-n; x++){
			V[x+n-1] = V[x+n-1] - img[(y-1)*w+x+n-1]*img[(y-1)*w+x+n-1] + img[(y+n-1)*w+x+n-1]*img[(y+n-1)*w+x+n-1];
			acc = acc + V[x+n-1] - V[x-1];
			out[y*w+x] = sqrt(1.0*acc);
		}//x
	}//y

	free(V);
}

