/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        gck.h                                                        *
 *                                                                           *
 * description: Functions for performing motion estimation using 2D Gray     *
 *              Code Kernels and the Walsh-Hadamard transform.               *
 *****************************************************************************/

#ifndef _gck_h_
#define _gck_h_

#include "matrix.h"
#include "match.h"

///////////////////////////////// DATA TYPES ////////////////////////////////
typedef signed _int32 basisT;
// A setup for pattern matching. Contains pattern matching required data.
// The resulting motion vectors are updated in the motionVecs field.
typedef struct {
	Matrix **prevImageProj;	  // array of previous image projections
	Image *curImage;		  // current image
	Diff_Image *diffImage;		  // difference image x(i1,i2) - x(i1-k, i2)
	Image *prevImage;		  // previous image
	Matrix *baseVectors;	  // rows of this matrix are the base vectors
	Matrix *baseVectorsOrder; // order of base vectors for performing projections (index in the baseVectors matrix)
	Matrix **curImageProj;	  // array of current image projections
	Matrix **curImageProj2;	  // array of current image projections
	int *IntegralImg;

	// temporary fields
	Matrix *colsProj;			// used in DC calculation
	Matrix *tmpProj;			// used in DC calculation
	Matrix_Dist *distances;			// distances from candidates in search range
	MatchQueue *bestMatches;	// best matches so far
	int32 *ProjPtr;
	int32 Idx[128][128]; //usef for storing order information for snake or IF, maximum is 128 now
	int32 tIdx[128][128]; //usef for storing order information for snake or IF, maximum is 128 now
	coordT Img_Heihgt; // number of rows in the source image
	coordT Img_Width; // number of cols in the source image
	coordT Block_size_img; // number of rows (and cols) in the pattern image
	coordT Block_size_pat; // number of rows (and cols) in the pattern image
	coordT Boundary_Size_Img;
	coordT Boundary_Size_Pat;
	coordT Img_Width_With_Boundary;
	coordT Img_Height_With_Boundary;
	coordT Pat_Width_With_Boundary;
	coordT Pat_Height_With_Boundary;
	coordT ImgProj_Width;
	coordT ImgProj_Height;
	int Bases_Num;	// number of supported WH basis
	int BasesComputed;
	int count;
	int match[MAX_MATCH];
	int xmatch[MAX_MATCH];
	int ymatch[MAX_MATCH];
	int Threshold;
	float Percent; //The percentage where GCK stops and the direct SSD is used
	int LogSize;
	int AlgFlag; //Shows which algorithm is being used
	//Used for Wanli's KHT
	int32 offset;
	int32 StartPos;
	int32 BlkSizeBy2;
	int32 Cols;
	int32 maxCols;
	int32 maxRows;
	//tracking performance
	int NumCand[MAX_BASES];	// Number of candidates at each step
	int NumSteps;		// Number of steps
	double TimeGCK[MAX_BASES];
	double TimeFWHT[MAX_BASES];
} GCKSetup;


/////////////////////// PROTOTYPES OF PUBLIC FUNCTIONS //////////////////////

GCKSetup *createGCKSetup();
void destroyGCKSetup(GCKSetup *setup);
void createWHBases(GCKSetup *setup);
void setImageGCK(GCKSetup *setup, int BaseStart, int BaseEnd, u_int8 *computed);
void setPatternGCK(GCKSetup *setup, Image **image);
void PMGCKSP(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases);
void PMGCKLP(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases);
void PMGCKSP_FWHT(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases);
void PMGCKLP_FWHT(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases);
void PMGCKSAD(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases);
void PMGCKSAD_FWHT(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases);
u_int32 SqrDiff[2*MAX_DIFF+1];
void ComputeOffset(GCKSetup *setup, Matrix *basesVectors);
Matrix *GroupedOrder3(Matrix *result);
Matrix *incFreqVectorsOrder(Matrix *result);
Matrix *snakeVectorsOrder(Matrix *result);
GCKSetup *GCKSetupInit(GCKSetup *result, int AlgChoice, coordT sourceRows, 
						 coordT sourceCols, coordT patternRows, basisT numOfBasis);
void DeleteMemGCKSetup(GCKSetup *setup);


#endif