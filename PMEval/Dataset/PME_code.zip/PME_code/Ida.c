
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "pm.h"
#include "BoxFilter.h"

static float BuffImageSquare[MAX_IMAGE_SIZE];
static int BuffImageSum[MAX_IMAGE_SIZE];
int Ida(information *info){

    unsigned char *Image=info->Image;
    unsigned char *Template=info->Template;
    int ImageWidth=info->ImageWidth;
    int ImageHeight=info->ImageHeight;
    int TemplateWidth=info->TemplateWidth;
    int TemplateHeight=info->TemplateHeight;
          
	int N=info->N;   

	float Bound[MAX_BOUNDS];
	float temp;
	int temp2;

	int count = 0;
	int Mycount = 0;
	int i,k,j;
	int x,y;

#ifdef RETURN_STATS
	int totale_punti=0;
	int punti_scartati_whole = 0;
	int punti_scartati[MAX_BOUNDS]={0};
#endif
	
	int partial_height = TemplateHeight / N;
	float template_square[MAX_BOUNDS];
	float *ImageSquare;
	int SSD=0;			
	float bound_cauchyschwarz;
	int SSD_MIN = info->SsdThreshold; 
#ifdef OBTAIN_BOUND
	int Candj = -1;
#endif
#ifdef RETURN_STATS
//  	printf("Warning: collecting stats...\n");
#endif

	for(i=0; i<N; i++){template_square[i]=0.0;}
#ifdef OBTAIN_BOUND
	for(i=0; i<N; i++){info->Bound[i]=0.0;}
#endif
	
#ifdef ALLC_INLOOP
	ImageSquare = (float *) malloc (ImageWidth * ImageHeight * sizeof (float) );
#else
	ImageSquare = BuffImageSquare;
#endif
	
	BoxFilteringSquareNorm(Image, ImageWidth, ImageHeight, TemplateWidth, partial_height, ImageSquare);
 	
	for(x=0; x<N; x++){
		for(i=(partial_height*x); i<(partial_height*(x+1)); i++)
		for (j=0;j<TemplateWidth;j++) {
			template_square[x] += Template[i * TemplateWidth + j]*Template[i * TemplateWidth + j];
		}
		template_square[x] = (float)(sqrt(template_square[x]));
	}
	
	for (y=0;y<=(ImageHeight-TemplateHeight);y++)
	for (x=0;x<=(ImageWidth-TemplateWidth);x++){
#ifdef RETURN_STATS
		totale_punti++;
#endif
		
		temp=0.0; 
		SSD = 0;

	   for(i=0; i<N; i++){
   			Bound[i]= ImageSquare[(y+(i*partial_height) )*ImageWidth + x] - template_square[i];
			Bound[i] = Bound[i] * Bound[i];
			temp = temp + Bound[i];
	   }
#ifdef OBTAIN_BOUND
	   Candj++;
	   info->Bound[0] += temp/((float)info->FSDist[Candj]);
#endif
		if ( temp >= SSD_MIN){
			#ifdef RETURN_STATS
			punti_scartati[0]++;  // 0 bounds
			#endif			
			goto label_cauchyschwarz;
		}
   
		for(k=0; k<N-1; k++){	
 		
			for(i=(partial_height*k);i<(partial_height * (k+1) );i++){
			for (j=0;j<TemplateWidth;j++){
				temp2 = (int)(Image[(y+i)*ImageWidth+(x+j)] - Template[i*TemplateWidth+j]);
				SSD += temp2*temp2;
			}}
			temp = temp -  Bound[k];
			bound_cauchyschwarz = SSD + temp ; 
#ifdef OBTAIN_BOUND
	   info->Bound[k+1] += bound_cauchyschwarz/((float)info->FSDist[Candj]);
#endif			
			if (bound_cauchyschwarz>=SSD_MIN)  {
				#ifdef RETURN_STATS
				punti_scartati[k+1]++;
				#endif			
				goto label_cauchyschwarz;
			}
		}

  		// #######################################################################
  		// ######### 	Complete SSD computation when IDA fails :-( 	##########
		// #######################################################################

		for(i=(partial_height*(N-1));i<TemplateHeight;i++)
		for (j=0;j<TemplateWidth;j++){
			temp2 = (int)(Image[(y+i)*ImageWidth+(x+j)]-Template[i*TemplateWidth+j]);
			SSD += temp2*temp2;
		}
		Mycount++;
		if (SSD<SSD_MIN ){
			info->match[count] = SSD;
			info->xmatch[count]=y;
			info->ymatch[count]=x;
			count++;
		}
	  label_cauchyschwarz:	 continue;
	}
	
	info->count = count;

#ifdef RETURN_STATS
    // Statistics (if enabled during compilation)
    info->total_points=totale_punti;
	info->NumCand[0] = totale_punti;
//    info->total_points_lowres_hires=0;
//    info->total_points_lowres=0;
    
    for (k=0; k<=N; k++){
		info->skipped_points[k]=punti_scartati[k];
		info->NumCand[k+1] = info->NumCand[k] - punti_scartati[k];
//    info->skipped_points_lowres_hires[k]=0;
//    info->skipped_points_lowres[k]=0;
	}
    for (;k<12-1; k++) info->NumCand[k+1] = 0;
#endif

return 0;
}




int Ida_SAD(information *info){

	unsigned char *Image=info->Image;
	unsigned char *Template=info->Template;
	int ImageWidth=info->ImageWidth;
	int ImageHeight=info->ImageHeight;
	int TemplateWidth=info->TemplateWidth;
	int TemplateHeight=info->TemplateHeight;
          
	int N=info->N;   

	int Bound[MAX_BOUNDS], BOUND;
	int SAD;			
	int bound_cauchyschwarz;
	int SAD_MIN = info->SsdThreshold; 

	int count = 0;
	int i,k,j;
	int x,y;

	int *ImageSum;

#ifdef RETURN_STATS
//	printf("Warning: collecting stats...\n");
	int totale_punti=0;
	int punti_scartati[MAX_BOUNDS]={0};
#endif

	int partial_height = TemplateHeight/N;
	int template_sum[MAX_BOUNDS];
#ifdef RETURN_STATS
//	printf("Warning: collecting stats...\n");
#endif
	for(i=0; i<N; i++){
		template_sum[i]=0;
	}

#ifdef ALLC_INLOOP
	ImageSum = (int *) malloc (ImageWidth * ImageHeight * sizeof (int) );
#else
	ImageSum = (int *) BuffImageSum;
#endif
	BoxFilteringSum(Image, ImageWidth, ImageHeight, TemplateWidth, partial_height, ImageSum);
	
	for(x=0; x<N; x++)
	for(i=(partial_height*x); i<(partial_height*(x+1)); i++)
	for (j=0;j<TemplateWidth;j++) {
		template_sum[x] += (int)(Template[i * TemplateWidth + j]);
	}
	
	for (y=0;y<=(ImageHeight-TemplateHeight);y++)
	for (x=0;x<=(ImageWidth-TemplateWidth);x++){

#ifdef RETURN_STATS
		totale_punti++;
#endif
	
		BOUND=0; 
		SAD=0;
		
		for(i=0; i<N; i++){
   			Bound[i]= abs(ImageSum[(y+(i*partial_height) )*ImageWidth + x] - template_sum[i]);
			BOUND += Bound[i];
		}
	   
		if (BOUND >= SAD_MIN){
			#ifdef RETURN_STATS
			punti_scartati[0]++;  // 0 bounds
			#endif			
			goto label_cauchyschwarz;
		}
	  
  		for(k=0; k<N-1; k++){	

			for(i=(partial_height*k);i<(partial_height * (k+1) );i++){
			for (j=0;j<TemplateWidth;j++){
				SAD += abs(Image[(y+i)*ImageWidth+(x+j)] - Template[i*TemplateWidth+j]);
			}}
				
			BOUND = BOUND -  Bound[k];
			bound_cauchyschwarz = SAD + BOUND ; 
			
			if (bound_cauchyschwarz>=SAD_MIN)  {
				#ifdef RETURN_STATS
				punti_scartati[k+1]++;
				#endif			
				goto label_cauchyschwarz;
			}
		}

		for(i=(partial_height*(N-1));i<TemplateHeight;i++)
		for (j=0;j<TemplateWidth;j++) {
			SAD += abs(Image[(y+i)*ImageWidth+(x+j)]-Template[i*TemplateWidth+j]);
		}

		if (SAD<SAD_MIN ) {
			info->match[count] = SAD;
			info->xmatch[count] = y;
			info->ymatch[count] = x;
//			printf("%d, %d, %d\n", x, y, SAD);
			count++;
		}
		label_cauchyschwarz:	 continue;
	}
//	printf("\n\n\n");
	
#ifdef ALLC_INLOOP
	free(ImageSum);
#endif
	info->count = count;

#ifdef RETURN_STATS
	// Statistics (if enabled during compilation)
	info->total_points=totale_punti;
	info->NumCand[0] = totale_punti;
//	info->total_points_lowres_hires=0;
//	info->total_points_lowres=0;
	  
	for (k=0; k<=N; k++){
		info->skipped_points[k]=punti_scartati[k];
		info->NumCand[k+1] = info->NumCand[k] - punti_scartati[k];
//		info->skipped_points_lowres_hires[k]=0;
//		info->skipped_points_lowres[k]=0;
	}
    for (;k<12-1; k++) info->NumCand[k+1] = 0;
#endif

return 0;
}




