


void SatSum(unsigned char *Image, int ImageWidth, int ImageHeight, int *ResultImage);


void BoxFilteringSum(unsigned char *Image, int ImageWidth, int ImageHeight, int TemplateWidth, int TemplateHeight, int *ResultImage);
void BoxFilteringSum2(int *ImageSum, int wStart, int hStart, int wEnd, int hEnd, int ImageWidth, int ImageHeight, int TemplateWidth, int TemplateHeight, int *ResultImage);

void BoxFilteringSquareNorm(unsigned char *Image, int ImageWidth, int ImageHeight, int TemplateWidth, int TemplateHeight, float *ResultImageSqrt);

void BoxFilteringSquareNorm2(unsigned char *img, int w, int h, int tw, int th, double *out);
