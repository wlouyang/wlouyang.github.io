/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        main.c                                                       *
 *                                                                           *
 * description: main function												 *
 *																			 *
 * version:																	 *
 *	  1.0 - 14/2/06															 *
 *			Fully working and efficient                                      *
 *    1.1 - 14/2/06															 *
 *          Added efficient boundary calculation                             *
 *    1.2 - 9/5/06															 *
 *			Added Full-Search and Diamond-Search as a reference              *
 *    1.3 - 19/5/06															 *
 *			Added increasing frequency order as the default projection order *
 *    1.31 - 16/2/07														 *
 *			Fixed a bug related to the boundary calculation                  *
 *    1.4 - 1/6/07															 *
 *			Added logging of output motion vectors to a file                 *
 *			Fixed a bug where motion vectors were saved in inverted          *
 *          direction                                                        *
 *																			 *
 *****************************************************************************/

// For this program to run quickly, the following compiler options should be set
// (Visual Studio .NET 2005):
//	 Debug Information Format: Disabled
//	 Optimization: Maximum Speed (/O2)
//	 Inline Function Exstension: Any Suitable (/Ob2)

#include <math.h>
#include <string.h>
#include <stdio.h>
#include <io.h>
#include "defs.h"
#include "fs.h"
#include "gck.h"
#include "wh.h"


#include "./openCV/cv.h"
#include "./openCV/cxcore.h"
//#include "./openCV/highgui.h"
int Obtain_SAD(unsigned char *Image, unsigned char *Template, int x, int y, int TemplateHeight, int TemplateWidth, int ImageWidth);
int Obtain_SSD(unsigned char *Image, unsigned char *Template, int x, int y, int TemplateHeight, int TemplateWidth, int ImageWidth);

/******************************************************************************
 * Read one video frame from a YUV file.                                      *
 ******************************************************************************/
int readYUV(u_int8 *luma, u_int8 *chroma, u_int32 frameSize, FILE *fp) {
	
	if (fread(luma, sizeof(u_int8), frameSize, fp) != frameSize)
		return -1;

	if (fread(chroma, sizeof(u_int8), frameSize/2, fp) != (u_int16)(frameSize/2))
		return -1;

	return 0;
}

__inline int readImg3(u_int8 *luma, u_int32 frameSize, FILE *fp) {
	if (fread(luma, sizeof(u_int8), frameSize, fp) != frameSize)
		return -1;
	return 0;
}

/******************************************************************************
 * Main function - execution starts here.                                     *
 ******************************************************************************/
void ConstructSqrTable()
{ 
	int i;
	u_int16 tmp;
	for (i = 0; i<2*MAX_DIFF+1; i++)
	{
		tmp = absDiff[i];
		SqrDiff[i] = tmp * tmp;
	}
}

void SetCandMtxZero(t_Candidates *pCand, int Choice, int NumSteps)
{
	memset(pCand->fNumCand, 0, NumSteps*sizeof(float));
	pCand->NumSteps = NumSteps;
}

void InitCandMtx(t_Candidates *pCand, int NumChoice, int MaxSteps)
{
	int i;
	for (i=0; i<NumChoice; i++)
	{
		pCand->NumSteps = 0;
		memset(pCand->fNumCand, 0, MaxSteps*sizeof(float));
		pCand++;
	}
}

extern int32 BasesInOneCol[128];
extern int32 BasesInOneRow[128];

#if (NORM_MEASURE==CHOICE_SSD)

int BasesMtx[6][7]=
{{0, 0, 0,  0, 0, 0, 0},
{ MAX_BASES, MAX_BASES, MAX_BASES, MAX_BASES, MAX_BASES,0, 0}, //Bases for S1
{ MAX_BASES, MAX_BASES,MAX_BASES,MAX_BASES, MAX_BASES,0, 0}, //Bases for S2
{ MAX_BASES, MAX_BASES,MAX_BASES,MAX_BASES, MAX_BASES,0, 0}, //Bases for S3
{ MAX_BASES,MAX_BASES,MAX_BASES,MAX_BASES, MAX_BASES,0, 0},  //Bases for S4
{ MAX_BASES,MAX_BASES,MAX_BASES,MAX_BASES, MAX_BASES,0, 0}  //Bases for S4
};
//float PercentMtx[4] = {(float)0.001, (float)0.001, (float)0.001, (float)0.001};
float PercentMtx[4] = {(float)DEFAULT_DISTANCE_PERCENT_BY_100, (float)DEFAULT_DISTANCE_PERCENT_BY_100, (float)DEFAULT_DISTANCE_PERCENT_BY_100, (float)DEFAULT_DISTANCE_PERCENT_BY_100};

#endif
#if (NORM_MEASURE==CHOICE_SAD)
int BasesMtx[5][7]=
{{0, 0, 0,  0, 0, 0, 0},
{ MAX_BASES, MAX_BASES, MAX_BASES, MAX_BASES, MAX_BASES,0, 0}, //Bases for S1
{ MAX_BASES, MAX_BASES,MAX_BASES,MAX_BASES, MAX_BASES,0, 0}, //Bases for S2
{ MAX_BASES, MAX_BASES,MAX_BASES,MAX_BASES, MAX_BASES,0, 0}, //Bases for S3
{ MAX_BASES,MAX_BASES,MAX_BASES,MAX_BASES, MAX_BASES,0, 0}  //Bases for S4
};
float PercentMtx[4] = {(float)DEFAULT_DISTANCE_PERCENT_BY_100, (float)DEFAULT_DISTANCE_PERCENT_BY_100, (float)DEFAULT_DISTANCE_PERCENT_BY_100, (float)DEFAULT_DISTANCE_PERCENT_BY_100};
#endif
IDARMtx[4] = {4, 4, 8, 8};


#define OP_TIMES 10000
int A[OP_TIMES];
int B[OP_TIMES];
int C[OP_TIMES];
int D[OP_TIMES];
int E[OP_TIMES];
int F[OP_TIMES];

float TestAddVSMulRatio()
{
#ifdef WIN32
	struct _timeb tstruct1;
	struct _timeb tstruct2;
#else
	struct timeb tstruct1;
	struct timeb tstruct2;
#endif
	time_t ltime1;
	time_t ltime2;
	int i, j;
	int Mult_time;
	int Add_time;
	float ratio;

   srand( (unsigned)time( NULL ) );

   /* Display 10 numbers. */
   for( i = 0;   i < OP_TIMES;i++ )
   {
      A[i]= rand()&255;
      B[i]= rand()&255;
      D[i]= rand()&255;
      E[i]= rand()&255;
	}
//Time for multiplication
   _ftime (&tstruct1);       
   time (&ltime1);           

   for (j=0; j<OP_TIMES; j++)
   for( i = 0;   i < OP_TIMES;i++ )
   {
      C[i]= A[i]*B[i];
   }

   time (&ltime2);   
   _ftime (&tstruct2);
  Mult_time = (ltime2 * 1000 + tstruct2.millitm) - (ltime1 * 1000 + tstruct1.millitm);

//Time for Addition
   _ftime (&tstruct1);       
   time (&ltime1);           

   for (j=0; j<OP_TIMES; j++)
   for( i = 0;   i < OP_TIMES;i++ )
   {
      F[i]= D[i]+E[i];
   }
   time (&ltime2);   
   _ftime (&tstruct2);
  Add_time = (ltime2 * 1000 + tstruct2.millitm) - (ltime1 * 1000 + tstruct1.millitm);

  printf("Add Time: %d, Mul Time: %d.", Add_time, Mult_time);
  ratio = (float) Mult_time;
  ratio = ratio/Add_time;
  return ratio;
}

void PatternWH2GCK(WHSetup *whsetup, GCKSetup *gcksetup)
{
	int i;
	for (i=0; i<whsetup->numOfBasis; i++)
	{
		PatternWHTCoef[i] = whsetup->patternProjections[i];
	}
}

extern int  tot_time;
void Obtain_Coordinates(int ImgSizeIdx, char *COORD_FILE_NAME);
coordT Coordinates[30][10][2];
	information info; 
	information info1;

int main(void) {

	u_int8 *frameLuma = (u_int8 *)malloc(MAX_IMG_HEIGHT * MAX_IMG_WIDTH * sizeof (u_int8));
	u_int8 **PatLuma;
	Image **pPattern;
	Image *pImage;
	int loop;
	GCKSetup *gckSetup = NULL;
	GCKSetup *gckWSetup = NULL;
	GCKSetup *gckHSetup = NULL;
	WHSetup *whSetup = NULL;
	int SizeNum[6] = {0, 1, 2, 3, 4, 4};
	t_Candidates CandMtx[10];
	char Pat_filename[80];
	char Img_filename[80];
	char Cod_filename[80];
	char *(AlgoDescriptor[10]);
	char *(NoiseTypeDescriptor[10]);
	int curBaseNum;
	int ImageNumIdx, PatNumIdx;
	int NoiseIdx, ImgSizeIdx, TemplateSizeIdx;
	int AlgChoice;
	int NoiseTypeIdx, NoiseTypeStart, NoiseTypeEnd;
		char *PAT_FILE_NAME, *IMG_FILE_NAME;

	#ifndef PROFILING_MODE
		int ch;
		double seconds;	
	#endif

	#ifdef LOGGING_MODE

		char log_filename[80];
		FILE *log_file;
		char width[5];
		char height[5];
		char frames[5];
		char q[3];
		char m[3];
		motionVec mv;
		
	#endif


	// initializations
	FILE *video_file;
	FILE *pattern_file;

#ifdef WIN32
	struct _timeb tstruct1;
	struct _timeb tstruct2;
#else
	struct timeb tstruct1;
	struct timeb tstruct2;
#endif
	int tmp_time;
	time_t ltime1;
	time_t ltime2;
	int  tot_time2=0;
	float totTime[12];
	float totTimeSqr[12];
	float TotalBases[12];
#ifdef OBTAIN_BOUND
	double StepCount[12][MAX_BASES];
	double Bound[12][MAX_BASES];
#endif
	IplImage *img, *templ,*ftmp; //ftmp is what to display on
	const char* opencv_libraries = 0;
	const char* addon_modules    = 0;
	int ipp_is_used;
	int IMG_WIDTH, IMG_HEIGHT, PAT_WIDTH, PAT_HEIGHT, BLOCK_SIZE_PAT;
	double Dbgtmp1;

  FILE *stream;
  FILE *stream2;
  FILE *streamBound;
  FILE *stream_LPRCan;
  FILE *stream_IDACan;
  FILE *stream_PGCKCan;
  FILE *stream_PWHTCan;
  FILE *stream_FWHTCan;
  FILE *stream_PGCKBas;
  FILE *stream_FWHTBas;
  FILE *stream_WHT_LRP_time;

  AlgoDescriptor[CHOICE_LRP_PM_SLD] =  "LRP_SLD";
  AlgoDescriptor[CHOICE_LRP_PM_SAT] =  "LRP_CAN";
  AlgoDescriptor[CHOICE_LRP_PM_HIER] = "LRP_HIE";
  AlgoDescriptor[CHOICE_FEDER_IDA] =   "IDA_FED";
  AlgoDescriptor[CHOICE_HELOR_PWHT] =  "PK__HEL";
  AlgoDescriptor[CHOICE_HELOR_GCK] =   "GCK_HEL";
  AlgoDescriptor[CHOICE_WANLI_FWHT] =  "FWHT_WA";
  AlgoDescriptor[CHOICE_EXHAUSTIV] =   "Exhaust";
  AlgoDescriptor[CHOICE_OPENCV_FFT] =  "FFT_OCV";

  NoiseTypeDescriptor[0] = "NOISES";
  NoiseTypeDescriptor[1] = "FILTER";
  NoiseTypeDescriptor[2] = "JPEGEN";
	
  stream = fopen(LOG_FILE_NAME, "w" );
  stream2 = fopen(LOG_FILE_NAME2, "w" );
  streamBound = fopen(LOG_FILE_NAME_BOUND, "w" );

  stream_LPRCan = fopen(LOG_FILE_NAME_LRP_CAN, "w" );
  stream_IDACan = fopen(LOG_FILE_NAME_IDA_CAN, "w" );
  stream_PGCKCan = fopen(LOG_FILE_NAME_PGCK_CAN, "w" );
  stream_FWHTCan = fopen(LOG_FILE_NAME_FWHT_CAN, "w" );
  stream_PWHTCan = fopen(LOG_FILE_NAME_PWHT_CAN, "w" );
  stream_PGCKBas = fopen(LOG_FILE_NAME_PGCK_BASENUM, "w" );
  stream_FWHTBas = fopen(LOG_FILE_NAME_FWHT_BASENUM, "w" );
  stream_WHT_LRP_time = fopen(LOG_FILE_NAME_WHT_LRP_TIME, "w" );

  //Try to tell the ratio of the time used by power operation compared with addtion.
  printf("POWER_VS_ADDS: %f", TestAddVSMulRatio());

	for (AlgChoice = CHOICE_START; AlgChoice<CHOICE_NUM+CHOICE_START; AlgChoice++)
	{
		totTime[AlgChoice] = 0;
		totTimeSqr[AlgChoice] = 0;
		TotalBases[AlgChoice] = 0;
	}

	PatLuma = (u_int8 **)malloc(PAT_NUM * sizeof (u_int8*));
	pPattern = (Image**) malloc(PAT_NUM * sizeof (Image *));
	ConstructSqrTable();
	PatLuma[0]   = (u_int8 *)malloc(MAX_IMG_HEIGHT * MAX_IMG_WIDTH * sizeof (u_int8));

	pImage = createImage(frameLuma, MAX_IMG_HEIGHT, MAX_IMG_WIDTH);
	pPattern[0] = createImage(PatLuma[0], MAX_IMG_HEIGHT, MAX_IMG_WIDTH);
	InitCandMtx(CandMtx, CHOICE_NUM+CHOICE_START, MAX_BASES+2);

//OpenCV setup, do not use assembly language because it is unfair for other algorithms that are not optimized
	cvUseOptimized(0);
	cvGetModuleInfo(0, &opencv_libraries, &addon_modules);
	ipp_is_used = addon_modules!=0 && strstr(addon_modules, "ipp")!=0;
	printf(" ipp_is_used: %d\n", ipp_is_used);
	/*printf("\n[INFO] OpenCV: %s\n       Add-on Modules: %s  ipp_is_used: %d\n",
	opencv_libraries, addon_modules, ipp_is_used);*/

#ifdef RETURN_STATS
	printf("Warning: collecting stats for IDA, LRP...\n");
#endif

	loop = 1;
#ifdef ALL_NOISE_TYPE
// Test on all noise types
	NoiseTypeStart=0;
	NoiseTypeEnd=3;
#else
// Test just one noise type
	NoiseTypeStart=IMAGE_SET_CHOICE;
	NoiseTypeEnd=NoiseTypeStart+1;
#endif
	ImgSizeIdx = SIZE_START+SIZE_NUM-1;
	TemplateSizeIdx = SizeNum[ImgSizeIdx]-1;
	IMG_HEIGHT = 120 << (ImgSizeIdx-1);
	IMG_WIDTH = 160 << (ImgSizeIdx-1);
	BLOCK_SIZE_PAT = 16<<TemplateSizeIdx;

	{// This code is used for allocating the large memory to gckSetup
		int Block_size_img = BLOCK_SIZE_PAT*SCALE;
		int Max_offset = Block_size_img>>1;
		int Boundary_Size_Img = BLOCK_SIZE_PAT+Max_offset;
		int Img_Width_With_Boundary = IMG_WIDTH + Boundary_Size_Img;
		int Img_Height_With_Boundary= IMG_HEIGHT+ Boundary_Size_Img;
		int ImgProj_Width =Img_Width_With_Boundary-BLOCK_SIZE_PAT+1;
		int ImgProj_Height =Img_Height_With_Boundary-BLOCK_SIZE_PAT+1;
		int mysize = ImgProj_Height * ImgProj_Width * (MEM_BASES) * sizeof(int32);
		gckSetup = (GCKSetup *)malloc(sizeof(GCKSetup));
		GCKSetupInit(gckSetup, CHOICE_WANLI_FWHT, IMG_HEIGHT, IMG_WIDTH, BLOCK_SIZE_PAT, MAX_BASES);
	}
	// For every noise type, including Gaussian, blur and JPEG
	for (NoiseTypeIdx = NoiseTypeStart; NoiseTypeIdx<NoiseTypeEnd; NoiseTypeIdx++)
	{
		printf("FileType: %s \n",NoiseTypeDescriptor[NoiseTypeIdx]);
//		fprintf(stream, "FileType: %s \n",NoiseTypeDescriptor[NoiseTypeIdx]);

	// For every dataset
		for (ImgSizeIdx = SIZE_START; ImgSizeIdx < SIZE_START+SIZE_NUM; ImgSizeIdx++)
#ifdef ALL_TEMPLATE_SIZES
		for (TemplateSizeIdx = 0; TemplateSizeIdx < SizeNum[ImgSizeIdx]; TemplateSizeIdx++)
#endif
		{		
		char *COORD_FILE_NAME;
		char PAT_FILE_NAME2[100], IMG_FILE_NAME2[100];
		char COORD_FILE_NAME2[100];
		int IDA_R, LRP_N, LARGE_PATTERN;
		float	PERCENT_GCK;
		void (*PMGCK)(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases);  
		void (*PMGCKNew)(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases);  
#ifndef ALL_TEMPLATE_SIZES
		TemplateSizeIdx = ImgSizeIdx - 1;
		if (ImgSizeIdx==5)
			TemplateSizeIdx--;
#endif

		if (NoiseTypeIdx == IMAGE_NOISE)
			IMG_FILE_NAME  = "/Noise_Data/%d/I%d_%d.bin";
		else if (NoiseTypeIdx == IMAGE_JPEG)
			IMG_FILE_NAME  = "/JPEG_Data/%d/I%d_%d.bin";
		else if (NoiseTypeIdx == IMAGE_FILTER)
			IMG_FILE_NAME  = "/filter_data/%d/I%d_%d.bin";
		PAT_WIDTH  = 16<<TemplateSizeIdx;				// number of columns in the pattern image
		PAT_HEIGHT = 16<<TemplateSizeIdx;				// number of rows in the pattern image
		BLOCK_SIZE_PAT = 16<<TemplateSizeIdx;
		LRP_N = 4+TemplateSizeIdx;

		//PMGCK and PMGCKNew will choose xxSP or xxLP depending on the size of the image.
		//When the size is too large, we have to use floating point instead of type "int" for representing the transformed results
		//Identyfy the size of image
		switch (ImgSizeIdx)
		{
		case S1:
			IMG_WIDTH  = 160;				// number of columns in the source image
			IMG_HEIGHT = 120;				// number of rows in the source image
			PAT_FILE_NAME  = "/template/160/T_%d/t%d_%d.bin";
			COORD_FILE_NAME  = "/template/160/T_%d/pattern-coordinates.txt";
			PMGCK = PMGCKSP;
			PMGCKNew = PMGCKSP_FWHT;
			break;
		case S2:
			IMG_WIDTH = 320;	
			IMG_HEIGHT = 240;
			PAT_FILE_NAME = "/template/320/T_%d/t%d_%d.bin";
			COORD_FILE_NAME  = "/template/320/T_%d/pattern-coordinates.txt";
			PMGCK = PMGCKSP;
			PMGCKNew = PMGCKSP_FWHT;
			break;
		case S3:
			IMG_WIDTH = 640;
			IMG_HEIGHT = 480;
			PAT_FILE_NAME = "/template/640/T_%d/t%d_%d.bin";
			COORD_FILE_NAME  = "/template/640/T_%d/pattern-coordinates.txt";
			LARGE_PATTERN = 1;
			PMGCK = PMGCKLP;
			PMGCKNew = PMGCKLP_FWHT;
			break;
		case S4:
			IMG_WIDTH = 1280;
			IMG_HEIGHT = 960;
			PAT_FILE_NAME = "/template/1280/T_%d/t%d_%d.bin";
			COORD_FILE_NAME  = "/template/1280/T_%d/pattern-coordinates.txt";
			LARGE_PATTERN = 1;
			PMGCK = PMGCKLP;
			PMGCKNew = PMGCKLP_FWHT;
			break;
		case S5:
			IMG_WIDTH = 2560;
			IMG_HEIGHT = 1920;
			PAT_FILE_NAME = "/template/2560/T_%d/t%d_%d.bin";
			COORD_FILE_NAME  = "/template/2560/T_%d/pattern-coordinates.txt";
			LARGE_PATTERN = 1;
			PMGCK = PMGCKLP;
			PMGCKNew = PMGCKLP_FWHT;
			break;
		default:
			printf("This size is not supported yet!!!\n");
		}


		strcpy(COORD_FILE_NAME2, BASE_PATH);
		COORD_FILE_NAME = strcat(COORD_FILE_NAME2, COORD_FILE_NAME);
		sprintf( Cod_filename,    COORD_FILE_NAME, BLOCK_SIZE_PAT);
		Obtain_Coordinates(ImgSizeIdx, Cod_filename);

		strcpy(PAT_FILE_NAME2, BASE_PATH);
		strcpy(IMG_FILE_NAME2, BASE_PATH);
		PAT_FILE_NAME = strcat(PAT_FILE_NAME2, PAT_FILE_NAME);
		IMG_FILE_NAME = strcat(IMG_FILE_NAME2, IMG_FILE_NAME);
		PERCENT_GCK = PercentMtx[TemplateSizeIdx];
		IDA_R = IDARMtx[TemplateSizeIdx];
		gckSetup = createGCKSetup(gckSetup, CHOICE_WANLI_FWHT, IMG_HEIGHT, IMG_WIDTH, BLOCK_SIZE_PAT, MAX_BASES);
		gckSetup->Percent = PERCENT_GCK;
		gckSetup->LogSize = LRP_N;

		if ((CHOICE_START<=CHOICE_HELOR_PWHT) && (CHOICE_NUM+CHOICE_START >CHOICE_HELOR_PWHT))
		{
			whSetup = createWHSetup(IMG_HEIGHT, IMG_WIDTH, BLOCK_SIZE_PAT, MAX_BASES);
			whSetup->patternImage = NULL;
			whSetup->sourceImage = NULL;
		}


		fprintf(stream,"Image Size %d Template Size: %d\n", 160<<(ImgSizeIdx-1), 16<<TemplateSizeIdx);
		fprintf(stream2,"Image Size %d Template Size: %d\n", 160<<(ImgSizeIdx-1), 16<<TemplateSizeIdx);
		printf("Image Size %d Template Size: %d\n", 160<<(ImgSizeIdx-1), 16<<TemplateSizeIdx);

		templ = cvCreateImage( cvSize(BLOCK_SIZE_PAT,BLOCK_SIZE_PAT),IPL_DEPTH_8U,1);
		img = cvCreateImage( cvSize(IMG_WIDTH,IMG_HEIGHT),IPL_DEPTH_8U,1);
		ftmp = cvCreateImage( cvSize(IMG_WIDTH - BLOCK_SIZE_PAT + 1, IMG_HEIGHT - BLOCK_SIZE_PAT + 1),32,1);

		for (NoiseIdx = NOISE_START; NoiseIdx < NOISE_NUM+NOISE_START; NoiseIdx++)
		{
			int BASES_NUM;
			
			BASES_NUM = (int) (BasesMtx[ImgSizeIdx][NoiseIdx]);
			printf("Noise %d:\n", NoiseIdx);
			for (AlgChoice = CHOICE_START; AlgChoice<CHOICE_NUM+CHOICE_START; AlgChoice++)
				if ( (AlgChoice == CHOICE_LRP_PM_SLD) || (AlgChoice == CHOICE_LRP_PM_SAT) 
				|| (AlgChoice == CHOICE_FEDER_IDA) || (AlgChoice == CHOICE_HELOR_PWHT) 
				|| (AlgChoice == CHOICE_HELOR_GCK) || (AlgChoice == CHOICE_WANLI_FWHT) )
			{
				int NumSteps;
				switch (AlgChoice)
				{
				case CHOICE_LRP_PM_SLD:
					NumSteps = LRP_N;
					break;
				case CHOICE_LRP_PM_SAT:
					NumSteps = LRP_N;	
					break;
				case CHOICE_FEDER_IDA:
					NumSteps = IDA_R;
					break;
				case CHOICE_HELOR_PWHT:
					NumSteps = BASES_NUM;
					break;
				case CHOICE_HELOR_GCK:
					NumSteps = BASES_NUM;
					break;
				case CHOICE_WANLI_FWHT:
					NumSteps = BASES_NUM;
				}
				NumSteps+=1;
				SetCandMtxZero(CandMtx+AlgChoice, AlgChoice, MAX_BASES+2);
#ifdef OBTAIN_BOUND
				for (AlgChoice = CHOICE_START; AlgChoice<CHOICE_NUM+CHOICE_START; AlgChoice++)
				{
					memset(StepCount[AlgChoice], 0, sizeof(double)*MAX_BASES);
					memset(Bound[AlgChoice], 0, sizeof(double)*MAX_BASES);
				}
#endif
			}
			memset(gckSetup->TimeFWHT, 0, sizeof(double)*MAX_BASES);
			memset(gckSetup->TimeGCK, 0, sizeof(double)*MAX_BASES);
			memset(info.TimeLRPSLD, 0, sizeof(double)*MAX_BASES);
			memset(whSetup->Time, 0, sizeof(double)*MAX_BASES);
			memset(whSetup->NumCand, 0, sizeof(double)*MAX_BASES);


#ifdef PRINT_IMAGE_NUN
				printf( "processing image:    ");
#endif
			for (ImageNumIdx = 0; ImageNumIdx < IMG_NUM; ImageNumIdx++) 
			{
#ifdef PRINT_IMAGE_NUN
				printf( "\b\b\b %2d", ImageNumIdx);
#endif
			for (PatNumIdx = 0; PatNumIdx < PAT_NUM; PatNumIdx++) 
			{
				int SSD;
				int MMD, THRESHOLD;
				double THRESHOLD_d, MMD_d;
				sprintf( Pat_filename,    PAT_FILE_NAME, BLOCK_SIZE_PAT, ImageNumIdx+1, PatNumIdx );
				reallocImage2(pPattern[0], PatLuma[0], PAT_HEIGHT, PAT_WIDTH);
				if ((pattern_file = fopen(Pat_filename, "rb")) == NULL)	
					exitWithError("Error while opening pattern file.");
				if (readImg3(PatLuma[0], PAT_HEIGHT * PAT_WIDTH, pattern_file))
					exitWithError("Error while reading from pattern file.");
#ifdef PRINT_IMAGE_NUN
//				printf( "%2d\n", PatNumIdx);
#endif

				// read frame
				sprintf( Img_filename,  IMG_FILE_NAME, IMG_WIDTH, ImageNumIdx+1, NoiseIdx);
				if ((video_file = fopen(Img_filename, "rb")) == NULL)
					exitWithError("Error while opening image file1.\n");
				if (readImg3(frameLuma, IMG_HEIGHT * IMG_WIDTH, video_file))
					exitWithError("Error while reading from image file.\n");
				reallocImage2(pImage, frameLuma, IMG_HEIGHT, IMG_WIDTH);
				fclose(video_file);
				fclose(pattern_file);
//				printf( "processing image %d Pat %d\n", ImageNumIdx, PatNumIdx);
//				printf( "processing image %s Pat %s\n", Img_filename, Pat_filename);

#ifdef ADAPTIVE_THRESHOLD
#if (NORM_MEASURE==CHOICE_SSD)
				SSD = Obtain_SSD(frameLuma, PatLuma[0], 
					Coordinates[ImageNumIdx][PatNumIdx][0], Coordinates[ImageNumIdx][PatNumIdx][1], 
					PAT_HEIGHT, PAT_WIDTH, IMG_WIDTH);
				THRESHOLD_d = SSD*1.1 + BLOCK_SIZE_PAT*BLOCK_SIZE_PAT;
				MMD_d  = sqrt(THRESHOLD_d)/BLOCK_SIZE_PAT;
				MMD = (int) ceil(MMD_d);

				// Restrict the MMD, should not be too large
				if ( (BLOCK_SIZE_PAT >16) && (MMD >63) )
				{
//					printf("\nOriginal MMD is: %d  %f\n", MMD, MMD_d);
					MMD = 63; // Control the SSD not to be too large to be meaningless
				}
				else if ( ( BLOCK_SIZE_PAT == 16) && (MMD >127) )
				{
//					printf("\nOriginal MMD is: %d  %f\n", MMD, MMD_d);
					MMD = 127; // Control the SSD not to be too large to be meaningless
				}
				THRESHOLD=(BLOCK_SIZE_PAT*BLOCK_SIZE_PAT*MMD*MMD);
#endif
#if (NORM_MEASURE==CHOICE_SAD)
				SSD = Obtain_SAD(frameLuma, PatLuma[0], 
					Coordinates[ImageNumIdx][PatNumIdx][0], Coordinates[ImageNumIdx][PatNumIdx][1], 
					PAT_HEIGHT, PAT_WIDTH, IMG_WIDTH);
				THRESHOLD_d = SSD*1.1;
				MMD_d  = THRESHOLD_d/(BLOCK_SIZE_PAT*BLOCK_SIZE_PAT);
				MMD = (int) ceil(MMD_d)+1;
				if ( (BLOCK_SIZE_PAT >16) && (MMD >63) )
				{
//					printf("\nOriginal MMD is: %d  %f\n", MMD, MMD_d);
					MMD = 63; // Control the SSD not to be too large to be meaningless
				}
				else if ( ( BLOCK_SIZE_PAT == 16) && (MMD >127) )
				{
//					printf("\nOriginal MMD is: %d  %f\n", MMD, MMD_d);
					MMD = 127; // Control the SSD not to be too large to be meaningless
				}
				THRESHOLD=(BLOCK_SIZE_PAT*BLOCK_SIZE_PAT*MMD);
#endif
#endif
				
				for (AlgChoice = CHOICE_START; AlgChoice<CHOICE_NUM+CHOICE_START; AlgChoice++)
				{
					int i;
					if ( (NoiseIdx != NOISE_START) && (CHOICE_EXHAUSTIV == AlgChoice) )
						continue;
					if ( ( CHOICE_EXHAUSTIV == AlgChoice ) && (NoiseTypeIdx != IMAGE_NOISE) )
						continue;
#ifdef SKIP_FS
					if ( ( CHOICE_EXHAUSTIV == AlgChoice )) 
						continue;
#endif
//					printf("AlgChoice: %s\n", AlgoDescriptor[AlgChoice]);
					START_COUNT_TIME;
					switch (AlgChoice)
					{
					case CHOICE_EXHAUSTIV:
						info.Image = frameLuma;  //unsigned char array with the image pixels
						info.ImageWidth = IMG_WIDTH; //image width
						info.ImageHeight = IMG_HEIGHT; //image height
						info.Template = PatLuma[0]; //unsigned char array with the template pixels
						info.TemplateWidth = PAT_WIDTH;	//template width
						info.TemplateHeight = PAT_HEIGHT; //template height

						//SETTING THE THRESHOLD
						info.SsdThreshold = THRESHOLD;
#if (NORM_MEASURE==CHOICE_SSD)
						SsdTh(&info);
#endif
#if (NORM_MEASURE==CHOICE_SAD)
						SadTh(&info);
#endif
						break;
					case CHOICE_LRP_PM_SLD:
						info.Image = frameLuma;  //unsigned char array with the image pixels
						info.ImageWidth = IMG_WIDTH; //image width
						info.ImageHeight = IMG_HEIGHT; //image height
						info.Template = PatLuma[0]; //unsigned char array with the template pixels
						info.TemplateWidth = PAT_WIDTH;	//template width
						info.TemplateHeight = PAT_HEIGHT; //template height

						//SETTING THE THRESHOLD
						info.SsdThreshold = THRESHOLD;
						info.N = LRP_N;//Parameter of the IDA algorithm
#if (NORM_MEASURE==CHOICE_SSD)
						SsdLrpBF(&info);
#endif
#if (NORM_MEASURE==CHOICE_SAD)
						SadLrpBF(&info);
#endif
						break;
					case CHOICE_LRP_PM_SAT:
						info.Image = frameLuma;  //unsigned char array with the image pixels
						info.ImageWidth = IMG_WIDTH; //image width
						info.ImageHeight = IMG_HEIGHT; //image height
						info.Template = PatLuma[0]; //unsigned char array with the template pixels
						info.TemplateWidth = PAT_WIDTH;	//template width
						info.TemplateHeight = PAT_HEIGHT; //template height

						//SETTING THE SSD THRESHOLD
						info.SsdThreshold = THRESHOLD;
						info.N = LRP_N;//Parameter of the IDA algorithm
#if (NORM_MEASURE==CHOICE_SSD)
						SsdLrpSAT(&info);
#endif
#if (NORM_MEASURE==CHOICE_SAD)
						SadLrpSAT(&info);
#endif
						break;
					case CHOICE_LRP_PM_HIER:
						info.Image = frameLuma;  //unsigned char array with the image pixels
						info.ImageWidth = IMG_WIDTH; //image width
						info.ImageHeight = IMG_HEIGHT; //image height
						info.Template = PatLuma[0]; //unsigned char array with the template pixels
						info.TemplateWidth = PAT_WIDTH;	//template width
						info.TemplateHeight = PAT_HEIGHT; //template height

						//SETTING THE SSD THRESHOLD
						info.SsdThreshold = THRESHOLD;
						info.N = LRP_N;//Parameter of the IDA algorithm
#if (NORM_MEASURE==CHOICE_SSD)
						SsdLrpHierarchical(&info);
#endif
#if (NORM_MEASURE==CHOICE_SAD)
						SadLrpHierarchical(&info);
#endif
						break;					
					case CHOICE_FEDER_IDA:
						info.Image = frameLuma;  //unsigned char array with the image pixels
						info.ImageWidth = IMG_WIDTH; //image width
						info.ImageHeight = IMG_HEIGHT; //image height
						info.Template = PatLuma[0]; //unsigned char array with the template pixels
						info.TemplateWidth = PAT_WIDTH;	//template width
						info.TemplateHeight = PAT_HEIGHT; //template height

						//SETTING THE SSD THRESHOLD
						info.SsdThreshold = THRESHOLD;
						info.N = IDA_R;//Parameter of the IDA algorithm
#if (NORM_MEASURE==CHOICE_SSD)
						Ida(&info);
#endif
#if (NORM_MEASURE==CHOICE_SAD)
						Ida_SAD(&info);
#endif
						break;
					case CHOICE_HELOR_PWHT:
						setSourceImage(whSetup, pImage);
						setPatternImage(whSetup, pPattern[0]);
						whSetup->numOfBasis = BASES_NUM;
						// In this case, use default setting of PWHT provided by Hel-Or
						whSetup->startDistancePercent = PERCENT_GCK*100;
						whSetup->startBottomUpPercent = PERCENT_GCK*5*100;
#if (NORM_MEASURE==CHOICE_SSD)
						whPatternMatch(whSetup, (float) MMD);	
#endif
#if ( (SAD_CHECK_PKS==1) && (NORM_MEASURE==CHOICE_SAD) )
						whPatternMatchSAD(whSetup, MMD);
#endif
						break;
					case CHOICE_HELOR_GCK:
						gckSetup->Threshold = MMD;
						gckSetup->Bases_Num = BASES_NUM;
						//Note: For the sake of memory requirement, we chose snakeVectorsOrder. 
						//incFreqVectorsOrder can also be chosen if macro "MEMSAVE_WHT" is not defined
#ifdef MEMSAVE_WHT
						gckSetup->baseVectorsOrder = snakeVectorsOrder(gckSetup->baseVectorsOrder);
#else
						gckSetup->baseVectorsOrder = incFreqVectorsOrder(gckSetup->baseVectorsOrder);
#endif
						gckSetup->AlgFlag = CHOICE_HELOR_GCK;
						setPatternGCK(gckSetup, pPattern);
						curBaseNum = BASES_NUM;
#if (NORM_MEASURE==CHOICE_SSD)
						PMGCK(gckSetup, ImageNumIdx, PatNumIdx, pImage, BASES_NUM);
#endif
#if ( (SAD_CHECK_PKS==1) && (NORM_MEASURE==CHOICE_SAD) )
//						PMGCKLP(gckSetup, ImageNumIdx, PatNumIdx, pImage, BASES_NUM);
						PMGCKSAD(gckSetup, ImageNumIdx, PatNumIdx, pImage, curBaseNum);
#endif
						break;
					case CHOICE_WANLI_FWHT:
//						gckSetup = gckWSetup;
						gckSetup->Bases_Num = BASES_NUM;
						gckSetup->Threshold = MMD;
						gckSetup->baseVectorsOrder = GroupedOrder3(gckSetup->baseVectorsOrder);
						setPatternGCK(gckSetup, pPattern);
						gckSetup->AlgFlag = CHOICE_WANLI_FWHT;
						curBaseNum = BASES_NUM;
#if (NORM_MEASURE==CHOICE_SSD)
						PMGCKNew(gckSetup, ImageNumIdx, PatNumIdx, pImage, curBaseNum);
#endif
#if ( (SAD_CHECK_PKS==1) && (NORM_MEASURE==CHOICE_SAD) )
//						PMGCKLP_FWHT(gckSetup, ImageNumIdx, PatNumIdx, pImage, curBaseNum);
						PMGCKSAD_FWHT(gckSetup, ImageNumIdx, PatNumIdx, pImage, curBaseNum);
#endif
						break;						
					case CHOICE_OPENCV_FFT:
						img->imageData = frameLuma;
						templ->imageData = PatLuma[0];
						info.SsdThreshold = THRESHOLD;
#if (NORM_MEASURE==CHOICE_SSD)
						cvMatchTemplate( img, templ, ftmp, &info, CV_TM_SQDIFF); //CV_TM_SQDIFF_NORMED  CV_TM_SQDIFF
#endif
						break;
					default:
						printf("This algroithm choice is not supported yet!\n");
					}
					END_COUNT_TIME;
					tot_time2 += tmp_time;
					totTime[AlgChoice] += tmp_time;
					totTimeSqr[AlgChoice] += ( ((float)tmp_time) * tmp_time);

// Compare the output to see if it is incorrect, can be used for debugging
					if (AlgChoice == CHOICE_START)
					{
						if ( (AlgChoice == CHOICE_HELOR_GCK) || (AlgChoice == CHOICE_WANLI_FWHT) )
						{
							for (i = 0; i < gckSetup->count; i++)
							{
								info1.xmatch[ i ]  = gckSetup->xmatch[ i ];
								info1.ymatch[ i ]  = gckSetup->ymatch[ i ];
								info1.match[ i ]   = gckSetup->match[ i ];
							}
							info1.count = gckSetup->count;
							for (i=0; i<CandMtx[AlgChoice].NumSteps; i++)
								CandMtx[AlgChoice].fNumCand[i] += gckSetup->NumCand[i];

#ifdef OBTAIN_BOUND
							for (i=0; i<CandMtx[AlgChoice].NumSteps; i++)
							{
								StepCount[AlgChoice][i] += gckSetup->NumCand[i];
								Bound[AlgChoice][i] += gckSetup->Bound[i];
							}
#endif
						}
						else if (AlgChoice != CHOICE_HELOR_PWHT)
						{
							for (i = 0; i < info.count; i++)
							{
								info1.xmatch[ i ]  = info.xmatch[ i ];
								info1.ymatch[ i ]  = info.ymatch[ i ];
								info1.match[ i ]   = info.match[ i ];
							}
							info1.count = info.count;
							for (i=0; i<12; i++)
								CandMtx[AlgChoice].fNumCand[i] += info.NumCand[i];
#ifdef OBTAIN_BOUND
							for (i=0; i<CandMtx[AlgChoice].NumSteps; i++)
							{
								StepCount[AlgChoice][i] += info.NumCand[i];
								Bound[AlgChoice][i] += info.Bound[i];
							}
#endif
						}
						else
						{
							for (i=0; i<CandMtx[AlgChoice].NumSteps; i++)
								CandMtx[AlgChoice].fNumCand[i] += (float) whSetup->NumCand[i];
						}
						if (info1.count == 0)
							printf("\n zero found for Image %d Pat %d\n", ImageNumIdx, PatNumIdx);
/*						fprintf(stream, "%d found\n", info1.count);
						if (info1.count < 15)
						{
							int i;
							for (i = 0; i < info1.count; i++)
								fprintf(stream, "Pos x: %d, y: %d  dist: %d\n", info1.xmatch[ i ], info1.ymatch[ i ], info1.match[ i ]);
						}
*/					}
					else
					{
#if ( (NORM_MEASURE==CHOICE_SSD) || ( (SAD_CHECK_PKS==1) && (NORM_MEASURE==CHOICE_SAD) ) )
						if ( (AlgChoice == CHOICE_HELOR_GCK) || (AlgChoice == CHOICE_WANLI_FWHT) )
						{

							if (info1.count != gckSetup->count)
									printf("count different for choice %d, Ori: %d Now: %d Pat: %d, Img: %d\n", AlgChoice, info1.count, gckSetup->count, PatNumIdx, ImageNumIdx);
							else
							for (i = 0; i < gckSetup->count; i++)
							{
								double DistDiff, DistDiffabs;
								if (info1.xmatch[ i ]  != gckSetup->xmatch[ i ])
									printf("xpos is different for choice %d\n", AlgChoice);
								if (info1.ymatch[ i ]  != gckSetup->ymatch[ i ])
									printf("ypos is different for choice %d\n", AlgChoice);
								DistDiff = (double)info1.match[ i ] - gckSetup->match[ i ];
								DistDiffabs = fabs(DistDiff);
								if ( DistDiff > 1)								
									printf("Distance is different for choice %d, %d, %d\n", AlgChoice, info1.match[ i ], gckSetup->match[ i ]);								
							}
							for (i=0; i<CandMtx[AlgChoice].NumSteps; i++)
								CandMtx[AlgChoice].fNumCand[i] += gckSetup->NumCand[i];
#ifdef OBTAIN_BOUND
							for (i=0; i<CandMtx[AlgChoice].NumSteps; i++)
							{
								StepCount[AlgChoice][i] += gckSetup->NumCand[i];
								Bound[AlgChoice][i] += gckSetup->Bound[i];
							}
#endif
						}
						else
						if (AlgChoice == CHOICE_HELOR_PWHT)
						{
							Match *match;
							int count;
							count = numOfMatches(whSetup);
							match = matches(whSetup);
							if (info1.count != count)
									printf("count different for choice %d, Ori: %d Now: %d Pat: %d, Img: %d\n", AlgChoice, info1.count, count, PatNumIdx, ImageNumIdx);
							for (i = 0; i < count; i++)
							{
								if (info1.xmatch[ i ]  != (int) matchY(match))
									printf("xpos is different for choice %d\n", AlgChoice);
								if (info1.ymatch[ i ]  != (int) matchX(match))
									printf("ypos is different for choice %d\n", AlgChoice);
								// We did not compare the SSD/SAD for PWHT because the float type used by PWHT for computing SSD will 
								// have some accuracy problem though the result is right
/*								if ( fabs(info1.match[ i ] - matchDistance(match)) > 1)
								#if (NORM_MEASURE==CHOICE_SAD)
									printf("i: %d, Distance is different for choice %d, %d, %f\n", i, AlgChoice, info1.match[ i ], matchDistance(match));
								#else
									printf("i: %d, Distance is different for choice %d, %d, %f\n", i, AlgChoice, info1.match[ i ], matchDistance(match));
								#endif*/
								match++;
							}
							for (i=0; i<CandMtx[AlgChoice].NumSteps; i++)
								CandMtx[AlgChoice].fNumCand[i] +=  (float) whSetup->NumCand[i];
						}
						else
#endif
						{
							if (info1.count != info.count)
									printf("count different for choice %d, Ori: %d Now: %d Pat: %d, Img: %d\n", AlgChoice, info1.count, info.count, PatNumIdx, ImageNumIdx);
							else
							for (i = 0; i < info.count; i++)
							{
								if (info1.xmatch[ i ]  != info.xmatch[ i ])
									printf("xpos is different for choice %d\n", AlgChoice);
								if (info1.ymatch[ i ]  != info.ymatch[ i ])
									printf("ypos is different for choice %d\n", AlgChoice);
								if (AlgChoice != CHOICE_OPENCV_FFT)
									if ( fabs(info1.match[ i ] - info.match[ i ]) > 1)
										printf("Distance is different for choice %d, %d, %d\n", AlgChoice, info1.match[ i ], info.match[ i ]);
							}
							for (i=0; i<12; i++)
								CandMtx[AlgChoice].fNumCand[i] += info.NumCand[i];
#ifdef OBTAIN_BOUND
							for (i=0; i<12; i++)
							{
								StepCount[AlgChoice][i] += info.NumCand[i];
								Bound[AlgChoice][i] += info.Bound[i];
							}
#endif
						}
					}
#if ( (NORM_MEASURE==CHOICE_SSD) || ( (SAD_CHECK_PKS==1) && (NORM_MEASURE==CHOICE_SAD) ) )
					if ( (AlgChoice == CHOICE_HELOR_GCK) || (AlgChoice == CHOICE_WANLI_FWHT) )
						TotalBases[AlgChoice] += gckSetup->BasesComputed;
					if (AlgChoice == CHOICE_HELOR_PWHT)
						TotalBases[AlgChoice] += whSetup->BasesComputed;
#endif


					//Show stats
/*					if ( (AlgChoice == CHOICE_HELOR_GCK) || (AlgChoice == CHOICE_WANLI_FWHT) )
					{
						fprintf(stream, "%d found using %d projections: \n", gckSetup->count, gckSetup->BasesComputed);
						if (gckSetup->count < 15)
						{
							int i;
							for (i = 0; i < gckSetup->count; i++)
								fprintf(stream, "Pos x: %d, y: %d  dist: %d\n", gckSetup->xmatch[ i ], gckSetup->ymatch[ i ], gckSetup->match[ i ]);
						}
					}
					else
					{
						fprintf(stream, "%d found\n", info.count);
						if (info.count < 15)
						{
							int i;
							for (i = 0; i < info.count; i++)
								fprintf(stream, "Pos x: %d, y: %d  dist: %d\n", info.xmatch[ i ], info.ymatch[ i ], info.match[ i ]);
						}
					}
*/
					
				} //for choices of algorithms
			}} //for patterns and images (datasets
#ifdef PRINT_IMAGE_NUN
			printf( "\n");
#endif
			// Print out and write to file some log information used for analysis
			fprintf(stream2, "Noise Level: %d\n",NoiseIdx);
			fprintf(stream, "Noise Level: %d\n",NoiseIdx);
			for (AlgChoice = CHOICE_START; AlgChoice<CHOICE_NUM+CHOICE_START; AlgChoice++)
			{
				float Mean, Var, SqrMean;
				Mean = (float) (totTime[AlgChoice]*0.001/PAT_NUM/IMG_NUM) ;
				SqrMean = (float) (totTimeSqr[AlgChoice]*0.001*0.001/PAT_NUM/IMG_NUM);
				Var = (float) fabs(SqrMean - Mean*Mean);				
				fprintf(stream, "%d %s Time: %.4f \t Std_Var: %.6f\n",AlgChoice, AlgoDescriptor[AlgChoice], totTime[AlgChoice]*0.001,  sqrt(Var));
#ifdef SHOW_TIME
				printf("%d %s Time: %.5f \t Std_Var: %.6f\n",AlgChoice, AlgoDescriptor[AlgChoice], totTime[AlgChoice]*0.001,  sqrt(Var));				
#endif
			}

#ifdef OBTAIN_BOUND
			for (AlgChoice = CHOICE_START; AlgChoice<CHOICE_NUM+CHOICE_START; AlgChoice++)
			{
				int i;
				fprintf(streamBound, "%d %s \n", AlgChoice, AlgoDescriptor[AlgChoice]);
				for (i=0; i<MAX_BASES; i++)
				{
					if (StepCount[AlgChoice][i]>0)
						fprintf(streamBound,"%f \t", Bound[AlgChoice][i]/StepCount[AlgChoice][i]);
					else
						i = MAX_BASES;
				}
				fprintf(streamBound,"\n");
			}

#endif
			// Log2.txt, recording time, basses
			for (AlgChoice = CHOICE_START; AlgChoice<CHOICE_NUM+CHOICE_START; AlgChoice++)
			{
				float Mean, Var, SqrMean;
				int i;
				Mean = (float) (totTime[AlgChoice]*0.001/PAT_NUM/IMG_NUM);
				SqrMean = (float) (totTimeSqr[AlgChoice]*0.001*0.001/PAT_NUM/IMG_NUM);
				Var = SqrMean - Mean*Mean;
//				fprintf(stream2,"%d %s Avg.Time: %.3f \tAvg.bases: \t%.3f\t in %d\n",AlgChoice, AlgoDescriptor[AlgChoice], Mean,  (TotalBases[AlgChoice]) / (IMG_NUM*PAT_NUM), BASES_NUM);

				if (AlgChoice==CHOICE_HELOR_GCK)
					fprintf(stream_PGCKBas,"%d %s Avg.bases: \t%.3f\t in %d\n",AlgChoice, AlgoDescriptor[AlgChoice],  (TotalBases[AlgChoice]) / (IMG_NUM*PAT_NUM), BASES_NUM);
				if (AlgChoice==CHOICE_WANLI_FWHT)
					fprintf(stream_FWHTBas,"%d %s Avg.bases: \t%.3f\t in %d\n",AlgChoice, AlgoDescriptor[AlgChoice],  (TotalBases[AlgChoice]) / (IMG_NUM*PAT_NUM), BASES_NUM);
				
				if ( (AlgChoice == CHOICE_LRP_PM_SLD) || (AlgChoice == CHOICE_LRP_PM_SAT) 
					    || (AlgChoice == CHOICE_FEDER_IDA) || (AlgChoice == CHOICE_HELOR_PWHT) 
						|| (AlgChoice == CHOICE_HELOR_GCK) || (AlgChoice == CHOICE_WANLI_FWHT) )
				{
					fprintf(stream2,"%s \t", AlgoDescriptor[AlgChoice]);						
					for (i=1; i<CandMtx[AlgChoice].NumSteps; i++)
					{
						
						Dbgtmp1 = CandMtx[AlgChoice].fNumCand[i]/(IMG_NUM*PAT_NUM);
						if (AlgChoice==CHOICE_HELOR_PWHT)
							fprintf(stream2,"%d \t", (int) (whSetup->NumCand[i]/(IMG_NUM*PAT_NUM)));						
						else
							fprintf(stream2,"%d \t", (int) (CandMtx[AlgChoice].fNumCand[i]/(IMG_NUM*PAT_NUM)));
						if (AlgChoice==CHOICE_FEDER_IDA)
							fprintf(stream_IDACan,"%d \t", (int) (CandMtx[AlgChoice].fNumCand[i]/(IMG_NUM*PAT_NUM)));
						if (AlgChoice==CHOICE_LRP_PM_SAT)
							fprintf(stream_LPRCan,"%d \t", (int) (CandMtx[AlgChoice].fNumCand[i]/(IMG_NUM*PAT_NUM)));
						if (AlgChoice==CHOICE_HELOR_GCK)
							fprintf(stream_PGCKCan,"%d \t", (int) (CandMtx[AlgChoice].fNumCand[i]/(IMG_NUM*PAT_NUM)));
						if (AlgChoice==CHOICE_WANLI_FWHT)
							fprintf(stream_FWHTCan,"%d \t", (int) (CandMtx[AlgChoice].fNumCand[i]/(IMG_NUM*PAT_NUM)));
						if (AlgChoice==CHOICE_HELOR_PWHT)
							fprintf(stream_PWHTCan,"%d \t", (int) (whSetup->NumCand[i]/(IMG_NUM*PAT_NUM)));
					}
					for (i=CandMtx[AlgChoice].NumSteps; i<MAX_BASES+2; i++)
					{
						fprintf(stream2,"%d \t", (int) (CandMtx[AlgChoice].fNumCand[i]/(IMG_NUM*PAT_NUM)));
						if (AlgChoice==CHOICE_FEDER_IDA)
							fprintf(stream_IDACan,"%d \t", (int) 0);
						if (AlgChoice==CHOICE_LRP_PM_SAT)
							fprintf(stream_LPRCan,"%d \t", (int) 0);
						if (AlgChoice==CHOICE_HELOR_GCK)
							fprintf(stream_PGCKCan,"%d \t", (int) 0);
						if (AlgChoice==CHOICE_WANLI_FWHT)
							fprintf(stream_FWHTCan,"%d \t", (int) 0);
						if (AlgChoice==CHOICE_WANLI_FWHT)
							fprintf(stream_FWHTCan,"%d \t", (int) (CandMtx[AlgChoice].fNumCand[i]/(IMG_NUM*PAT_NUM)));
					}
					fprintf(stream2,"\n");
						if (AlgChoice==CHOICE_FEDER_IDA)
							fprintf(stream_IDACan,"\n");
						if (AlgChoice==CHOICE_LRP_PM_SAT)
							fprintf(stream_LPRCan,"\n");
						if (AlgChoice==CHOICE_HELOR_GCK)
							fprintf(stream_PGCKCan,"\n");
						if (AlgChoice==CHOICE_WANLI_FWHT)
							fprintf(stream_FWHTCan,"\n");
				}
			}
			for (AlgChoice = CHOICE_START; AlgChoice<CHOICE_NUM+CHOICE_START; AlgChoice++)
			{
				totTime[AlgChoice] = 0;
				totTimeSqr[AlgChoice] = 0;
				TotalBases[AlgChoice] = 0;
			}
			
		} //for noise levels
		cvReleaseImage(&templ);
		cvReleaseImage(&img);
		cvReleaseImage(&ftmp);
			if (whSetup != NULL) 
			{
				destroyWHSetup(whSetup);
				whSetup = NULL;
			}
			if (gckSetup != NULL) 
				DeleteMemGCKSetup(gckSetup);

	}//for sizes
	}//for Noise typs

	//Check if openCV ipp is used	
	if (gckSetup != NULL) 
	{
		destroyGCKSetup(gckSetup);
		free(gckSetup);
		gckSetup = NULL;
	}
	cvGetModuleInfo(0, &opencv_libraries, &addon_modules);
	ipp_is_used = addon_modules!=0 && strstr(addon_modules, "ipp")!=0;
	printf(" ipp_is_used: %d\n", ipp_is_used);


	fprintf(stream," Total time: %.3f \t Average: %.2f \n",tot_time2*0.001/loop, tot_time2*0.001/loop/IMG_NUM);
	
	// clean up
	destroyImage(pPattern[0]);
	destroyImage(pImage);
	free(PatLuma);
	fclose(stream);
	fclose(stream2);
	
	fclose(stream_LPRCan);
	fclose(stream_IDACan);
	fclose(stream_PGCKCan);
	fclose(stream_PWHTCan);
	fclose(stream_FWHTCan);
	fclose(stream_PGCKBas);
	fclose(stream_FWHTBas);
	fclose(streamBound);
	fclose(stream_WHT_LRP_time);


	#ifndef PROFILING_MODE
	
		seconds = (double)clock() / CLOCKS_PER_SEC;
		printf("\nElapsed Time: %5.2f seconds.\n", seconds);
		ch = getchar();
	
	#endif
}

void Obtain_Coordinates(int ImgSizeIdx, char *COORD_FILE_NAME)
{
	FILE *Coord_file;
	int ImageNumIdx, PatNumIdx;

	if ((Coord_file = fopen(COORD_FILE_NAME, "r")) == NULL)
		exitWithError("Error while opening coordinate file.\n");
	for (ImageNumIdx = 0; ImageNumIdx < 30; ImageNumIdx++) 
	{
		char s[50];
		fscanf( Coord_file, "%s\n", s );
		for (PatNumIdx = 0; PatNumIdx < 10; PatNumIdx++) 
		{
			int x, y;
			fscanf( Coord_file, "%d %d\n", &x, &y);
			Coordinates[ImageNumIdx][PatNumIdx][0] = x;
			Coordinates[ImageNumIdx][PatNumIdx][1] = y;
		}
	}
}

int Obtain_SSD(unsigned char *Image, unsigned char *Template, int x, int y, int TemplateHeight, int TemplateWidth, int ImageWidth)
{
	int temp, SSD;
	int i, j;
	SSD = 0;
	for (i=0;i<TemplateHeight;i++){
		for (j=0;j<TemplateWidth;j++){
			temp = Image[(y+i)*ImageWidth+(x+j)] - Template[i*TemplateWidth+j];
			SSD = SSD + (temp*temp);
		}
	}
	return SSD;
}

int Obtain_SAD(unsigned char *Image, unsigned char *Template, int x, int y, int TemplateHeight, int TemplateWidth, int ImageWidth)
{
	int temp, SSD;
	int i, j;
	SSD = 0;
	for (i=0;i<TemplateHeight;i++){
		for (j=0;j<TemplateWidth;j++){
			temp = Image[(y+i)*ImageWidth+(x+j)] - Template[i*TemplateWidth+j];
			SSD = SSD + abs(temp);
		}
	}
	return SSD;
}

/*
A code showing how to use OpenCV FFT for pattern matching
#include <cv.h>
#include <cxcore.h>
#include <highgui.h>
#include <stdio.h>
//from http://blog.weisu.org/2008/10/opencv-match-template-cvmatchtemplate.html
int main( int argc, char** argv ) 
{
    IplImage *src, *templ,*ftmp[6]; //ftmp is what to display on
    int i;
  
    //Read in the template to be used for matching:
    if((templ=cvLoadImage("template.jpg", 1))== 0) {
            printf("Error on reading template %s\n","temp"); 
            return(-1);
    }

    //Read in the source image to be searched:
    if((src=cvLoadImage("source.jpg", 1))== 0) {
            printf("Error on reading src image %s\n","source"); 
            return(-1);
    }

    int patchx = templ->width;
    int patchy = templ->height;
    int iwidth = src->width - patchx + 1;
    int iheight = src->height - patchy + 1;
    for(i=0; i<6; ++i){
        ftmp[i] = cvCreateImage( cvSize(iwidth,iheight),32,1);
    }

    //DO THE MATCHING OF THE TEMPLATE WITH THE IMAGE
    for(i=0; i<6; ++i){
        cvMatchTemplate( src, templ, ftmp[i], i); 
        cvNormalize(ftmp[i],ftmp[i],1,0,CV_MINMAX);
    }
    //DISPLAY
    cvNamedWindow( "Template", 0 );
    cvShowImage(   "Template", templ );
    cvNamedWindow( "Image", 0 );
    cvShowImage(   "Image", src );

    cvNamedWindow( "SQDIFF", 0 );
    cvShowImage(   "SQDIFF", ftmp[0] );
    cvNamedWindow( "SQDIFF_NORMED", 0 );
    cvShowImage(   "SQDIFF_NORMED", ftmp[1] );
    cvNamedWindow( "CCORR", 0 );
    cvShowImage(   "CCORR", ftmp[2] );

    cvNamedWindow( "CCORR_NORMED", 0 );
    cvShowImage(   "CCORR_NORMED", ftmp[3] );

    cvNamedWindow( "CCOEFF", 0 );
    cvShowImage(   "CCOEFF", ftmp[4] );

    cvNamedWindow( "CCOEFF_NORMED", 0 );
    cvShowImage(   "CCOEFF_NORMED", ftmp[5] );
    cvWaitKey(0);
}
*/
