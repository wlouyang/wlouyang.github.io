/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        gck.h                                                        *
 *                                                                           *
 * description: Functions for performing motion estimation using 2D Gray     *
 *              Code Kernels and the Walsh-Hadamard transform.               *
 *****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <limits.h>
#include "defs.h"
#include "gck.h"

#include <sys/types.h>
#include <sys/timeb.h>

///////////////////////////////// CONSTANTS /////////////////////////////////
#pragma inline_recursion(on)
#pragma inline_depth(10)
/*
#ifdef MAX_PATTERN_32
	#pragma inline_depth(10)
#else
	#ifdef MAX_PATTERN_64
		#pragma inline_depth(12)
	#else
		#pragma inline_depth(14)
	#endif
#endif
*/
static int32 GroupProjOrder[16*16][3];
static u_int8 MtxOffset[128];
static u_int8 MtxOffsetTmp[128];
static int32 MtxSign[128];

static const int32 FWHTPos[28] = {
	0,  1,  2,  3,  4,  5,  6,  7, 8, 
	0,  1,  2,  3,  4,  5,  6,
	0,  1,  2,  3,  4,  5,  6,
	0,  1,  2,  3,  4};


static const int32 GroupProjOrderBasis3[16][3] = {
//	y, x, prev
	0, 0, 0, // 0
	1, 0, 0, // 1
	2, 0, 1, // 2
	3, 0, 2, // 3
	0, 1, 0, // 4
	1, 1, 1, // 5
	2, 1, 5, // 6
	3, 1, 6, // 7
	0, 2, 4, // 8
	1, 2, 8, // 9
	2, 2, 9, // 10
	3, 2, 10, // 11
	0, 3, 8, // 12
	1, 3, 12, //13
	2, 3, 13, //14
	3, 3, 14, //15
};

// Order of increasing frequency for GCK projections. First two columns are the
// coordinats of the projection in the WHT domain. Third column is the index
// of the previous projection. This array is only suitable for blocks with
// dimensions <= 16*16.
static const int32 incFreqProjOrder[16*16][3] = {
	0,0,0,	//0
	1,0,0,	//1
	0,1,0,	//2
	1,1,2,	//3
	2,0,1,	//4
	0,2,2,	//5
	2,1,3,  //6
	1,2,5,  //7
	3,0,4,  //8
	2,2,7,  //9
	0,3,5,  //10
	3,1,6,  //11
	1,3,10,	//12
	3,2,9,	//13
	2,3,12,	//14
	4,0,8,	//15
	0,4,10,	//16
	4,1,11,	//17
	1,4,16,	//18
	3,3,14,	//19
	4,2,13,	//20
	2,4,18,	//21
	5,0,15,	//22
	0,5,16,	//23
	5,1,17,	//24
	4,3,19,	//25
	3,4,21,	//26
	1,5,23,	//27
	5,2,20,	//28
	2,5,27,	//29
	4,4,25,
	6,0,22,
	5,3,25,
	3,5,26,
	0,6,23,
	6,1,24,
	1,6,27,
	6,2,28,
	2,6,29,
	5,4,30,
	4,5,30,
	6,3,32,
	3,6,33,
	7,0,31,
	0,7,34,
	7,1,35,
	1,7,36,
	5,5,39,
	7,2,37,
	6,4,39,
	4,6,40,
	2,7,38,
	7,3,41,
	3,7,42,
	8,0,43,
	6,5,47,
	5,6,47,
	0,8,44,
	8,1,45,
	1,8,46,
	7,4,49,
	4,7,50,
	8,2,48,
	2,8,51,
	8,3,52,
	6,6,55,
	3,8,53,
	7,5,55,
	5,7,56,
	9,0,54,
	0,9,57,
	9,1,58,
	8,4,60,
	4,8,61,
	1,9,59,
	9,2,62,
	2,9,63,
	7,6,65,
	6,7,65,
	9,3,64,
	8,5,67,
	5,8,68,
	3,9,66,
	10,0,69,
	9,4,72,
	4,9,73,
	0,10,70,
	10,1,71,
	7,7,77,
	1,10,74,
	8,6,77,
	6,8,78,
	10,2,75,
	2,10,76,
	9,5,80,
	5,9,81,
	10,3,79,
	3,10,82,
	8,7,88,
	7,8,88,
	10,4,84,
	4,10,85,
	11,0,83,
	9,6,90,
	6,9,91,
	0,11,86,
	11,1,87,
	1,11,89,
	11,2,92,
	2,11,93,
	10,5,94,
	5,10,95,
	11,3,96,
	8,8,98,
	3,11,97,
	9,7,98,
	7,9,99,
	11,4,100,
	10,6,103,
	6,10,104,
	4,11,101,
	12,0,102,
	0,12,105,
	12,1,106,
	1,12,107,
	12,2,108,
	11,5,110,
	9,8,113,
	8,9,113,
	5,11,111,
	2,12,109,
	10,7,115,
	7,10,116,
	12,3,112,
	3,12,114,
	11,6,118,
	6,11,119,
	12,4,117,
	4,12,120,
	9,9,127,
	13,0,121,
	10,8,127,
	8,10,128,
	0,13,122,
	13,1,123,
	1,13,124,
	12,5,126,
	5,12,129,
	13,2,125,
	11,7,131,
	7,11,132,
	2,13,130,
	13,3,133,
	3,13,134,
	12,6,135,
	6,12,136,
	10,9,139,
	9,10,139,
	13,4,137,
	4,13,138,
	11,8,141,
	8,11,142,
	14,0,140,
	0,14,143,
	14,1,144,
	13,5,146,
	12,7,149,
	7,12,150,
	5,13,147,
	1,14,145,
	14,2,148,
	2,14,151,
	10,10,156,
	14,3,152,
	11,9,156,
	9,11,157,
	3,14,153,
	13,6,154,
	6,13,155,
	12,8,160,
	8,12,161,
	14,4,158,
	4,14,159,
	13,7,166,
	7,13,167,
	15,0,162,
	14,5,165,
	5,14,168,
	0,15,163,
	15,1,164,
	11,10,172,
	10,11,172,
	1,15,169,
	15,2,170,
	12,9,174,
	9,12,175,
	2,15,171,
	15,3,173,
	14,6,177,
	6,14,178,
	3,15,176,
	13,8,179,
	8,13,180,
	15,4,181,
	4,15,182,
	11,11,190,
	14,7,183,
	12,10,190,
	10,12,191,
	7,14,184,
	15,5,186,
	5,15,187,
	13,9,194,
	9,13,195,
	15,6,198,
	14,8,201,
	8,14,202,
	6,15,199,
	12,11,205,
	11,12,205,
	13,10,207,
	10,13,208,
	15,7,206,
	7,15,209,
	14,9,212,
	9,14,213,
	15,8,215,
	12,12,218,
	8,15,216,
	13,11,218,
	11,13,219,
	14,10,220,
	10,14,221,
	15,9,224,
	9,15,225,
	13,12,227,
	12,13,227,
	14,11,229,
	11,14,230,
	15,10,231,
	10,15,232,
	13,13,235,
	14,12,235,
	12,14,236,
	15,11,237,
	11,15,238,
	14,13,241,
	13,14,241,
	15,12,242,
	12,15,243,
	14,14,246,
	15,13,246,
	13,15,247,
	15,14,250,
	14,15,250,
	15,15,253 };


//////////////////////////////// PROTOTYPES /////////////////////////////////

Matrix *createWHBaseVectors();
void calcWHMat(Matrix *mat, u_int16 dim);
Matrix *snakeVectorsOrder(Matrix *result);
Matrix *GroupedOrder(Matrix *result);
Matrix *GroupedOrder2(Matrix *result);
void createWHBase(Matrix* baseVectors, Matrix *base, u_int16 i, u_int16 j);
void projWHDC(GCKSetup *setup, Image *image, Matrix *dcProj, Matrix *tmpProj);
void projWHDC_Pattern(GCKSetup *setup, Image *image, Matrix *dcProj, Matrix *tmpProj);
void calcGCKOffset(int32 *offset, int32 *sign, Matrix *basesVectors, int32 curVecNum, int32 prevVecNum);
void singleWHProjByRow_Pattern(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign);
void singleWHProjByCol_Pattern(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign);
 u_int32 calcSAD(u_int8 *sourcePtr, u_int16 sourceDif, u_int8 *destPtr, u_int16 destDif, int BLOCK_SIZE_IMG); 
void setBoundaryZerosProjs(GCKSetup *setup, Matrix **prvImgProj, basisT BaseStart, basisT BaseEnd);


///////////////////////////////// FUNCTIONS /////////////////////////////////

/******************************************************************************
 * Creates and returns a GCKSetup.                                            *
 ******************************************************************************/
int32 BasesInOneCol[160];
int32 BasesInOneRow[160];
int32 StrideMtx[160];
int32 Stride3Mtx[160];
int BOUNDARY_SIZE_IMG, BLOCK_SIZE_IMG;

void PrepareBasis(GCKSetup *setup, int BasisNum)
{
	int32 i, j;
	int32 counter;
	int32 NumBases, Maxi, Maxj;
	NumBases = BasisNum;
	Maxi = 8;
	Maxj = 8;
	for (counter = 0; counter<NumBases; counter++)
	{
		i = matVal(setup->baseVectorsOrder,counter,0);
		j = matVal(setup->baseVectorsOrder,counter,1);
		setup->Idx[i][j] = counter;
		FreqOrder[i][j] = counter;
		FreqOrder2[i][j] = (counter/4)*5+(counter&3)+1;
		StrideMtx[FreqOrder2[i][j]] = matSize(setup->prevImageProj[0]);
		Stride3Mtx[FreqOrder2[i][j]] = StrideMtx[FreqOrder2[i][j]]*3;
	}
	for (counter = 0; counter<NumBases; counter++)
	{
		i = matVal(setup->baseVectorsOrder,counter,0);
		j = matVal(setup->baseVectorsOrder,counter,1);
		if ( ((j&3)==0) && ((j & 4) !=0) )
		{
			FreqOrder2[i][j]+=3;
			StrideMtx[FreqOrder2[i][j]] = matSize(setup->prevImageProj[0]);
			StrideMtx[FreqOrder2[i][j]] = - StrideMtx[FreqOrder2[i][j]];
			Stride3Mtx[FreqOrder2[i][j]] = StrideMtx[FreqOrder2[i][j]]*3;
		}
	}
	for (j=0; j<Maxj; j++)
	{	
		BasesInOneCol[j] = 0;
		for (i=0; i<Maxi; i++)
		{
			if (setup->Idx[i][j]<BasisNum)
				BasesInOneCol[j]++;
		}
	}	
	for (i=0; i<Maxi; i++)
	{	
		BasesInOneRow[j] = 0;
		for (j=0; j<Maxj; j++)
		{
			if (setup->Idx[i][j]<BasisNum)
				BasesInOneRow[i]++;
		}
	}	
}

__inline  u_int32 calcSSD(u_int8 *sourcePtr, u_int16 sourceDif, u_int8 *destPtr, u_int16 destDif, int BLOCK_SIZE_IMG) 
{
	 
	  register u_int32 sad;
	  register u_int16 cols;
	  register u_int16 rows;
	  u_int32 *pSqrDiff = SqrDiff+MAX_DIFF;
	 sad = 0;

//	 rows = BLOCK_SIZE_IMG;
     cols = BLOCK_SIZE_IMG;

	 for (rows = BLOCK_SIZE_IMG; rows !=0; rows--)
	 {
		 do { 
			 sad += pSqrDiff[*destPtr-*sourcePtr];
			sourcePtr++;
			destPtr++;
			cols--;
		 }while(cols!=0);		
		 sourcePtr += sourceDif;
		 destPtr += destDif;
		 cols = BLOCK_SIZE_IMG;
	 };

	 /*
	  * This version is simpler to understand but slower
			
	 for (i=curX; i<maxX; i++)
		 for (j=curY; j<maxY; j++) {
			 sad += ABS_DIFF(matVal(curImage, j, i), matVal(prevImage, j-offsetY, i-offsetX));
		 }
	 */

	 return sad;
 }

__inline  u_int32 calcSSD2(u_int8 *sourcePtr, u_int16 sourceDif, u_int8 *destPtr, u_int16 destDif, int BLOCK_SIZE_IMG) 
{
	 
	  register u_int32 SSD = 0;
	  register u_int16 cols;
	  register u_int16 rows;
	 

	 rows = BLOCK_SIZE_IMG;
	 cols = BLOCK_SIZE_IMG;
	 do {
		 do { 
			 int diff = (int) ( *destPtr - *sourcePtr);
			 SSD += diff*diff;
			sourcePtr++;
			destPtr++;
			cols--;
		 }while(cols!=0);		
		 sourcePtr += sourceDif;
		 destPtr += destDif;
		 cols = BLOCK_SIZE_IMG;
		 rows--;
	 } 
	 while(rows!=0);

	 /*
	  * This version is simpler to understand but slower
			
	 for (i=curX; i<maxX; i++)
		 for (j=curY; j<maxY; j++) {
			 sad += ABS_DIFF(matVal(curImage, j, i), matVal(prevImage, j-offsetY, i-offsetX));
		 }
	 */

	 return SSD;
 }


__inline  u_int32 calcSAD(u_int8 *sourcePtr, u_int16 sourceDif, u_int8 *destPtr, u_int16 destDif, int BLOCK_SIZE_IMG) 
{
	 
	  register u_int32 sad;
/*	  u_int8 *destPtr;
	  u_int16 destDif;*/
	  register u_int16 cols;
	  register u_int16 rows;
	  u_int32 *pSqrDiff = SqrDiff+MAX_DIFF;
	 sad = 0;

	 rows = BLOCK_SIZE_IMG;
     cols = BLOCK_SIZE_IMG;

	 do {
		 do { 
			 sad += abs(*destPtr-*sourcePtr);
			sourcePtr++;
			destPtr++;
			cols--;
		 }while(cols!=0);		
		 sourcePtr += sourceDif;
		 destPtr += destDif;
		 cols = BLOCK_SIZE_IMG;
		 rows--;
	 } while(rows!=0);

	 /*
	  * This version is simpler to understand but slower
			
	 for (i=curX; i<maxX; i++)
		 for (j=curY; j<maxY; j++) {
			 sad += ABS_DIFF(matVal(curImage, j, i), matVal(prevImage, j-offsetY, i-offsetX));
		 }
	 */

	 return sad;
 }

// Allocate large number of memories required and provide parameters used
GCKSetup *GCKSetupInit(GCKSetup *result, int AlgChoice, coordT sourceRows, 
						 coordT sourceCols, coordT patternRows, basisT numOfBasis)
{
	int32 i;
#ifdef SHOW_MY_STATS	
	int32 counter;
#endif
	int32 NumBases;
	int32 Max_offset, Boundary_Size_Pat;
	int32 mysize;

	result->Img_Heihgt = sourceRows;
	result->Img_Width = sourceCols;
	result->Block_size_img = patternRows*SCALE;
	result->Block_size_pat = patternRows;
	result->Bases_Num = numOfBasis;
	Max_offset = result->Block_size_img>>1;
	result->Boundary_Size_Img = result->Block_size_img+Max_offset;

	Boundary_Size_Pat = result->Block_size_pat+Max_offset;
	result->Img_Width_With_Boundary = result->Img_Width + result->Boundary_Size_Img;
	result->Img_Height_With_Boundary= result->Img_Heihgt+ result->Boundary_Size_Img;
	result->Pat_Width_With_Boundary = result->Block_size_pat + Boundary_Size_Pat;
	result->Pat_Height_With_Boundary= result->Block_size_pat + Boundary_Size_Pat;
	result->Boundary_Size_Pat = Boundary_Size_Pat;
	BOUNDARY_SIZE_IMG = result->Boundary_Size_Img;
	BLOCK_SIZE_IMG = result->Block_size_img;
	result->ImgProj_Width =result->Img_Width_With_Boundary-BLOCK_SIZE_IMG+1;
	result->ImgProj_Height =result->Img_Height_With_Boundary-BLOCK_SIZE_IMG+1;

	mysize = result->ImgProj_Height * result->ImgProj_Width * (MEM_BASES) * sizeof(int32);
	result->ProjPtr = (int32 *)malloc(mysize);
	if (!result->ProjPtr)
		exitWithError("can't allocate ProjPtr array in createGCKSetup.");

	result->prevImage = allocImage(result->Img_Height_With_Boundary, result->Img_Width_With_Boundary);
	result->curImage = allocImage(result->Pat_Height_With_Boundary, result->Pat_Width_With_Boundary);
	result->diffImage = allocDiffImage(result->Img_Height_With_Boundary, result->Img_Width_With_Boundary);


	result->baseVectorsOrder = allocMatrix(BLOCK_SIZE_IMG * BLOCK_SIZE_IMG, 3);

//this code is used for showing the order information

	result->colsProj = allocMatrix(result->Img_Height_With_Boundary+1, result->Img_Width_With_Boundary+1);

	result->curImageProj = (Matrix **)malloc(sizeof(Matrix *) * (MEM_BASES));
	result->prevImageProj = (Matrix **)malloc(sizeof(Matrix *) * (MEM_BASES));
	
	result->distances = allocMatrix_Dist(result->Img_Heihgt, result->Img_Width);
	
	for (i=0; i<MEM_BASES; i++) 
	{
		Matrix *mat;
		coordT rows=result->ImgProj_Height;
		coordT cols=result->ImgProj_Width;
		mat = (Matrix *)malloc(sizeof(Matrix));
		mat->rowsPtr = (int32 **)malloc(rows * sizeof(int32 *));
		if (!mat->rowsPtr)
			exitWithError("ERROR in allocMatrix: can't allocate cellValues rows mapping.");
	
		result->prevImageProj[i] = mat;
	}


//	NumBases = (MAX_BASES+MAX_BASES/4);
	NumBases = MEM_BASES;
	for (i=0; i<NumBases; i++) {
		result->curImageProj[i] = allocMatrix(result->Pat_Height_With_Boundary-result->Block_size_pat+1, result->Pat_Width_With_Boundary-result->Block_size_pat+1);
	}

	return result;
}

GCKSetup *createGCKSetup(GCKSetup *result, int AlgChoice, coordT sourceRows, 
						 coordT sourceCols, coordT patternRows, basisT numOfBasis)
{

	int32 i, j, NumBases;
#ifdef SHOW_MY_STATS	
	int32 counter;
#endif
	int32 NumBasesToPrint, Maxi, Maxj;
	int32 Max_offset, Boundary_Size_Pat;
	if (!result)
		exitWithError("ERROR in createGCKSetup: can't allocate setup.");
	result->Img_Heihgt = sourceRows;
	result->Img_Width = sourceCols;
	result->Block_size_img = patternRows*SCALE;
	result->Block_size_pat = patternRows;
	result->Bases_Num = numOfBasis;
	Max_offset = result->Block_size_img>>1;
	result->Boundary_Size_Img = result->Block_size_img+Max_offset;

	Boundary_Size_Pat = result->Block_size_pat+Max_offset;
	result->Img_Width_With_Boundary = result->Img_Width + result->Boundary_Size_Img;
	result->Img_Height_With_Boundary= result->Img_Heihgt+ result->Boundary_Size_Img;
	result->Pat_Width_With_Boundary = result->Block_size_pat + Boundary_Size_Pat;
	result->Pat_Height_With_Boundary= result->Block_size_pat + Boundary_Size_Pat;
	result->Boundary_Size_Pat = Boundary_Size_Pat;
	BOUNDARY_SIZE_IMG = result->Boundary_Size_Img;
	BLOCK_SIZE_IMG = result->Block_size_img;
	result->ImgProj_Width =result->Img_Width_With_Boundary-BLOCK_SIZE_IMG+1;
	result->ImgProj_Height =result->Img_Height_With_Boundary-BLOCK_SIZE_IMG+1;

	reallocImage2(result->prevImage, result->prevImage->rowsPtr[0], result->Img_Height_With_Boundary, result->Img_Width_With_Boundary);
	reallocImage2(result->curImage, result->curImage->rowsPtr[0], result->Pat_Height_With_Boundary, result->Pat_Width_With_Boundary);

	reallocDiffImage2(result->diffImage, result->diffImage->rowsPtr[0], result->Img_Height_With_Boundary, result->Img_Width_With_Boundary);

	result->baseVectors = createWHBaseVectors();
	if (AlgChoice == CHOICE_HELOR_GCK)
		result->baseVectorsOrder = incFreqVectorsOrder(result->baseVectorsOrder);
	else if (AlgChoice == CHOICE_WANLI_FWHT)
		result->baseVectorsOrder = GroupedOrder3(result->baseVectorsOrder);


	NumBasesToPrint = MAX_BASES;
	Maxi = 16;
	Maxj = 16;
	for (i=0; i<Maxi; i++)
	{
		for (j=0; j<Maxj; j++)			
			result->Idx[i][j]=0;
	}

//this code is used for showing the order information
#ifdef SHOW_MY_STATS	
	for (counter = 0; counter<NumBasesToPrint; counter++)
	{
		i = matVal(result->baseVectorsOrder,counter,0);
		j = matVal(result->baseVectorsOrder,counter,1);
		result->Idx[i][j] = counter;
	}
	for (i=0; i<Maxi; i++)
	{
		for (j=0; j<Maxj; j++)
		{
			printf("%3d ", result->Idx[i][j]);
		}
		printf("\n", result->Idx[i][j]);
	}
#endif

	result->distances = allocMatrix_Dist(result->Img_Heihgt, result->Img_Width);
	

	for (i=0; i<MEM_BASES; i++) 
	{
		Matrix *mat;
		coordT rows=result->ImgProj_Height;
		coordT cols=result->ImgProj_Width;
		u_int32 row;
		int32 *ptr;
		mat = result->prevImageProj[i];
		mat->cellValues = ptr = &(result->ProjPtr[i * rows * cols]);
		mat->rows = rows;
		mat->cols = cols;
		mat->size = rows * cols;

		for (row = 0; row < rows ; row++) {
			mat->rowsPtr[row] = ptr;
			ptr += cols;
		}
		
	}
	NumBases = MEM_BASES;
	for (i=0; i<NumBases; i++) {
		Matrix *mat = result->curImageProj[i];
		coordT rows=result->Pat_Height_With_Boundary-result->Block_size_pat+1;
		coordT cols=result->Pat_Width_With_Boundary-result->Block_size_pat+1;
		u_int32 row;
		int32 *ptr;
		ptr = mat->cellValues;
		mat->rows = rows;
		mat->cols = cols;
		mat->size = rows * cols;

		for (row = 0; row < rows ; row++) {
			mat->rowsPtr[row] = ptr;
			ptr += cols;
		}
	}

	for (i = 0; i<MAX_BASES; i++) {
		int row, col;
		row = matVal(result->baseVectorsOrder,i,0);
		col = matVal(result->baseVectorsOrder,i,1)>>2;
		result->tIdx[row][col] = (i>>2)+4;
	}

	setBoundaryZerosProjs(result, result->prevImageProj, 0, MEM_BASES);
	PrepareBasis(result, numOfBasis);
	ComputeOffset(result, result->baseVectors);
	//settings for WHTInOneRowG4
	result->Cols = result->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1;
	result->maxRows = result->ImgProj_Height-(BLOCK_SIZE_IMG>>1)-BLOCK_SIZE_IMG;
	result->maxCols = result->Cols - (BLOCK_SIZE_IMG>>1);
	result->offset = BLOCK_SIZE_IMG>>2;
	result->StartPos= &matVal(result->prevImageProj[0], (BLOCK_SIZE_IMG>>1),BLOCK_SIZE_IMG>>2)-&matVal(result->prevImageProj[0], 0,0);
	result->BlkSizeBy2 = BLOCK_SIZE_IMG>>1;
	return result;
}


void DeleteMemGCKSetup(GCKSetup *setup) {
	destroyMatrixDist(setup->distances);
	destroyMatrix(setup->baseVectors);
}
/*****************************************************************************
 * Destroys the given GCKSetup.                                               *
 *****************************************************************************/
void destroyGCKSetup(GCKSetup *setup) {

	int32 i;
	for (i=0; i<MEM_BASES; i++) {
		destroyMatrix2(setup->prevImageProj[i]);
	}
	for (i=0; i<MEM_BASES; i++) {
		destroyMatrix(setup->curImageProj[i]);
	}
	free(setup->curImageProj);
	free(setup->prevImageProj);

#ifdef MY_DEBUG
	free(setup->curImageProj2);
#endif

	free(setup->ProjPtr);

	destroyMatrix(setup->colsProj);
	destroyMatrix(setup->baseVectorsOrder);
}




/******************************************************************************
 * Allocates and creates a matrix that contains Walsh-Hadamard base vectors   *
 * as its rows. The vectors are in sequency order.                            *
 ******************************************************************************/
__inline Matrix *createWHBaseVectors() {	

	Matrix *unorderWH = allocMatrix(BLOCK_SIZE_IMG, BLOCK_SIZE_IMG);
	Matrix *unorderWH_conv, *indices, *result;
	Matrix *mask = allocMatrix(1,2);

	matVal(mask,0,0) = 1;
	matVal(mask,0,1) = -1;

	matVal(unorderWH,0,0) = 1;
	matVal(unorderWH,0,1) = 1;
	matVal(unorderWH,1,0) = 1;
	matVal(unorderWH,1,1) = -1;

	calcWHMat(unorderWH, 2);
	unorderWH_conv = conv2Matrix(unorderWH, mask);
	absMatrix(unorderWH_conv);
	indices = sumRowsMatrix(unorderWH_conv); 	// ordered index	
	divMatrixByConst(indices, 2);
	addConstToMatrix(indices, -1);			    // index starts from 0
	result = copyRowsByIndex(unorderWH, indices);

	destroyMatrix(unorderWH);
	destroyMatrix(unorderWH_conv);
	destroyMatrix(indices);
	destroyMatrix(mask);

	return result;
}


/******************************************************************************
 * Builds unordered Walsh-Hadmard vectors of given size recursively.		  *
 ******************************************************************************/
__inline void calcWHMat(Matrix *mat, u_int16 size) {	

	if (size == matRows(mat))
		return;

	copyMatrixSegment(mat, mat, 0, 0,    size, 0, size, size, PLUS);
	copyMatrixSegment(mat, mat, 0, size, size, 0, 0,    size, PLUS);
	copyMatrixSegment(mat, mat, 0, size, size, 0, size, size, MINUS);
	size*=2;
	calcWHMat(mat, size);
}


/******************************************************************************
 * Returns the snakee vectors order. This is an order that preserves the      *
 * alpha-relation property between each vector and the vector that precede    *
 * it.																          *
 ******************************************************************************/
Matrix *snakeVectorsOrder(Matrix *result) {

//	Matrix *result = allocMatrix(BLOCK_SIZE_IMG * BLOCK_SIZE_IMG, 3);
	int16 i, j ,counter=1;
			
	matVal(result,0,0) = 0;
	matVal(result,0,1) = 0;
	matVal(result,0,2) = 0;		// previous projection

	for (i=1;i<BLOCK_SIZE_IMG;i++)	{
        for (j=0;j<=(int)i ;j++){
            if (i%2 == 1) {
                matVal(result,counter,0) = j;
                matVal(result,counter,1) = i;
            }
            else {
                matVal(result,counter,0) = i;
                matVal(result,counter,1) = j;
			}
			matVal(result,counter,2) = counter-1;	// previous projection
			counter++;
		}
		for (j=i-1;j>=0;j--){
			if (i%2 == 1) {
				matVal(result,counter,0) = i;
				matVal(result,counter,1) = j;	
			}
			else {
				matVal(result,counter,0) = j;
				matVal(result,counter,1) = i;
			}
			matVal(result,counter,2) = counter-1;	// previous projection
			counter++;
		}
	}
	return result;
}

Matrix *GroupedOrder3(Matrix *result) {

//	Matrix *result = allocMatrix(BLOCK_SIZE_IMG * BLOCK_SIZE_IMG, 3);
	int16 i, j, counter;
	counter = 0;
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis3[counter][1];
			GroupProjOrder[counter][1] = GroupProjOrderBasis3[counter][0];
			GroupProjOrder[counter][2] = GroupProjOrderBasis3[counter][2];
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis3[counter-16][1]+4;
			GroupProjOrder[counter][1] = GroupProjOrderBasis3[counter-16][0];
			GroupProjOrder[counter][2] = GroupProjOrderBasis3[counter-16][2]+16;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis3[counter-32][1];
			GroupProjOrder[counter][1] = GroupProjOrderBasis3[counter-32][0]+4;
			GroupProjOrder[counter][2] = GroupProjOrderBasis3[counter-32][2]+32;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis3[counter-48][1]+4;
			GroupProjOrder[counter][1] = GroupProjOrderBasis3[counter-48][0]+4;
			GroupProjOrder[counter][2] = GroupProjOrderBasis3[counter-48][2]+48;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis3[counter-64][1]+8;
			GroupProjOrder[counter][1] = GroupProjOrderBasis3[counter-64][0];
			GroupProjOrder[counter][2] = GroupProjOrderBasis3[counter-64][2]+64;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis3[counter-80][1];
			GroupProjOrder[counter][1] = GroupProjOrderBasis3[counter-80][0]+8;
			GroupProjOrder[counter][2] = GroupProjOrderBasis3[counter-80][2]+80;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis3[counter-96][1];
			GroupProjOrder[counter][1] = GroupProjOrderBasis3[counter-96][0]+12;
			GroupProjOrder[counter][2] = GroupProjOrderBasis3[counter-96][2]+96;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis3[counter-112][1]+12;
			GroupProjOrder[counter][1] = GroupProjOrderBasis3[counter-112][0];
			GroupProjOrder[counter][2] = GroupProjOrderBasis3[counter-112][2]+112;
			counter++;
		}
	GroupProjOrder[0][2] = 0;
	GroupProjOrder[16][2] = 12;
	GroupProjOrder[32][2] = 3;
	GroupProjOrder[48][2] = 44;
	GroupProjOrder[64][2] = 28;
	GroupProjOrder[80][2] = 35;
	GroupProjOrder[96][2] = 83;
	GroupProjOrder[112][2] = 76;
	memcpy(result->cellValues, GroupProjOrder, MAX_BASES*3*sizeof(int32));
	return result;
}

/******************************************************************************
 * Returns the increasing frequency vectors order. This is an order that      *
 * preserves the alpha-relation property between each vector and one of the   *
 * vector that precede it. This order gives better results than snake order   *
 * but can be used only when all previous projections are saved in memory     *
 * (always in this code).                                                     *
 ******************************************************************************/
Matrix *incFreqVectorsOrder(Matrix *result) {
//	Matrix *result = allocMatrix(BLOCK_SIZE_IMG * BLOCK_SIZE_IMG, 3);
	memcpy(result->cellValues, incFreqProjOrder, BLOCK_SIZE_IMG*BLOCK_SIZE_IMG*3*sizeof(int32));
	return result;
}


/******************************************************************************
 * Creates the Walsh-Hadamard base specified by coordinates (i,j) in          *
 * basesVectors and stores it into base.                                      *
 ******************************************************************************/
__inline void createWHBase(Matrix* baseVectors, Matrix *base, u_int16 i, u_int16 j) {

	u_int16 dim = matRows(baseVectors);
	u_int16 k;

	for (k=0; k<dim; k++)
		copyMatrixSegment(baseVectors, base, 0, 0, dim, i, k, 1, matVal(baseVectors,j,k));

	return;		
}


/******************************************************************************
 * Calculates the DC component of each window of size BLOCK_SIZE of the given *
 * image using 4 operations per pixel. The result is returned in dcProj       *
 * (which should be pre-allocated with the correct size). tmpProj is a		  *
 * pre-allocated matrix in the size of the image, used for temporary          *
 * calculations.                                                              *
 ******************************************************************************/

__inline void projWHDCDbg(GCKSetup *setup, Image *image, Matrix *dcProj, Matrix *tmpProj) {

	u_int8 *ptr1; 
	int32 *ptr2;
	u_int16 col, row;
	int32 sum;

	u_int16 RLoc, CLoc;
	u_int16 maxCols = setup->ImgProj_Width;
	u_int16 maxRows = setup->ImgProj_Height;

	for (CLoc=0; CLoc<setup->Img_Width_With_Boundary; CLoc++)  {
		ptr1 = &imVal(image, 0, CLoc);
		row = BLOCK_SIZE_IMG;
		sum = 0;

		while (row--) {
			sum += *ptr1;
			ptr1 += setup->Img_Width_With_Boundary;
		}
		matVal(tmpProj,0,CLoc) = sum;

		for (RLoc=1; RLoc<maxRows; RLoc++)
			matVal(tmpProj,RLoc,CLoc) =
					matVal(tmpProj,RLoc-1,CLoc) - imVal(image,RLoc-1,CLoc) + imVal(image,RLoc+BLOCK_SIZE_IMG-1,CLoc);
	}
	
 	for (RLoc=0; RLoc<maxRows;RLoc++)  {
		ptr2 = &imVal(tmpProj, RLoc, 0);
		col = BLOCK_SIZE_IMG;
		sum = 0;

		while (col--) 
			sum += *(ptr2++);
		matVal(dcProj,RLoc,0) = sum;

		for (CLoc=1; CLoc<maxCols; CLoc++)
			matVal(dcProj,RLoc,CLoc) =
				matVal(dcProj,RLoc,CLoc-1) - matVal(tmpProj,RLoc,CLoc-1) + matVal(tmpProj,RLoc,CLoc+BLOCK_SIZE_IMG-1);
	}
}

/******************************************************************************
 * Calculates the DC component of each window of size BLOCK_SIZE of the given *
 * image using 4 operations per pixel. The result is returned in dcProj       *
 * (which should be pre-allocated with the correct size). tmpProj is a		  *
 * pre-allocated matrix in the size of the image, used for temporary          *
 * calculations.                                                              *
 ******************************************************************************/
__inline void projWHDC(GCKSetup *setup, Image *image, Matrix *dcProj, Matrix *tmpProj) {

	u_int8 *ptr1; 
	int32 *ptr2, *ptr3;
	u_int16 col;
	int32 sum;
	int BRowSize = BLOCK_SIZE_IMG;
	int BColSize = BLOCK_SIZE_IMG;
	u_int16 RLoc, CLoc;
	u_int16 maxCols = setup->ImgProj_Width;
	u_int16 maxRows = setup->ImgProj_Height;
//	int32 *currentProjPtr, *prevProjPtr1;
	int stridePrev, strideCur;

	memset(&matVal(tmpProj,0,0), 0, sizeof(int32)*setup->Img_Width_With_Boundary);
	for (RLoc=0; RLoc<BRowSize; RLoc++)
	{
		ptr1 = &imVal(image, 0, 0);
		ptr2 = &matVal(tmpProj,RLoc,0);
		for (CLoc=0; CLoc<setup->Img_Width_With_Boundary; CLoc++)  {
			*ptr2 += *ptr1;
			ptr2++;
			ptr1++;
		}
	}


	for (RLoc=1; RLoc<maxRows; RLoc++)
	{
		ptr2 = &matVal(tmpProj,RLoc-1,0);
		strideCur = &matVal(tmpProj,RLoc,0) - &matVal(tmpProj,RLoc-1,0);
		ptr1 = &imVal(image,RLoc-1,0);
		stridePrev = &matVal(image,RLoc+BRowSize-1,0) - &matVal(image,RLoc-1,0);
		for (CLoc=0; CLoc<setup->Img_Width_With_Boundary; CLoc++)  
		{
			ptr2[strideCur] = *ptr2 - *ptr1 + ptr1[stridePrev];
			ptr2++;
			ptr1++;
		}
	}
	
 	for (RLoc=0; RLoc<maxRows;RLoc++)  {
		ptr2 = &imVal(tmpProj, RLoc, 0);
		col = BColSize;
		sum = 0;

		while (col--) 
			sum += *(ptr2++);
		matVal(dcProj,RLoc,0) = sum;

		ptr2 = &matVal(tmpProj,RLoc,0);
		ptr3 = &matVal(dcProj,RLoc,0);
		for (CLoc=1; CLoc<maxCols; CLoc++)
		{
			ptr3[1] = *ptr3 - *ptr2 + ptr2[BColSize];
			ptr3++;
			ptr2++;
		}
	}
}



__inline void projWHDC_Pattern(GCKSetup *setup, Image *image, Matrix *dcProj, Matrix *tmpProj) {

	u_int8 *ptr1; 
	int32 *ptr2;
	u_int16 col, row;
	int32 sum;

	u_int16 RLoc, CLoc;
	u_int16 maxCols = setup->Pat_Width_With_Boundary-setup->Block_size_pat+1;
	u_int16 maxRows = setup->Pat_Height_With_Boundary-setup->Block_size_pat+1;

	for (CLoc=0; CLoc<setup->Pat_Width_With_Boundary; CLoc++)  {
		ptr1 = &imVal(image, 0, CLoc);
		row = setup->Block_size_pat;
		sum = 0;

		while (row--) {
			sum += *ptr1;
			ptr1 += setup->Pat_Width_With_Boundary;
		}
		matVal(tmpProj,0,CLoc) = sum;

		for (RLoc=1; RLoc<maxRows; RLoc++)
			matVal(tmpProj,RLoc,CLoc) =
					matVal(tmpProj,RLoc-1,CLoc) - imVal(image,RLoc-1,CLoc) + imVal(image,RLoc+setup->Block_size_pat-1,CLoc);
	}
	
 	for (RLoc=0; RLoc<maxRows;RLoc++)  {
		ptr2 = &imVal(tmpProj, RLoc, 0);
		col = setup->Block_size_pat;
		sum = 0;

		while (col--) 
			sum += *(ptr2++);
		matVal(dcProj,RLoc,0) = sum;

		for (CLoc=1; CLoc<maxCols; CLoc++)
			matVal(dcProj,RLoc,CLoc) =
				matVal(dcProj,RLoc,CLoc-1) - matVal(tmpProj,RLoc,CLoc-1) + matVal(tmpProj,RLoc,CLoc+setup->Block_size_pat-1);
	}
}

/******************************************************************************
 * Calculates the offset and sign for GCK projection.                         *
 ******************************************************************************/                                              
 __inline void calcGCKOffset(int32 *offset, int32 *sign, Matrix *basesVectors, int32 curVecNum, int32 prevVecNum) {

	 u_int16 i;

	 for (i=0; i<matRows(basesVectors); i++)
		 if (matVal(basesVectors, curVecNum, i) != matVal(basesVectors, prevVecNum, i))
			 break;

     *offset = i;
	 *sign = -matVal(basesVectors, prevVecNum, i);

	 return;
 }


/*******************************************************************************
 * Calculates the current projection of the image based on previous projection *
 * by rows using GCK (2 operations per pixel).								   *
 ******************************************************************************/ 
 
__inline void singleWHProjByRow_Prv(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign) {

	u_int16 row, col;
	u_int16 maxCols, maxRows;
	u_int16 rows = currentProj->rows;
	u_int16 leftBoundarySize = (u_int16)(sizeof(int32)*offset);
	int32 *currentProjPtr, *prevProjPtr1;
	int strideOffset, stride;

	maxCols = (u_int16)(setup->ImgProj_Width);
	maxRows = (u_int16)(setup->ImgProj_Height-offset);

	// fill boundary with zeros
	memset(currentProj->cellValues, 0, sizeof(int32)*offset*currentProj->cols);
	for (row=0; row<rows; row++)
		memset(&matVal(currentProj,row,0), 0, leftBoundarySize);

	// calculate non-boundary with 2 operations per pixel
	strideOffset = &matVal(currentProj,offset,0) - &matVal(currentProj,0,0);
	stride = &matVal(currentProj,1,0) - &matVal(currentProj,0,0);
	if (sign == 1)
		for (col=0; col < maxCols; col++)
		{
			currentProjPtr = &matVal(currentProj,0,col);
			prevProjPtr1 = &matVal(prevProj,0,col);
			for (row=0; row < maxRows; row++)
			{
				currentProjPtr[strideOffset] = *currentProjPtr - prevProjPtr1[strideOffset] - *prevProjPtr1;
				currentProjPtr+=stride;
				prevProjPtr1+=stride;
			}
		}
	else
		for (col=0; col < maxCols; col++)
		{
			currentProjPtr = &matVal(currentProj,0,col);
			prevProjPtr1 = &matVal(prevProj,0,col);
			for (row=0; row < maxRows; row++)
			{
				currentProjPtr[strideOffset] = *prevProjPtr1 - *currentProjPtr - prevProjPtr1[strideOffset];
				currentProjPtr+=stride;
				prevProjPtr1+=stride;
			}
		}
}


__inline void singleWHProjByRow(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign) 
{

	u_int16 row, col;
	u_int16 maxCols, maxRows;
	u_int16 rows = currentProj->rows;
	u_int16 leftBoundarySize = (u_int16)(sizeof(int32)*offset);
	int32 *currentProjPtr, *prevProjPtr;
	int32 Cols = setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1;

	maxCols = (u_int16)(setup->ImgProj_Width);
	maxRows = (u_int16)(setup->ImgProj_Height-offset);

	// fill boundary with zeros
	memset(currentProj->cellValues, 0, sizeof(int32)*offset*currentProj->cols);
	for (row=0; row<rows; row++)
		memset(&matVal(currentProj,row,0), 0, leftBoundarySize);

	// calculate non-boundary with 2 operations per pixel
	currentProjPtr = &matVal(currentProj,0,0);
	prevProjPtr = &matVal(prevProj,0,0);
	if (sign == 1)
	{
		for (col=0; col < maxCols; col++)
		{
			for (row=0; row < maxRows; row++)
			{
				currentProjPtr[(row+offset)*Cols+col] 
					= currentProjPtr[(row)*Cols+col] - prevProjPtr[(row)*Cols+col] - prevProjPtr[(row+offset)*Cols+col];
			}
		}
	}
	else
	{
		for (col=0; col < maxCols; col++)
		{
			for (row=0; row < maxRows; row++)
			{
				currentProjPtr[(row+offset)*Cols+col] 
					= prevProjPtr[(row)*Cols+col] - currentProjPtr[(row)*Cols+col] - prevProjPtr[(row+offset)*Cols+col];
			}
		}
	}
}
/*******************************************************************************
 * Calculates the current projection of the image based on previous projection *
 * by columns using GCK (2 operations per pixel).							   *
 ******************************************************************************/ 
__inline void singleWHProjByCol(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign) {

	u_int16 row, col;
	u_int16 maxCols, maxRows;
	u_int16 rows = currentProj->rows;
	u_int16 leftBoundarySize = (u_int16)(sizeof(int32)*offset);
	int32 *currentProjPtr, *prevProjPtr;
	int32 Cols = setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1;

	maxCols = (u_int16)(setup->ImgProj_Width-offset);
	maxRows = (u_int16)(setup->ImgProj_Height);

	// fill boundary with zeros
	memset(currentProj->cellValues, 0, sizeof(int32)*(offset)*currentProj->cols);
	for (row=0; row<rows; row++)
		memset(&matVal(currentProj,row,0), 0, leftBoundarySize);
		
	currentProjPtr = &matVal(currentProj,0,0);
	prevProjPtr = &matVal(prevProj,0,0);
	if (sign == 1)
		for (row=0; row < maxRows; row++)
		{
			for (col=0; col < maxCols; col++)
			{
				currentProjPtr[row*Cols+offset+col] = 
					currentProjPtr[row*Cols+col] - prevProjPtr[row*Cols+col] - prevProjPtr[row*Cols+offset+col];
			}
		}
	else
		for (row=0; row < maxRows; row++)
		{
			for (col=0; col < maxCols; col++)
			{
				currentProjPtr[row*Cols+offset+col] = 
					prevProjPtr[row*Cols+col] - currentProjPtr[row*Cols+col] - prevProjPtr[row*Cols+offset+col];
			}
		}
}

__inline void singleWHProjByRow_Pattern(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign) {

	u_int16 row, col;
	u_int16 maxCols, maxRows;
	u_int16 rows = currentProj->rows;
	u_int16 leftBoundarySize = (u_int16)(sizeof(int32)*offset);
	int32 *currentProjPtr, *prevProjPtr1, Cols;

	maxCols = (u_int16)(setup->Pat_Width_With_Boundary-setup->Block_size_pat+1);
	maxRows = (u_int16)(setup->Pat_Height_With_Boundary-setup->Block_size_pat+1-offset);
	currentProjPtr = &matVal(currentProj,0,0);
	prevProjPtr1 = &matVal(prevProj,0,0);
	Cols = &matVal(currentProj,1,0) - &matVal(currentProj,0,0);

	// fill boundary with zeros
	memset(currentProj->cellValues, 0, sizeof(int32)*offset*currentProj->cols);
	for (row=0; row<rows; row++)
		memset(&matVal(currentProj,row,0), 0, leftBoundarySize);

	// calculate non-boundary with 2 operations per pixel
	if (sign == 1)
	{
		for (col=0; col < maxCols; col++)
			for (row=0; row < maxRows; row++)
				currentProjPtr[(row+offset)*Cols+col] 
					= currentProjPtr[(row)*Cols+col] - prevProjPtr1[(row+offset)*Cols+col] - prevProjPtr1[(row)*Cols+col];
//				matVal(currentProj,row+offset,col) =
//                   matVal(currentProj,row,col) - matVal(prevProj,row+offset,col) - matVal(prevProj,row,col);
	}
	else
	{
		for (col=0; col < maxCols; col++)
			for (row=0; row < maxRows; row++)
				currentProjPtr[(row+offset)*Cols+col] 
					= prevProjPtr1[(row)*Cols+col] - currentProjPtr[(row)*Cols+col] - prevProjPtr1[(row+offset)*Cols+col];
//                matVal(currentProj,row+offset,col) =
//					-matVal(currentProj,row,col) + matVal(prevProj,row,col) - matVal(prevProj,row+offset,col);
	}
}


/*******************************************************************************
 * Calculates the current projection of the image based on previous projection *
 * by columns using GCK (2 operations per pixel).							   *
 ******************************************************************************/ 
__inline void singleWHProjByCol_Pattern(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign) {

	u_int16 row, col;
	u_int16 maxCols, maxRows;
	u_int16 rows = currentProj->rows;
	u_int16 leftBoundarySize = (u_int16)(sizeof(int32)*offset);
	int32 *currentProjPtr, *prevProjPtr1, Cols;

	maxCols = (u_int16)(setup->Pat_Width_With_Boundary-setup->Block_size_pat+1-offset);
	maxRows = (u_int16)(setup->Pat_Height_With_Boundary-setup->Block_size_pat+1);

	// fill boundary with zeros
	memset(currentProj->cellValues, 0, sizeof(int32)*(offset)*currentProj->cols);
	for (row=0; row<rows; row++)
		memset(&matVal(currentProj,row,0), 0, leftBoundarySize);

	currentProjPtr = &matVal(currentProj,0,0);
	prevProjPtr1 = &matVal(prevProj,0,0);
	Cols = &matVal(currentProj,1,0) - &matVal(currentProj,0,0);
		
	// calculate non-boundary with 2 operations per pixel
	if (sign == 1)
		for (row=0; row < maxRows; row++)
		{
			for (col=0; col < maxCols; col++)
			{
				currentProjPtr[row*Cols+offset+col] = 
					currentProjPtr[row*Cols+col] - prevProjPtr1[row*Cols+offset+col] - prevProjPtr1[row*Cols+col];
			}
		}
	else
		for (row=0; row < maxRows; row++)
		{
			for (col=0; col < maxCols; col++)
			{
				currentProjPtr[row*Cols+offset+col] = 
					prevProjPtr1[row*Cols+col] - currentProjPtr[row*Cols+col] - prevProjPtr1[row*Cols+offset+col];
			}
		}

	
/*	if (sign == 1)
		for (row=0; row < maxRows; row++)
			for (col=0; col < maxCols; col++)
				matVal(currentProj,row,col+offset) =
                    matVal(currentProj,row,col) - matVal(prevProj,row,col+offset) - matVal(prevProj,row,col);
	else
		for (row=0; row < maxRows; row++)
			for (col=0; col < maxCols; col++)
                matVal(currentProj,row,col+offset) =
					-matVal(currentProj,row,col) + matVal(prevProj,row,col) - matVal(prevProj,row,col+offset);
*/
}


__inline void projDiffWHDC(GCKSetup *setup, Diff_Image *image, Matrix *dcProj, Matrix *tmpProj, int BRowSize, int BColSize) {


	int16 *ptr1; 
	int32 *ptr2, *ptr3;
	u_int16 col;
	int32 sum;

	u_int16 RLoc, CLoc;
	u_int16 maxCols = setup->ImgProj_Width;
	u_int16 maxRows = setup->ImgProj_Height;
	int stridePrev, strideCur;

	memset(&matVal(tmpProj,0,0), 0, sizeof(int32)*setup->Img_Width_With_Boundary);
	for (RLoc=0; RLoc<BRowSize; RLoc++)
	{
		ptr1 = &imVal(image, 0, 0);
		ptr2 = &matVal(tmpProj,RLoc,0);
		CLoc = setup->Img_Width_With_Boundary;
		while(CLoc--)
			*(ptr2++) += *(ptr1++);
	}


	for (RLoc=1; RLoc<maxRows; RLoc++)
	{
		ptr2 = &matVal(tmpProj,RLoc-1,0);
		strideCur = &matVal(tmpProj,RLoc,0) - &matVal(tmpProj,RLoc-1,0);
		ptr1 = &imVal(image,RLoc-1,0);
		stridePrev = &matVal(image,RLoc+BRowSize-1,0) - &matVal(image,RLoc-1,0);
		for (CLoc=0; CLoc<setup->Img_Width_With_Boundary; CLoc++)  
		{
			ptr2[strideCur] = *ptr2 - *ptr1 + ptr1[stridePrev];
			ptr2++;
			ptr1++;
		}
	}
	
 	for (RLoc=0; RLoc<maxRows;RLoc++)  {
		ptr2 = &imVal(tmpProj, RLoc, 0);
		col = BColSize;
		sum = 0;

		while (col--) 
			sum += *(ptr2++);
		matVal(dcProj,RLoc,0) = sum;

		ptr2 = &matVal(tmpProj,RLoc,0);
		ptr3 = &matVal(dcProj,RLoc,0);
		for (CLoc=1; CLoc<maxCols; CLoc++)
		{
			ptr3[1] = *ptr3 - *ptr2 + ptr2[BColSize];
			ptr3++;
			ptr2++;
		}
	}
}


__inline void projDiffWHDC_Norm(GCKSetup *setup, Diff_Image *image, Matrix *dcProj, Matrix *tmpProj, int BRowSize, int BColSize) {


	int16 *ptr1; 
	int32 *ptr2, *ptr3;
	u_int16 col;
	int32 sum;

	u_int16 RLoc, CLoc;
	u_int16 maxCols = setup->ImgProj_Width;
	u_int16 maxRows = setup->ImgProj_Height;
	int stridePrev, strideCur;

	memset(&matVal(tmpProj,0,0), 0, sizeof(int32)*setup->Img_Width_With_Boundary);
	for (RLoc=0; RLoc<BRowSize; RLoc++)
	{
		ptr1 = &imVal(image, 0, 0);
		ptr2 = &matVal(tmpProj,RLoc,0);
		CLoc = setup->Img_Width_With_Boundary;
		while(CLoc--)
			*(ptr2++) += *(ptr1++);
	}


	for (RLoc=1; RLoc<maxRows; RLoc++)
	{
		ptr2 = &matVal(tmpProj,RLoc-1,0);
		strideCur = &matVal(tmpProj,RLoc,0) - &matVal(tmpProj,RLoc-1,0);
		ptr1 = &imVal(image,RLoc-1,0);
		stridePrev = &matVal(image,RLoc+BRowSize-1,0) - &matVal(image,RLoc-1,0);
		for (CLoc=0; CLoc<setup->Img_Width_With_Boundary; CLoc++)  
		{
			ptr2[strideCur] = *ptr2 - *ptr1 + ptr1[stridePrev];
			ptr2++;
			ptr1++;
		}
	}
	
 	for (RLoc=0; RLoc<maxRows;RLoc++)  {
		ptr2 = &imVal(tmpProj, RLoc, 0);
		col = BColSize;
		sum = 0;

		while (col--) 
			sum += *(ptr2++);
		matVal(dcProj,RLoc,0) = sum;

		ptr2 = &matVal(tmpProj,RLoc,0);
		ptr3 = &matVal(dcProj,RLoc,0);
		for (CLoc=1; CLoc<maxCols; CLoc++)
		{
#if (NORM_MEASURE==CHOICE_SSD)
			ptr3[1] = (*ptr3 - *ptr2 + ptr2[BColSize]);
#else
			ptr3[1] = (*ptr3 - *ptr2 + ptr2[BColSize]);
#endif
			ptr3++;
			ptr2++;
		}
	}
/* 	for (RLoc=0; RLoc<maxRows;RLoc++)  {
		matVal(dcProj,RLoc,0) >>= setup->LogSize;
		ptr3 = &matVal(dcProj,RLoc,1);
		for (CLoc=1; CLoc<maxCols; CLoc++)
		{
			*ptr3  >>= setup->LogSize;
//			if (*ptr3 < 0) 
//				(*ptr3)++;
			ptr3++;
		}
	}*/
}
/******************************************************************************
 * Compute x(i,j)-x(i+k,j)											          *
 *										                                      *
 ******************************************************************************/
__inline void CalcImageDiff(GCKSetup *setup, Image *image, Diff_Image *diff_image)
{
	u_int32 i, j;
	u_int8 *Souce_ptr;
	int16 *diff_ptr;
	Souce_ptr = &imVal(image, 0, 0);
	diff_ptr = &imVal(diff_image, 0, 0);
	for (i = 0; i < setup->ImgProj_Height; i++)
		for (j = 0; j < setup->Img_Width_With_Boundary; j++)
		{
			*(diff_ptr)=*(Souce_ptr)-Souce_ptr[setup->Img_Width_With_Boundary*BLOCK_SIZE_IMG];
			Souce_ptr++;
			diff_ptr++;
		}
}

__inline void CalcImageDiff2(GCKSetup *setup, Image *image, Diff_Image *diff_image)
{
	u_int32 i, j;
	u_int8 *Src_ptr;
	int16 *diff_ptr;
//	int32 diff1;
	Src_ptr = &imVal(image, 0, 0);
	diff_ptr = &imVal(diff_image, 0, 0);
	for (i = 0; i < setup->Img_Height_With_Boundary; i++)
	{
/*		Src_ptr = &imVal(image, i, 0);
		diff_ptr = &imVal(diff_image, i, 0);*/
		for (j = 0; j < setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG; j++)
		{
			*(diff_ptr)= (*(Src_ptr)-Src_ptr[BLOCK_SIZE_IMG]);
			Src_ptr++;
			diff_ptr++;
		}
		Src_ptr += BLOCK_SIZE_IMG;
		diff_ptr += BLOCK_SIZE_IMG;
	}
}

/* This is easier to understand Wanli's Algorithm for computing four WHT values in one row*/
__inline void WHTInOneRowG4_SLOW(GCKSetup *setup, Matrix **prevImageProj, Matrix * tProj, int startRow, int startCol)
{
//	static char ReferIdx[4] = {0, 2, 1, 3};
	Matrix *Proj0;
	Matrix *Proj1;
	Matrix *Proj2;
	Matrix *Proj3;
	int row, col;
	const int offset = BLOCK_SIZE_IMG>>2;
	u_int16 maxCols;
	u_int16 maxRows;
	int Order0, Order1, Order2, Order3;
	int numInGroup = 4;
	int32 sign = startCol & 4;

	Order0 = FreqOrder[startRow][startCol];
	Order1 = FreqOrder[startRow][startCol+1];
	Order2 = FreqOrder[startRow][startCol+2];
	Order3 = FreqOrder[startRow][startCol+3];
	if (0 == sign)
	{
		Proj0 = prevImageProj[Order0];
		Proj1 = prevImageProj[Order1];
		Proj2 = prevImageProj[Order2];
		Proj3 = prevImageProj[Order3];
	}
	else
	{
		Proj3 = prevImageProj[Order0];
		Proj2 = prevImageProj[Order1];
		Proj1 = prevImageProj[Order2];
		Proj0 = prevImageProj[Order3];
	}

		
	maxCols = setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1;
	maxRows = setup->ImgProj_Height;
	maxCols -= ((BLOCK_SIZE_IMG>>1))-offset;
	for (row=BLOCK_SIZE_IMG>>1; row < maxRows; row++)
	{
		for (col=0; col < maxCols; col++)
		{
			register int32 tmp0 = matVal(tProj,row,col);
			matVal(Proj0,row,col+offset) = matVal(Proj0,row,col) - tmp0;
			matVal(Proj1,row,col+offset) = tmp0 - matVal(Proj2,row,col);
			matVal(Proj2,row,col+offset) = matVal(Proj1,row,col) - tmp0;
			matVal(Proj3,row,col+offset) = tmp0 - matVal(Proj3,row,col);
		}
	}
}



void WHTInOneRowG4(GCKSetup *setup, Matrix **prevImageProj, Matrix * tProj, int startRow, int startCol)
{
	 int32 *Ptr;
	register int col;
	int row;
	int pos;
	const int offset = setup->offset;
	const int BlkSizeBy2 = setup->BlkSizeBy2;
	const int32 Cols = setup->Cols;
	const int32 maxCols = setup->maxCols;
	const int32 maxRows = setup->maxRows;
	const int32 ProjNum = FreqOrder2[startRow][startCol];
	const int32 Stride = StrideMtx[ProjNum];
	const int32 StrideMul3 = Stride3Mtx[ProjNum];
	int32 Stride2;
	int32 Stridet = &matVal(tProj,0,0) - &matVal(prevImageProj[0], 0,0);
	Ptr = &matVal(prevImageProj[0], BlkSizeBy2+BLOCK_SIZE_IMG,offset);
	row = 0;
	col = 0;	
	Stride2 = Stride<<1;
	pos = 0;
	for (row=0; row<maxRows; row++)
	{	
		for (col = 0; col<maxCols; col++) {
			// pos = row*Cols+col;
			register int32 tmp0 = Ptr[Stridet+pos]; //Obtain the t
			// Use the t to obtain four projection values using 1 add/sub per projection value
			Ptr[pos+offset] = Ptr[pos] - tmp0;
			Ptr[Stride+pos+offset] = tmp0 - Ptr[Stride2+pos];
			Ptr[Stride2+pos+offset] = Ptr[Stride+pos] - tmp0;
			Ptr[StrideMul3+pos+offset] = tmp0 - Ptr[StrideMul3+pos];
			pos++;
 		} 
		pos+=BlkSizeBy2;
	}
}

__inline void WHTInOneColG4(GCKSetup *setup, Matrix **prevImageProj, Matrix * tProj, int startRow, int startCol)
{	register int32 *ptr0, *ptr1, *ptr2, *ptr3;
	register int32 *ptrt;
	register int col;
	int row;
	const int offset = BLOCK_SIZE_IMG>>2;
	int32 size2;
	int strideCur;
	int32 sign = startRow & 4;
	u_int16 maxCols;
	u_int16 maxRows;
	maxCols = setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1;
	strideCur = maxCols*offset;
	if (0 != sign)
	{
		ptr0 = &matVal(prevImageProj[FreqOrder[startRow+3][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
		ptr1 = &matVal(prevImageProj[FreqOrder[startRow+2][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
		ptr2 = &matVal(prevImageProj[FreqOrder[startRow+1][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
		ptr3 = &matVal(prevImageProj[FreqOrder[startRow][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
	}
	else
	{
		ptr0 = &matVal(prevImageProj[FreqOrder[startRow][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
		ptr1 = &matVal(prevImageProj[FreqOrder[startRow+1][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
		ptr2 = &matVal(prevImageProj[FreqOrder[startRow+2][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
		ptr3 = &matVal(prevImageProj[FreqOrder[startRow+3][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
	}
	size2 = sizeof(int32)*offset*maxCols;
	ptrt = &matVal(tProj,(BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
	maxRows = setup->Img_Height_With_Boundary-setup->Block_size_pat+1-offset;
	row = (BLOCK_SIZE_IMG>>1)-offset;
	col = BOUNDARY_SIZE_IMG;	

	while (row<maxRows)
	{
		while (col<maxCols) {
			const int32 tmp0 = *(ptrt);
			ptr0[strideCur] = *(ptr0) - tmp0;
			ptr1[strideCur] = tmp0 - *ptr2;
			ptr2[strideCur] = *(ptr1) - tmp0;
			ptr3[strideCur] = tmp0 - *(ptr3);
			ptrt++;
			ptr0++;
			ptr1++;
			ptr2++;
			ptr3++;
			col++;
		} 
		ptr0 += BOUNDARY_SIZE_IMG;
		ptr1 += BOUNDARY_SIZE_IMG;
		ptr2 += BOUNDARY_SIZE_IMG;
		ptr3 += BOUNDARY_SIZE_IMG;
		ptrt += BOUNDARY_SIZE_IMG;
		col = BOUNDARY_SIZE_IMG;
		row++;
	}
}



/******************************************************************************
 * Notifies the setup on the current image and projects it.					  *
 ******************************************************************************/

int  tot_time=0;
extern int32 FreqGroup[64][64];
//------------ Compute GCK for pattern  ------------
void setPatternGCK(GCKSetup *setup, Image **image) {
	int32 curBaseNum, PatStartIdx;
	int ProjValue_Pat;
	u_int32  prevBaseNum, byRow, curVecNum, prevVecNum;
	int32 sign, offset;
	
	const int32 PatIdx = 0;
	copyImageWithBoundary(image[PatIdx], setup->curImage, setup->Boundary_Size_Pat);

	PatStartIdx = PatIdx*(MAX_BASES+MAX_BASES/4);
	projWHDC_Pattern(setup, setup->curImage, setup->curImageProj[0], setup->colsProj);
	ProjValue_Pat = matVal(setup->curImageProj[0], setup->Boundary_Size_Pat, setup->Boundary_Size_Pat);
	PatternWHTCoef[0] = ProjValue_Pat;
	
	// calculate the other projections
	curBaseNum = 1;
	while (curBaseNum < setup->Bases_Num) {
		
		int PrevBasePos;
		int CurBasePos = curBaseNum;

		prevBaseNum = matVal(setup->baseVectorsOrder, curBaseNum, 2);
		PrevBasePos = prevBaseNum;
		CurBasePos = CurBasePos;

#ifdef MEMSAVE_WHT
		if (setup->AlgFlag = CHOICE_WANLI_FWHT)
		{
			if ( ((CurBasePos&15) == 3) || ((CurBasePos&15) == 12) ) // if (CurBasePos%16)==0
			{
				switch(CurBasePos)
				{
				case 3:
					CurBasePos = 5+0;
					break;
				case 12:
					CurBasePos = 5+1;
					break;
				case 28:
					CurBasePos = 5+2;
					break;
				case 35:
					CurBasePos = 5+3;
					break;
				case 40:
					CurBasePos = 5+4;
					break;
				case 76:
					CurBasePos = 5+5;
					break;
				case 83:
					CurBasePos = 5+6;
					break;
				default:
					CurBasePos = CurBasePos%5;
				}
			}
			else
				CurBasePos = CurBasePos%5;
			if ( ((PrevBasePos&15) == 3) || ((PrevBasePos&15) == 12) ) // if (PrevBasePos%16)==0
			{
				switch(PrevBasePos)
				{
				case 3:
					PrevBasePos = 5+0;
					break;
				case 12:
					PrevBasePos = 5+1;
					break;
				case 28:
					PrevBasePos = 5+2;
					break;
				case 35:
					PrevBasePos = 5+3;
					break;
				case 40:
					PrevBasePos = 5+4;
					break;
				case 76:
					PrevBasePos = 5+5;
					break;
				case 83:
					PrevBasePos = 5+6;
					break;
				default:
					PrevBasePos = PrevBasePos%5;
				}
			}
			else
				PrevBasePos = PrevBasePos%5;
		}
		else
		{
			PrevBasePos = PrevBasePos %4;
			CurBasePos = CurBasePos%4;
		}
#endif


		if (matVal(setup->baseVectorsOrder,curBaseNum,0) == matVal(setup->baseVectorsOrder,prevBaseNum,0)) {
			byRow = 0;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,1);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,1);
		}
		else  {
			byRow = 1;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,0);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,0);
		}

		calcGCKOffset(&offset, &sign, setup->baseVectors, curVecNum, prevVecNum);
		offset >>= (SCALE-1);
	
		if (byRow)
			singleWHProjByRow_Pattern(setup, setup->curImageProj[PrevBasePos], setup->curImageProj[CurBasePos],
							  offset, sign);
		else
			singleWHProjByCol_Pattern(setup, setup->curImageProj[PrevBasePos], setup->curImageProj[CurBasePos],
							  offset, sign);
		ProjValue_Pat = matVal(setup->curImageProj[CurBasePos], setup->Boundary_Size_Pat, setup->Boundary_Size_Pat);
		PatternWHTCoef[curBaseNum] = ProjValue_Pat;
		curBaseNum++;
	}
	
}

// Compute GCK by FWHT algorithm
// Wanli Ouyang and Wai-Kuen Cham, Fast algorithm for Walsh Hadamard transform on sliding windows. TPAMI, 32(1):165�C171, Jan. 2010.
int setIncImageGCK_FWHT(GCKSetup *setup, int BaseStart) {

	int16 sign;
	int ProjRowPos = matVal(setup->baseVectorsOrder,BaseStart,0);
	int ProjColPos = matVal(setup->baseVectorsOrder,BaseStart,1)>>2;
	int32 ProjNum= FreqOrder2[ProjRowPos][ProjColPos<<2];
	int curIdx, prevIdx;
	int16 maxCols, maxRows;
	int32 Cols = setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1;
	int32 toffsetStride;
	const int16 BlkSizeBy2 = setup->BlkSizeBy2;
	int32 *currentProjPtr, *prevProjPtr;
	int32 Stride;
	int32 ComputeChoice = BaseStart&3; //BaseStart%4

	curIdx = setup->tIdx[ProjRowPos][ProjColPos];
	sign = MtxSign[BaseStart];

	if(BaseStart==20)
		currentProjPtr = 0;

	currentProjPtr = &matVal(setup->prevImageProj[FWHTPos[curIdx-4]+4],0,0);
	currentProjPtr += setup->StartPos;
	Stride = StrideMtx[ProjNum];
	//  Note that the paper is writen for Dyadic ordered WHT, here we have sequency ordered WHT
	//  Thus the followings in this if branch is used for handling this difference
	if (Stride>0)
		ProjNum = 0;
	else
	{
		ProjNum = 3;
		ComputeChoice = 3-ComputeChoice;
	}

	maxCols = setup->maxCols;
	maxRows = setup->maxRows+(BLOCK_SIZE_IMG);

	if ((BaseStart&3)==0)
	{
		const int16 sign = MtxSign[BaseStart];
		int16 row;
		if ( ProjColPos == 0)
		{
			prevIdx = setup->tIdx[ProjRowPos-1][ProjColPos];
			toffsetStride = MtxOffset[BaseStart] * Cols;
		}
		else 
		{
			prevIdx = setup->tIdx[ProjRowPos][ProjColPos-1];
			toffsetStride = MtxOffset[BaseStart];
		}

			prevProjPtr = &matVal(setup->prevImageProj[FWHTPos[prevIdx-4]+4],0,0);
			prevProjPtr += setup->StartPos;
			if (sign == 0)
				for (row=0; row<maxRows; row++)
				{
					register int16 col;
					for (col = 0; col<maxCols; col++) {
						// t in (9) of Ouyang's paper is obtained now by the GCK algorithm
						currentProjPtr[row*Cols+col] = prevProjPtr[row*Cols+col-toffsetStride]-currentProjPtr[row*Cols+col-toffsetStride]-prevProjPtr[row*Cols+col]; 
					} 
				}
			else
				for (row=0; row<maxRows; row++)
				{
					register int16 col;
					for (col = 0; col<maxCols; col++) {
						register int32 tmp0; 
						// t in (9) of Ouyang's paper is obtained now by the GCK algorithm
						tmp0 = currentProjPtr[row*Cols+col-toffsetStride] - prevProjPtr[row*Cols+col-toffsetStride]-prevProjPtr[row*Cols+col];
						currentProjPtr[row*Cols+col] = tmp0; 
					} 
				}
	}
	
	{
		const int8 offset = setup->offset;
		int StarPos2 = matCols(setup->prevImageProj[ProjNum]) * (BOUNDARY_SIZE_IMG-BLOCK_SIZE_IMG/2);
		int16 row;
		int32 * ptr0 = &matVal(setup->prevImageProj[ProjNum], 0,0)+setup->StartPos+StarPos2;
		int32 * ptr1 = ptr0+Stride;
		int32 * ptr2 = ptr1+Stride;
		int32 * ptr3 = ptr2+Stride;
		currentProjPtr+=StarPos2;
		maxRows -= BOUNDARY_SIZE_IMG-BLOCK_SIZE_IMG/2;
		switch(ComputeChoice)
		{
		case 0:
			for (row=0; row<maxRows; row++)
			{
				register int16 col;
				for (col = 0; col<maxCols; col++) {
					// Compute the projection values from t using (11) in Ouyang's paper
					ptr0[row*Cols+col+offset] = ptr0[row*Cols+col] - currentProjPtr[row*Cols+col];
				} 
			}
			// One projection value computed
			return 1;
		case 1:
		case 2:
			for (row=0; row<maxRows; row++)
			{
				register int16 col;
				for (col = 0; col<maxCols; col++) {
					register int32 tmp0; 
					int32 val1, val2;
					// the t 
					tmp0 = currentProjPtr[row*Cols+col];
					// Compute the projection values from t using (11) in Ouyang's paper
					val1 = tmp0 - ptr2[row*Cols+col];
					val2 = ptr1[row*Cols+col] - tmp0;
					ptr1[row*Cols+col+offset] = val1;
					ptr2[row*Cols+col+offset] = val2;
				} 
			}
			// Two projection values computed at the same time
			return 2;
		case 3:
			for (row=0; row<maxRows; row++)
			{
				register int16 col;
				for (col = 0; col<maxCols; col++) {
					int32 val3;
					// Compute the projection values from t using (11) in Ouyang's paper
					val3 = currentProjPtr[row*Cols+col] - ptr3[row*Cols+col];
					ptr3[row*Cols+col+offset] = val3;
				} 
			}
			// One projection value computed
			return 1;
		default :
			printf("This is not supported in FWHT!\n");
			return 10000;
		}
	}
}


// Use FWHT algorithm to compute the 0th WHT basis (the dc component)
// Wanli Ouyang and Wai-Kuen Cham, Fast algorithm for Walsh Hadamard transform on sliding windows. TPAMI, 32(1):165�C171, Jan. 2010.
int setIncImageGCK_FWHT_Basis0(GCKSetup *setup) {

	int16 sign;
	const int BaseStart=0;
	int ProjRowPos = matVal(setup->baseVectorsOrder,BaseStart,0);
	int ProjColPos = matVal(setup->baseVectorsOrder,BaseStart,1)>>2;
	int curIdx;
	int16 maxCols, maxRows;
	int32 Cols = setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1;
	const int16 BlkSizeBy2 = setup->BlkSizeBy2;
	int32 *currentProjPtr;
	int16 row;
	const int8 offset = setup->offset;
	int32 * ptr0 = &matVal(setup->prevImageProj[0], 0,0)+setup->StartPos;

	curIdx = setup->tIdx[ProjRowPos][ProjColPos];
	sign = MtxSign[BaseStart];
	currentProjPtr = &matVal(setup->prevImageProj[curIdx],0,0)+setup->StartPos;
	
		maxCols = setup->maxCols;
		maxRows = setup->maxRows+(BLOCK_SIZE_IMG);
	
			for (row=0; row<maxRows; row++)
			{
				register int16 col;
				for (col = 0; col<maxCols; col++) {
					// Compute the projection values from t
					ptr0[row*Cols+col+offset] = ptr0[row*Cols+col] - currentProjPtr[row*Cols+col];
				} 
			}
			return 1;

}

// Pad projection values boundary with 0
void setBoundaryZerosProjs(GCKSetup *setup, Matrix **prvImgProj, basisT BaseStart, basisT BaseEnd)
{
	basisT i;
	u_int32 j;
 	Matrix *proj;
	for (i=BaseStart; i<BaseEnd; i++)
	{
		const int offset = BLOCK_SIZE_IMG>>1;
		const int32 size1 = sizeof(int32)*offset;
		const cols = (setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1);
		const int32 size2 = size1*cols;
		int32 *p;
		proj = prvImgProj[i];
		memset(&matVal(proj,0,0), 0, size2);
		p = &matVal(proj,offset,0);
		for (j=offset; j<setup->Img_Height_With_Boundary-setup->Block_size_pat+1; j++, p+=cols)
			memset(p, 0, size1);		  
	}
}

// G. Ben-Artz, H. Hel-Or, and Y. Hel-Or. The Gray-code filter kernels. TPAMI, 29(3):382�C393, Mar. 2007.
// Compute GCK by GCK algorithm proposed by G. Ben-Artz, Hel-Or and Hel-Or
void setIncImageGCK(GCKSetup *setup, int BaseStart, int BaseEnd) {

	int32 curBaseNum, prevBaseNum, byRow, curVecNum, prevVecNum, offset;
	int32 sign;
	//------------ For image  ------------
	// calculate the projections other than dc
	curBaseNum = BaseStart;
	while (curBaseNum < BaseEnd) 
	{
		int PrevBasePos, CurBasePos;
		prevBaseNum = matVal(setup->baseVectorsOrder, curBaseNum, 2);

		if (matVal(setup->baseVectorsOrder,curBaseNum,0) == matVal(setup->baseVectorsOrder,prevBaseNum,0)) {
			byRow = 0;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,1);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,1);
		}
		else  {
			byRow = 1;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,0);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,0);
		}

		calcGCKOffset(&offset, &sign, setup->baseVectors, curVecNum, prevVecNum);
		PrevBasePos = prevBaseNum;
		CurBasePos = curBaseNum;

#ifdef MEMSAVE_WHT
		// For Snake order
		PrevBasePos = PrevBasePos % 4;
		CurBasePos = CurBasePos % 4;
#endif
		if (byRow)
			singleWHProjByRow(setup, setup->prevImageProj[PrevBasePos], setup->prevImageProj[CurBasePos],
							  offset, sign);
		else
			singleWHProjByCol(setup, setup->prevImageProj[PrevBasePos], setup->prevImageProj[CurBasePos],
							  offset, sign);
			curBaseNum++;
	}
}


int32 matchesOffset[1280*960*4];
distanceT matchesDist[1280*960*4];
extern u_int32 SqrDiff[2*MAX_DIFF+1];
void ComputeOffset(GCKSetup *setup, Matrix *basesVectors)
{
	int32 *pCur;
	int32 stride, curVecNum, curBaseNum;
	register int32 rows = matRows(basesVectors);
	register u_int8 i;
	for (curVecNum = 1; curVecNum < BLOCK_SIZE_IMG; curVecNum++) 
	{
		pCur = &matVal(basesVectors, curVecNum, 0);
		stride = &matVal(basesVectors, curVecNum-1, 0) - pCur;
		for (i=0; (i<rows) && (*pCur== pCur[stride]); i++)
			pCur++;

		 MtxOffsetTmp[curVecNum] = i;
	}
	for (curBaseNum=0; curBaseNum<MAX_BASES; curBaseNum++)
	{
		int col, row;
		row = matVal(setup->baseVectorsOrder,curBaseNum,0);
		col = matVal(setup->baseVectorsOrder,curBaseNum,1)>>2;
		if ( (row+col) != 0)
		{
			if ( col == 0)
			{
				MtxOffset[curBaseNum] = MtxOffsetTmp[row];
				MtxSign[curBaseNum] = (matVal(setup->baseVectors, row-1, MtxOffset[curBaseNum]) ==  -1);
			}
			else 
			{
				MtxSign[curBaseNum] = (matVal(setup->baseVectors, col-1, MtxOffsetTmp[col]) ==  -1);	
				MtxOffset[curBaseNum] = MtxOffsetTmp[col]>>2;
			}
		}//end of if ( (row1+col1) != 0)
	}
}

//u_int8 computed[1024];

// PMGCK for Small pattern (modified from motionEstimationGCKSP of Hel-Or and Hel-Or)
void PMGCKSP(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases) {
	u_int16 maxValidX = setup->Img_Width_With_Boundary - BLOCK_SIZE_IMG;	// max valid coordinates for the
	u_int16 maxValidY = setup->Img_Height_With_Boundary - BLOCK_SIZE_IMG;	// upper left corner of candidate blocks
	int32 curBaseNum;
	int32 *sourcePtr, *initsourcePtr;
	u_int32 *destPtr , *initDestPtr, *matchesDistPtr;
	u_int16 sourceDif;
	u_int16 destDif, initDestDif;
	u_int16 cols;
	u_int16 numOfRows, initNumOfRows;
	u_int16 initNumOfCols;
	int32 startBase;
	u_int32 thresholdDistT;
	u_int8 *sourcePtrUint8;
	int32 suspectedCount, suspectedTotal, Count2;
	Matrix_Dist *distMat = setup->distances;
	u_int32 distMatSize = matSize(distMat) * sizeof(int32);

	const float OpsPerProj= (float) 2*maxValidX*maxValidY;
	float OpsProj;
	const float N = (float) setup->Block_size_pat*setup->Block_size_pat;
	float OpsSaved;

	int32 i, bestSadIndex = 0;
	u_int32 ssd;
	u_int32 threshold = setup->Threshold*setup->Block_size_pat*setup->Block_size_pat;

	const int32 PatIdx = 0;
	int32 BasesComputed;
	Matrix *prevImageProj;

	// -------------- Rejection Step ---------------
	matchesDistPtr = (int*) matchesDist;

	if (WANT_DC) 
		startBase = 0;
	else
		startBase = 1;
	copyImageWithBoundary(pImage, setup->prevImage, BOUNDARY_SIZE_IMG);
	BasesComputed=1;

#ifdef SHOW_MY_STATS	
		printf("Warning: collecting Hel-Or GCK stats...\n");
#endif

	projWHDC(setup, setup->prevImage, setup->prevImageProj[0], setup->colsProj);
	BasesComputed=1;

	initNumOfRows = setup->Img_Heihgt - BLOCK_SIZE_IMG + 1; 
	initNumOfCols = setup->Img_Width - BLOCK_SIZE_IMG + 1;
	initDestPtr = (u_int32*) distMat->cellValues;
	initDestDif = matCols(distMat) - initNumOfCols;
	memset(distMat->cellValues, 0, distMatSize);	// make distance matrix zeros
	sourceDif = matCols(setup->prevImageProj[0]) - initNumOfCols;
	destDif = initDestDif;
	suspectedTotal = suspectedCount = initNumOfCols*initNumOfRows;
#ifdef TRACK_CANDIDATES
		setup->NumCand[0] = suspectedCount;
#endif
	Count2 = (int) (suspectedCount * setup->Percent);
	//for each basis
	for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++) {
		u_int32 tmp;
		int32 ProjValue_Pat;
		int32 FlagBreak = 0;
		int CurBasePos = curBaseNum;
#ifdef MEMSAVE_WHT
		CurBasePos = CurBasePos%4; //For snake order
#endif
		suspectedCount = 0;
		prevImageProj = setup->prevImageProj[CurBasePos];
		ProjValue_Pat = PatternWHTCoef[curBaseNum]; //Projection value of Pattern
		// Because of padding, find the start position of projection value for position (0,0)
		initsourcePtr = prevImageProj->cellValues + matCols(prevImageProj) * BOUNDARY_SIZE_IMG + BOUNDARY_SIZE_IMG;
		sourcePtr = initsourcePtr;

		if (curBaseNum == startBase)
		{
		// For the 1st projection (DC)
			destPtr = initDestPtr;
			numOfRows = initNumOfRows; 
			while (numOfRows--) {
				cols = initNumOfCols;
				while (cols--) {
					tmp = abs(ProjValue_Pat - *sourcePtr); //Calculate absolute difference between pattern projection and window projection
					if ( tmp < threshold) // |x-y| < T1  <=> (x-y) * (x-y) < T1*T1, used by PWHT. And we follow this idea for PGCK and FWHT
					{
						//Enter here if cannot prune this candiate
						tmp = tmp*tmp; //Calculate lower bound
						*destPtr = tmp; // Store the lowerbound
						matchesDistPtr[suspectedCount] = *destPtr; //Store the lower bound of the candiate
						matchesOffset[suspectedCount++] = sourcePtr - initsourcePtr; //Store the offset of the candiate to initsourcePtr
/*		Debugging code
						ypos = matchesOffset[suspectedCount-1] / matCols(prevImageProj);
						xpos = matchesOffset[suspectedCount-1] - matCols(prevImageProj) * ypos;
						if ((ypos==7)&&(xpos==18))
							printf("here!\n");
*/					}
					sourcePtr++; //Next candidate
					destPtr++;
				}
				//Candidate at the next row
				sourcePtr += sourceDif;
				destPtr += destDif;
			}
			//Threshold is changed beause of the "|x-y| < T1  <=> (x-y) * (x-y) < T1*T1" thing
			// Previously, it is T1, now it is T1*T1.
			thresholdDistT = (int32) threshold;
#if (NORM_MEASURE==CHOICE_SAD)
			thresholdDistT *= setup->Block_size_pat;
#endif
			thresholdDistT *= thresholdDistT;
		}
		else
		{
		// For the projection other than 1st one (DC)
			for (i = 0; i<suspectedTotal; i++)//For suspectedTotal remaining candidates
			{
				int itmp;
				sourcePtr = initsourcePtr + matchesOffset[i]; //Find the pointer to the remaining candidate
				itmp = ProjValue_Pat - *sourcePtr; //Calculate difference
				tmp = itmp*itmp;	//Square of difference
				matchesDistPtr[i] += tmp; //Lower bound is computed here
				if (matchesDistPtr[i] < thresholdDistT) //Mismatched window?
				{ //Mismatched window!
					matchesDistPtr[suspectedCount] = matchesDistPtr[i]; //Store the lower bound of the candiate
					matchesOffset[suspectedCount++] = matchesOffset[i]; //Store the offset of the candiate to initsourcePtr
				} 
			}
		}
#ifdef SHOW_MY_STATS	
		printf("suspectedTotal: %d for %d projections, Ratios: %f\n", suspectedCount, curBaseNum, (float)suspectedCount/suspectedTotal);
#endif
#ifdef TRACK_CANDIDATES
		setup->NumCand[curBaseNum+1] = suspectedCount;
#endif

		//---------Relaed to early termination---------
#ifdef ADAPTIVE_TERMINATION
		// This is the code related to the Section "New termination condition based on computational complexity analysis" in the following paper
		// Wanli Ouyang, Federico Tombari, Stefano Mattoccia, Luigi Di Stefano and Wai-Kuen Cham, "Performance Evaluation of Full Search Equivalent Pattern Matching Algorithms ", IEEE Trans. Pattern Analysis and machine Intelligence(TPAMI), Minor revision.
		//examine the operation saved by doing this loop of projection based pattern matching		
		//suspectedCount: candidates after this loop;  suspectedTotal: candidates before this loop
		if (curBaseNum>3)
			OpsProj= OpsPerProj;
		else
			OpsProj= OpsPerProj/2;
		OpsSaved = (float) (OPS_FS*N*(suspectedTotal-suspectedCount) - (OpsProj+OPS_CHECK_REJECTION*suspectedCount));
		FlagBreak = (OpsSaved < 0) || ((OpsProj+OPS_CHECK_REJECTION*suspectedCount) > (OPS_FS2*N*suspectedCount));
#endif
		suspectedTotal = suspectedCount;
#ifndef ADAPTIVE_TERMINATION
		// Previous termination strategy used in PWHT algorithm and borrowed here
		FlagBreak = FlagBreak ||(suspectedTotal < Count2);
#endif

		if (FlagBreak) //Terminate the rejection step??
		{
			 //Terminate the rejection step!
			curBaseNum++;
			break;
		}
		//---------Relaed to early termination---------

		// compute projection values when more are needed
		if ( (BasesComputed - curBaseNum ==  1) && (BasesComputed<setup->Bases_Num) )
		{
			setIncImageGCK(setup, BasesComputed, BasesComputed+1);
			BasesComputed++; //one more projection computed
		}
	}//for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++)


// --------------------- FS Step --------------------
#if (NORM_MEASURE==CHOICE_SSD)
	threshold *= setup->Threshold;
#endif
	suspectedCount = 0;
	sourcePtrUint8 = imPixels(setup->curImage) + matCols(setup->curImage) * setup->Boundary_Size_Pat + setup->Boundary_Size_Pat;
	sourceDif = imCols(setup->curImage) - BLOCK_SIZE_IMG;
	prevImageProj = setup->prevImageProj[0];
	destDif = imCols(setup->prevImage) - BLOCK_SIZE_IMG;
#ifdef TRACK_CANDIDATES
	for (i=curBaseNum; i<setup->Bases_Num; i++) setup->NumCand[i] = 0;
	setup->NumCand[setup->Bases_Num] = suspectedTotal;
#endif
	i = 0;
	while (i<suspectedTotal)
	{
		int xpos, ypos;
		int offsetNow = matchesOffset[i];// + initNumOfCols;
		i++;
		//Position of the candidate window
		ypos = offsetNow / matCols(prevImageProj);
		xpos = offsetNow - matCols(prevImageProj) * ypos;
		//Calculate SSD
#if (NORM_MEASURE==CHOICE_SSD)
		ssd = calcSSD2(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
#else
		ssd = calcSAD(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
#endif
		if (ssd < threshold)
		{
			// A matched window found!
			setup->match[suspectedCount] = ssd;
			setup->xmatch[suspectedCount] = ypos;
			setup->ymatch[suspectedCount] = xpos;
			suspectedCount++;
		}
	}
	setup->count = suspectedCount;
	setup->BasesComputed = curBaseNum;
}

// PMGCK for Small pattern, Ouyang's algorithm
void PMGCKSP_FWHT(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases) {
	u_int16 maxValidX = setup->Img_Width_With_Boundary - BLOCK_SIZE_IMG;	// max valid coordinates for the
	u_int16 maxValidY = setup->Img_Height_With_Boundary - BLOCK_SIZE_IMG;	// upper left corner of candidate blocks
	u_int8 curBaseNum;
	int32 *sourcePtr, *initsourcePtr;
	u_int32 *destPtr , *initDestPtr, *matchesDistPtr;
	u_int16 sourceDif;
	u_int16 destDif, initDestDif;
	u_int16 cols;
	u_int16 numOfRows, initNumOfRows;
	u_int16 initNumOfCols;
	int32 startBase;
	u_int8 *sourcePtrUint8;
	int32 suspectedCount, suspectedTotal, Count2;
	Matrix_Dist *distMat = setup->distances;
	u_int32 distMatSize = matSize(distMat) * sizeof(int32);
	float OpsProj;
	const float OpsPerProj= (float) (2.0*maxValidX*maxValidY);
	const float N= (float)setup->Block_size_pat*setup->Block_size_pat;
	float OpsSaved;

	int32 i, bestSadIndex = 0;
	u_int32 ssd;
	u_int32 threshold = setup->Threshold*setup->Block_size_pat*setup->Block_size_pat;
	u_int32 thresholdDistT;

	const int32 PatIdx = 0;
	int32 BasesComputed;
	Matrix *prevImageProj;

// -------------- Rejection Step ---------------
	matchesDistPtr =(u_int32*) matchesDist;
	if (WANT_DC) 
		startBase = 0;
	else
		startBase = 1;
#ifdef SHOW_MY_STATS	
		printf("Warning: collecting Wanli GCK stats...\n");
#endif
	copyImageWithBoundary(pImage, setup->prevImage, BOUNDARY_SIZE_IMG);

	// Calculate the differnce image
	CalcImageDiff2(setup, setup->prevImage, setup->diffImage);
	// Compute the DC for difference image, note the pattern size is now (BLOCK_SIZE_IMG, BLOCK_SIZE_IMG/4)
	projDiffWHDC(setup, setup->diffImage, setup->prevImageProj[4], setup->colsProj, BLOCK_SIZE_IMG, BLOCK_SIZE_IMG>>2);
	// Obtain the 0th WHT basis image
	setIncImageGCK_FWHT_Basis0(setup);
	// Now 1 basis computed
	BasesComputed=1;

	initNumOfRows = setup->Img_Heihgt - BLOCK_SIZE_IMG + 1; 
	initNumOfCols = setup->Img_Width - BLOCK_SIZE_IMG + 1;
	initDestPtr = (u_int32*) distMat->cellValues;
	initDestDif = matCols(distMat) - initNumOfCols;
	memset(distMat->cellValues, 0, distMatSize);	// make distance matrix zeros
	sourceDif = matCols(setup->prevImageProj[0]) - initNumOfCols;
	destDif = initDestDif;
	suspectedTotal = suspectedCount = initNumOfCols*initNumOfRows;
#ifdef TRACK_CANDIDATES
		setup->NumCand[0] = suspectedCount;
#endif
	Count2 = (int) (suspectedCount * setup->Percent);

	//for each basis
	for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++) {
		u_int32 tmp;
		int32 ProjValue_Pat;
		int32 FlagBreak = 0;
		int32 CurBasePos = curBaseNum&3;
		suspectedCount = 0;
		prevImageProj = setup->prevImageProj[CurBasePos];
		//Projection value of Pattern
		ProjValue_Pat = PatternWHTCoef[curBaseNum];
		// Because of padding, find the start position of projection value for position (0,0)
		initsourcePtr = prevImageProj->cellValues + matCols(prevImageProj) * BOUNDARY_SIZE_IMG + BOUNDARY_SIZE_IMG;
		sourcePtr = initsourcePtr;

		if (curBaseNum == startBase)
		{
			// At first time, try all of the canditate points
			// For the 1st projection, e.g. DC
			destPtr = initDestPtr;
			numOfRows = initNumOfRows; 
			while (numOfRows--) {// For all rows
				cols = initNumOfCols;
				while (cols--) { //For all cols
					tmp = abs(ProjValue_Pat - *sourcePtr);//Calculate absolute difference between pattern projection and window projection
					if (tmp < threshold)// |x-y| < T1  <=> (x-y) * (x-y) < T1*T1, used by PWHT. And we follow this idea for PGCK and FWHT
					{
						//Enter here if cannot prune this candiate
						tmp = tmp*tmp;	//Calculate lower bound
						*destPtr = tmp; // Store the lowerbound
						matchesDistPtr[suspectedCount] = *destPtr ; //Store the lower bound of the candiate
						matchesOffset[suspectedCount++] = sourcePtr - initsourcePtr;//Store the offset of the candiate to initsourcePtr
					}
					//Next candidate
					sourcePtr++; 
					destPtr++;
				}						
				//Candidates at the next row
				sourcePtr += sourceDif; 
				destPtr += destDif;
			}
			//Threshold is changed beause of the "|x-y| < T1  <=> (x-y) * (x-y) < T1*T1" thing
			// Previously, it is T1, now it is T1*T1.
			thresholdDistT = (u_int32) threshold;
#if (NORM_MEASURE==CHOICE_SAD)
			thresholdDistT *= setup->Block_size_pat;
#endif
			thresholdDistT *= thresholdDistT;
		}
		else
		{
			// Later on, try canditate points that are not rejected before
			// For the projection other than 1st one (DC)
			for (i = 0; i<suspectedTotal; i++)//For suspectedTotal remaining candidates
			{
				//Find the pointer to the remaining candidate
				sourcePtr = initsourcePtr + matchesOffset[i];
				//Calculate difference
				tmp = abs (ProjValue_Pat - *sourcePtr);
				//Square of difference
				tmp = tmp*tmp;
				//Lower bound is computed here
				matchesDistPtr[i] += tmp;
				//Mismatched window?
				if (matchesDistPtr[i] < thresholdDistT)
				{//Mismatched window!
					//Store the lower bound of the candiate
					matchesDistPtr[suspectedCount] = matchesDistPtr[i]; 
					//Store the offset of the candiate to initsourcePtr
					matchesOffset[suspectedCount++] = matchesOffset[i]; 
				} 
			}
		}
#ifdef SHOW_MY_STATS	
		printf("suspectedTotal: %d for %d projections, Ratios: %f\n", suspectedCount, curBaseNum, (float)suspectedCount/suspectedTotal);
#endif
#ifdef TRACK_CANDIDATES
		setup->NumCand[curBaseNum+1] = suspectedCount;
#endif

#ifdef ADAPTIVE_TERMINATION
		// This is the code related to the Section "New termination condition based on computational complexity analysis" in the following paper
		// Wanli Ouyang, Federico Tombari, Stefano Mattoccia, Luigi Di Stefano and Wai-Kuen Cham, "Performance Evaluation of Full Search Equivalent Pattern Matching Algorithms ", IEEE Trans. Pattern Analysis and machine Intelligence(TPAMI), Minor revision.
		//examine the operation saved by doing this loop of projection based pattern matching		
		//suspectedCount: candidates after this loop;  suspectedTotal: candidates before this loop
		if (curBaseNum>3)
			OpsProj= OpsPerProj;
		else
			OpsProj= OpsPerProj/2;
		OpsSaved = (float) (OPS_FS*N*(suspectedTotal-suspectedCount) - (OpsProj+OPS_CHECK_REJECTION*suspectedCount));
		FlagBreak = (OpsSaved < 0) || ((OpsProj+OPS_CHECK_REJECTION*suspectedCount) > (OPS_FS2*N*suspectedCount));
#endif

		suspectedTotal = suspectedCount;
#ifndef ADAPTIVE_TERMINATION
		FlagBreak = FlagBreak ||(suspectedTotal < Count2);
#endif
		//To see if we should jump to directly computing the Euclidean distance
		if (FlagBreak)
		{
			curBaseNum++;
			break;
		}
		// compute projection values when more are needed
		if ( (BasesComputed - curBaseNum ==  1) && (BasesComputed<setup->Bases_Num) )
		{
			BasesComputed += setIncImageGCK_FWHT(setup, BasesComputed);
		}
	}//for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++)

// --------------------- FS Step --------------------
	suspectedCount = 0;
	sourcePtrUint8 = imPixels(setup->curImage) + matCols(setup->curImage) * setup->Boundary_Size_Pat + setup->Boundary_Size_Pat;
	sourceDif = imCols(setup->curImage) - BLOCK_SIZE_IMG;
	prevImageProj = setup->prevImageProj[0];
	destDif = imCols(setup->prevImage) - BLOCK_SIZE_IMG;
#if (NORM_MEASURE==CHOICE_SSD)
	threshold *= setup->Threshold;
#endif
#ifdef TRACK_CANDIDATES
	for (i=curBaseNum; i<setup->Bases_Num; i++) setup->NumCand[i] = 0;
	setup->NumCand[setup->Bases_Num] = suspectedTotal;
#endif
	i = 0;
	while (i<suspectedTotal)
	{
		int xpos, ypos;
		int offsetNow = matchesOffset[i];
		i++;
		//Position of the candidate window
		ypos = offsetNow / matCols(prevImageProj);
		xpos = offsetNow - matCols(prevImageProj) * ypos;
//		xpos = offsetNow % matCols(setup->prevImageProj[0]);
		//Calculate SSD
#if (NORM_MEASURE==CHOICE_SSD)
		ssd = calcSSD2(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
#else
		ssd = calcSAD(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
#endif
		if (ssd < threshold)
		{
			// A matched window found!
			setup->match[suspectedCount] = ssd;
			setup->xmatch[suspectedCount] = ypos;
			setup->ymatch[suspectedCount] = xpos;
			suspectedCount++;
		}
	}
	setup->count = suspectedCount;
	setup->BasesComputed = BasesComputed;
}

// PMGCK for large pattern, GCK algorithm
void PMGCKLP(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases) {
	u_int16 maxValidX = setup->Img_Width_With_Boundary - BLOCK_SIZE_IMG;	// max valid coordinates for the
	u_int16 maxValidY = setup->Img_Height_With_Boundary - BLOCK_SIZE_IMG;	// upper left corner of candidate blocks

	int32 curBaseNum;
	int32 *sourcePtr, *initsourcePtr;
	distanceT2 *destPtr , *initDestPtr, *matchesDistPtr;
	u_int16 sourceDif;
	u_int16 destDif, initDestDif;
	u_int16 cols;
	u_int16 numOfRows, initNumOfRows;
	u_int16 initNumOfCols;
	int32 startBase;
	u_int8 *sourcePtrUint8;
	int32 suspectedCount, suspectedTotal, Count2;

	Matrix_Dist *distMat = setup->distances;
	u_int32 distMatSize = matSize(distMat) * sizeof(distanceT2);

	int32 i, bestSadIndex = 0;
	u_int32 ssd;
	u_int32 threshold = (setup->Threshold*setup->Block_size_pat*setup->Block_size_pat) >> (setup->LogSize) ;

	const float OpsPerProj= (float) 2*maxValidX*maxValidY;
	float OpsProj;
	const float N= (float) setup->Block_size_pat*setup->Block_size_pat;
	float OpsSaved;

	const int32 PatIdx = 0;
	int32 BasesComputed;
	Matrix *prevImageProj;
	distanceT2 thresholdDistT;
#ifdef MY_DEBUG
	int32 CompareReturn;
#endif

// -------------- Rejection Step ---------------
	matchesDistPtr = (int*) matchesDist;
	if (WANT_DC) 
		startBase = 0;
	else
		startBase = 1;
	copyImageWithBoundary(pImage, setup->prevImage, BOUNDARY_SIZE_IMG);
#ifdef SHOW_MY_STATS	
		printf("Warning: collecting Hel-Or GCK stats...\n");
#endif
	projWHDC(setup, setup->prevImage, setup->prevImageProj[0], setup->colsProj);
	BasesComputed=1;

	initNumOfRows = setup->Img_Heihgt - BLOCK_SIZE_IMG + 1; 
	initNumOfCols = setup->Img_Width - BLOCK_SIZE_IMG + 1;
	initDestPtr = (int*) distMat->cellValues;
	initDestDif = matCols(distMat) - initNumOfCols;
	memset(distMat->cellValues, 0, distMatSize);	// make distance matrix zeros
	sourceDif = matCols(setup->prevImageProj[0]) - initNumOfCols;
	destDif = initDestDif;
	suspectedTotal = suspectedCount = initNumOfCols*initNumOfRows;
#ifdef TRACK_CANDIDATES
	setup->NumCand[0] = suspectedCount;
#endif
	Count2 = (int) (suspectedCount * setup->Percent);
	for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++) {
		distanceT2 tmp;
		int32 ProjValue_Pat, *pOffset;
		int32 FlagBreak = 0;
		distanceT2 *pDist; 
		int CurBasePos = curBaseNum;
#ifdef MEMSAVE_WHT
		CurBasePos = CurBasePos%4; //For snake order
#endif
		suspectedCount = 0;
		prevImageProj = setup->prevImageProj[CurBasePos];
		ProjValue_Pat = PatternWHTCoef[curBaseNum] >> (setup->LogSize) ;
		if (ProjValue_Pat<0) 
			ProjValue_Pat++;

		initsourcePtr = prevImageProj->cellValues + matCols(prevImageProj) * BOUNDARY_SIZE_IMG + BOUNDARY_SIZE_IMG;
		sourcePtr = initsourcePtr;

		// At first time, try all of the canditate points
		pDist = matchesDistPtr;
		pOffset = matchesOffset;
		if (curBaseNum == startBase)
		{
			int itmp;
			destPtr = initDestPtr;
			numOfRows = initNumOfRows; 
			while (numOfRows--) {
				cols = initNumOfCols;
				while (cols--) {
					itmp = ProjValue_Pat - (*sourcePtr >> setup->LogSize);
					tmp = abs(itmp);
					if ( (u_int32) tmp < threshold)
					{
						tmp = tmp*tmp;
						*destPtr += tmp;
						*pDist = *destPtr;
						*pOffset = sourcePtr - initsourcePtr;
						pDist++;
						pOffset++;
					}
					sourcePtr++;
					destPtr++;
				}						
				sourcePtr += sourceDif;
				destPtr += destDif;
			}
			suspectedCount = pDist - matchesDistPtr;
			thresholdDistT = (distanceT2) threshold;
#if (NORM_MEASURE==CHOICE_SAD)
			thresholdDistT *= setup->Block_size_pat;
#endif
			thresholdDistT *= thresholdDistT;
		}
		else
		{
			// Later on, try canditates that are not rejected before
			for (i = 0; i<suspectedTotal; i++)
			{
				sourcePtr = initsourcePtr + pOffset[i];//Find the pointer to the remaining candidate
				tmp = (distanceT2) (ProjValue_Pat - (*sourcePtr >> setup->LogSize));
				tmp = tmp*tmp;
				matchesDistPtr[i] += tmp;//Lower bound is computed here
				if (matchesDistPtr[i] < thresholdDistT)
				{
					matchesDistPtr[suspectedCount] = matchesDistPtr[i];
					pOffset[suspectedCount++] = pOffset[i];
				} 
			}
		}
#ifdef SHOW_MY_STATS	
		printf("suspectedTotal: %d for %d projections, Ratios: %f\n", suspectedCount, curBaseNum, (float)suspectedCount/suspectedTotal);
#endif
#ifdef TRACK_CANDIDATES
		setup->NumCand[curBaseNum+1] = suspectedCount;
#endif
#ifdef ADAPTIVE_TERMINATION
		// This is the code related to the Section "New termination condition based on computational complexity analysis" in the following paper
		// Wanli Ouyang, Federico Tombari, Stefano Mattoccia, Luigi Di Stefano and Wai-Kuen Cham, "Performance Evaluation of Full Search Equivalent Pattern Matching Algorithms ", IEEE Trans. Pattern Analysis and machine Intelligence(TPAMI), Minor revision.
		//examine the operation saved by doing this loop of projection based pattern matching		
		//suspectedCount: candidates after this loop;  suspectedTotal: candidates before this loop
		if (curBaseNum>3)
			OpsProj= OpsPerProj;
		else
			OpsProj= OpsPerProj/2;
		OpsSaved = (float) (OPS_FS*N*(suspectedTotal-suspectedCount) - (OpsProj+OPS_CHECK_REJECTION*suspectedCount));
		//Estimate the next step
		FlagBreak = (OpsSaved < 0) ||((OpsProj+OPS_CHECK_REJECTION*suspectedCount) > (OPS_FS2*N*suspectedCount));
#endif

		suspectedTotal = suspectedCount;
#ifndef ADAPTIVE_TERMINATION
		FlagBreak = FlagBreak ||(suspectedTotal < Count2);
#endif
		if (FlagBreak) 
		{
			curBaseNum++;
			break;
		}
		// compute projection values when more are needed
		if ( (BasesComputed - curBaseNum ==  1) && (BasesComputed<setup->Bases_Num) )
		{
			setIncImageGCK(setup, BasesComputed, BasesComputed+1);
			BasesComputed++;
		}
		
	}//for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++)

// --------------------- FS Step --------------------
	suspectedCount = 0;
#if (NORM_MEASURE==CHOICE_SSD)
	threshold = (int) (thresholdDistT);
#endif
#if (NORM_MEASURE==CHOICE_SAD)
	threshold = (int) (threshold<<setup->LogSize);
#endif
	sourcePtrUint8 = imPixels(setup->curImage) + matCols(setup->curImage) * setup->Boundary_Size_Pat + setup->Boundary_Size_Pat;
	sourceDif = imCols(setup->curImage) - BLOCK_SIZE_IMG;
	prevImageProj = setup->prevImageProj[0];
	destDif = imCols(setup->prevImage) - BLOCK_SIZE_IMG;
#ifdef TRACK_CANDIDATES
	for (i=curBaseNum; i<setup->Bases_Num; i++) setup->NumCand[i] = 0;
	setup->NumCand[setup->Bases_Num] = suspectedTotal;
#endif
	i = 0;
	while (i<suspectedTotal)
	{
		int xpos, ypos;
		int offsetNow = matchesOffset[i];// + initNumOfCols;
		i++;
		ypos = offsetNow / matCols(prevImageProj);
		xpos = offsetNow - matCols(prevImageProj) * ypos;
#if (NORM_MEASURE==CHOICE_SSD)
		ssd = calcSSD2(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
#endif
#if (NORM_MEASURE==CHOICE_SAD)
		ssd = calcSAD(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
#endif
		if (ssd < threshold)
		{
			setup->match[suspectedCount] = ssd;
			setup->xmatch[suspectedCount] = ypos;
			setup->ymatch[suspectedCount] = xpos;
			suspectedCount++;
		}
	}
	setup->count = suspectedCount;
	setup->BasesComputed = curBaseNum;
}

// PMGCK for large pattern, Ouyang's algorithm
void PMGCKLP_FWHT(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases) {

	u_int16 maxValidX = setup->Img_Width_With_Boundary - BLOCK_SIZE_IMG;	// max valid coordinates for the
	u_int16 maxValidY = setup->Img_Height_With_Boundary - BLOCK_SIZE_IMG;	// upper left corner of candidate blocks

	u_int8 curBaseNum;
	int32 *sourcePtr, *initsourcePtr;
	distanceT2 *destPtr , *initDestPtr, *matchesDistPtr;
	u_int16 sourceDif;
	u_int16 destDif, initDestDif;
	u_int16 cols;
	u_int16 numOfRows, initNumOfRows;
	u_int16 initNumOfCols;
	int32 startBase;
	u_int8 *sourcePtrUint8;
	int32 suspectedCount, suspectedTotal, Count2;

	Matrix_Dist *distMat = setup->distances;
	u_int32 distMatSize = matSize(distMat) * sizeof(distanceT2);

	const float OpsPerProj= (float) (2.0*maxValidX*maxValidY);
	float OpsProj= OpsPerProj;
	const float N= (float) setup->Block_size_pat*setup->Block_size_pat;
	float OpsSaved;


	int32 i, bestSadIndex = 0;
	u_int32 ssd;
	u_int32 threshold = (setup->Threshold*setup->Block_size_pat*setup->Block_size_pat) >> (setup->LogSize);
	distanceT2 thresholdDistT;

	const int32 PatIdx = 0;
	int32 BasesComputed;
	Matrix *prevImageProj;
#ifdef MY_DEBUG
	int32 CompareReturn;
#endif

	// -------------- Rejection Step ---------------
	matchesDistPtr = (int*) matchesDist;
	if (WANT_DC) 
		startBase = 0;
	else
		startBase = 1;
#ifdef SHOW_MY_STATS	
		printf("Warning: collecting Wanli GCK stats...\n");
#endif
	copyImageWithBoundary(pImage, setup->prevImage, BOUNDARY_SIZE_IMG);
	
	BasesComputed=1;

	// Calculate the differnce image
	CalcImageDiff2(setup, setup->prevImage, setup->diffImage);
	// Compute the DC for difference image, note the pattern size is now (BLOCK_SIZE_IMG, BLOCK_SIZE_IMG/4)
	projDiffWHDC(setup, setup->diffImage, setup->prevImageProj[4], setup->colsProj, BLOCK_SIZE_IMG, BLOCK_SIZE_IMG>>2);
	// Obtain the 0th WHT basis image (DC component)
	setIncImageGCK_FWHT_Basis0(setup);
	BasesComputed=1;

	//Prepare parameters used in the following rejection steps
	initNumOfRows = setup->Img_Heihgt - BLOCK_SIZE_IMG + 1; 
	initNumOfCols = setup->Img_Width - BLOCK_SIZE_IMG + 1;
	initDestPtr = (int*) distMat->cellValues;
	initDestDif = matCols(distMat) - initNumOfCols;
	memset(distMat->cellValues, 0, distMatSize);	// make distance matrix zeros
	sourceDif = matCols(setup->prevImageProj[0]) - initNumOfCols;
	destDif = initDestDif;
	suspectedTotal = suspectedCount = initNumOfCols*initNumOfRows;
#ifdef TRACK_CANDIDATES
		setup->NumCand[0] = suspectedCount;
#endif
	Count2 = (int) (suspectedCount * setup->Percent);

	//for each basis vector
	for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++) {
		distanceT2 tmp;
		int32 ProjValue_Pat, *pOffset;
		int32 FlagBreak = 0;
		distanceT2 *pDist; 
		int32 CurBasePos = curBaseNum&3;
		suspectedCount = 0;
		prevImageProj = setup->prevImageProj[CurBasePos];
		ProjValue_Pat = PatternWHTCoef[curBaseNum];
		ProjValue_Pat >>= setup->LogSize;//Normailize
		if (ProjValue_Pat<0) 
			ProjValue_Pat++;

		initsourcePtr = prevImageProj->cellValues + matCols(prevImageProj) * BOUNDARY_SIZE_IMG + BOUNDARY_SIZE_IMG;
		sourcePtr = initsourcePtr;

		// At first time, try all of the canditate points
		pDist = matchesDistPtr;
		pOffset = matchesOffset;
		if (curBaseNum == startBase)
		{
			int itmp;
			destPtr = initDestPtr;
			numOfRows = initNumOfRows; 
			while (numOfRows--) {
				cols = initNumOfCols;
				while (cols--) {
					itmp = ProjValue_Pat - (*sourcePtr >> setup->LogSize);
					tmp = abs(itmp);
					if ( (u_int32) tmp < threshold)
					{
						tmp = tmp*tmp;
						*destPtr += tmp;
						*pDist = *destPtr;
						*pOffset = sourcePtr - initsourcePtr;
						pDist++;
						pOffset++;
					}
					sourcePtr++;
					destPtr++;
				}						
				sourcePtr += sourceDif;
				destPtr += destDif;
			}
			suspectedCount = pDist - matchesDistPtr;
			thresholdDistT = (distanceT2) threshold;
#if (NORM_MEASURE==CHOICE_SAD)
			thresholdDistT *= setup->Block_size_pat;
#endif
			thresholdDistT *= thresholdDistT;
		}
		else
		// Later on, try canditate points that are not rejected before
		{
			for (i = 0; i<suspectedTotal; i++)
			{
				sourcePtr = initsourcePtr + pOffset[i];
				tmp = (distanceT2) (ProjValue_Pat - (*sourcePtr >> setup->LogSize));
				tmp = tmp*tmp;
				matchesDistPtr[i] += tmp;//Lower bound is computed here
				if (matchesDistPtr[i] < thresholdDistT)
				{
					matchesDistPtr[suspectedCount] = matchesDistPtr[i];
					pOffset[suspectedCount++] = pOffset[i];
				} 
			}
		}
#ifdef SHOW_MY_STATS	
		printf("suspectedTotal: %d for %d projections, Ratios: %f\n", suspectedCount, curBaseNum, (float)suspectedCount/suspectedTotal);
#endif
#ifdef TRACK_CANDIDATES
		setup->NumCand[curBaseNum+1] = suspectedCount;
#endif
#ifdef ADAPTIVE_TERMINATION
		// This is the code related to the Section "New termination condition based on computational complexity analysis" in the following paper
		// Wanli Ouyang, Federico Tombari, Stefano Mattoccia, Luigi Di Stefano and Wai-Kuen Cham, "Performance Evaluation of Full Search Equivalent Pattern Matching Algorithms ", IEEE Trans. Pattern Analysis and machine Intelligence(TPAMI), Minor revision.
		//examine the operation saved by doing this loop of projection based pattern matching		
		//suspectedCount: candidates after this loop;  suspectedTotal: candidates before this loop
		if (curBaseNum>3)
			OpsProj= OpsPerProj;
		else
			OpsProj= OpsPerProj/2;
		OpsSaved = (float) (OPS_FS*N*(suspectedTotal-suspectedCount) - (OpsProj+OPS_CHECK_REJECTION*suspectedCount));
		//Estimate the next step
		FlagBreak = (OpsSaved < 0) ||((OpsProj+OPS_CHECK_REJECTION*suspectedCount) > (OPS_FS2*N*suspectedCount));
#endif

		suspectedTotal = suspectedCount;
#ifndef ADAPTIVE_TERMINATION
		FlagBreak = FlagBreak ||(suspectedTotal < Count2);
#endif
		//To see if we should jump to directly computing the Euclidean distance
		if (FlagBreak) 
		{
			curBaseNum++;
			break;
		}
		// compute projection values when more are needed
		if ( (BasesComputed - curBaseNum ==  1) && (BasesComputed<setup->Bases_Num) )
		{
			BasesComputed += setIncImageGCK_FWHT(setup, BasesComputed);
		}
	}//for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++)
	suspectedCount = 0;
	sourcePtrUint8 = imPixels(setup->curImage) + matCols(setup->curImage) * setup->Boundary_Size_Pat + setup->Boundary_Size_Pat;
	sourceDif = imCols(setup->curImage) - BLOCK_SIZE_IMG;
	prevImageProj = setup->prevImageProj[0];
	destDif = imCols(setup->prevImage) - BLOCK_SIZE_IMG;
	i = 0;
#if (NORM_MEASURE==CHOICE_SSD)
	threshold = (int) (thresholdDistT);
#endif
#if (NORM_MEASURE==CHOICE_SAD)
	threshold = (int) (threshold<<setup->LogSize);
#endif
#ifdef TRACK_CANDIDATES
	for (i=curBaseNum; i<setup->Bases_Num; i++) setup->NumCand[i] = 0;
	setup->NumCand[setup->Bases_Num] = suspectedTotal;
#endif
	i = 0;
	while (i<suspectedTotal)
	{
		int xpos, ypos;
		int offsetNow = matchesOffset[i];// + initNumOfCols;
		i++;
		ypos = offsetNow / matCols(prevImageProj);
		xpos = offsetNow - matCols(prevImageProj) * ypos;
//		xpos = offsetNow % matCols(setup->prevImageProj[0]);
#if (NORM_MEASURE==CHOICE_SSD)
		ssd = calcSSD2(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
#endif
#if (NORM_MEASURE==CHOICE_SAD)
		ssd = calcSAD(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
#endif
		if (ssd < threshold)
		{
			setup->match[suspectedCount] = ssd;
			setup->xmatch[suspectedCount] = ypos;
			setup->ymatch[suspectedCount] = xpos;
			suspectedCount++;
		}
	}
	setup->count = suspectedCount;
	setup->BasesComputed = BasesComputed;
}

void PMGCKSAD(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases) {
	u_int16 maxValidX = setup->Img_Width_With_Boundary - BLOCK_SIZE_IMG;	// max valid coordinates for the
	u_int16 maxValidY = setup->Img_Height_With_Boundary - BLOCK_SIZE_IMG;	// upper left corner of candidate blocks

	int32 curBaseNum;
	int32 *sourcePtr, *initsourcePtr;
	distanceT2 *destPtr , *initDestPtr, *matchesDistPtr;
	u_int16 sourceDif;
	u_int16 destDif, initDestDif;
	u_int16 cols;
	u_int16 numOfRows, initNumOfRows;
	u_int16 initNumOfCols;
	int32 startBase;
	u_int8 *sourcePtrUint8;
	int32 suspectedCount, suspectedTotal, Count2;

	Matrix_Dist *distMat = setup->distances;
	u_int32 distMatSize = matSize(distMat) * sizeof(distanceT2);

	int32 i, bestSadIndex = 0;
	int32 ssd;
	int32 threshold = (setup->Threshold*setup->Block_size_pat*setup->Block_size_pat) ;

	const float OpsPerProj= (float)2*maxValidX*maxValidY;
	float OpsProj;
	const float N= (float)setup->Block_size_pat*setup->Block_size_pat;
	float OpsSaved;
	double OpsStepa, OpsStepb;

	const int32 PatIdx = 0;
	int32 BasesComputed;
	Matrix *prevImageProj;
		distanceT2 thresholdDistT;
#ifdef MY_DEBUG
	int32 CompareReturn;
#endif
	if (WANT_DC) 
		startBase = 0;
	else
		startBase = 1;
	matchesDistPtr = (int*)  matchesDist;
	copyImageWithBoundary(pImage, setup->prevImage, BOUNDARY_SIZE_IMG);
	BasesComputed=1;
#ifdef SHOW_MY_STATS	
		printf("Warning: collecting Hel-Or GCK stats...\n");
#endif
	projWHDC(setup, setup->prevImage, setup->prevImageProj[0], setup->colsProj);
	BasesComputed=1;

	initNumOfRows = setup->Img_Heihgt - BLOCK_SIZE_IMG + 1; 
	initNumOfCols = setup->Img_Width - BLOCK_SIZE_IMG + 1;
	initDestPtr = (int*) distMat->cellValues;
	initDestDif = matCols(distMat) - initNumOfCols;
	memset(distMat->cellValues, 0, distMatSize);	// make distance matrix zeros
	sourceDif = matCols(setup->prevImageProj[0]) - initNumOfCols;
	destDif = initDestDif;
	suspectedTotal = suspectedCount = initNumOfCols*initNumOfRows;
#ifdef TRACK_CANDIDATES
		setup->NumCand[0] = suspectedCount;
#endif
	Count2 = (int) (suspectedCount * setup->Percent);
	for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++) {
		distanceT2 tmp;
		int32 ProjValue_Pat;
		int32 FlagBreak = 0;
		int CurBasePos = curBaseNum;
#ifdef MEMSAVE_WHT
		CurBasePos = CurBasePos % 4;
#endif
		suspectedCount = 0;
		prevImageProj = setup->prevImageProj[CurBasePos];
		ProjValue_Pat = PatternWHTCoef[curBaseNum] ;
		initsourcePtr = prevImageProj->cellValues + matCols(prevImageProj) * BOUNDARY_SIZE_IMG + BOUNDARY_SIZE_IMG;
		sourcePtr = initsourcePtr;
		if (curBaseNum == startBase)
		{
			int itmp;
			destPtr = initDestPtr;
			numOfRows = initNumOfRows; 
			while (numOfRows--) {
				cols = initNumOfCols;
				while (cols--) {
					itmp = ProjValue_Pat - (*sourcePtr);
					if (  abs(itmp) < threshold)
					{
						matchesOffset[suspectedCount++] = sourcePtr - initsourcePtr;
					}
					sourcePtr++;
				}						
				sourcePtr += sourceDif;
			}
			thresholdDistT = (distanceT2) threshold;
		}
		else
		{
			for (i = 0; i<suspectedTotal; i++)
			{
				sourcePtr = initsourcePtr + matchesOffset[i];//Find the pointer to the remaining candidate
				tmp = abs (ProjValue_Pat - (*sourcePtr));
				if (tmp < threshold)
				{
					matchesOffset[suspectedCount++] = matchesOffset[i];
				} 
			}
		}
#ifdef SHOW_MY_STATS	
		printf("suspectedTotal: %d for %d projections, Ratios: %f\n", suspectedCount, curBaseNum, (float)suspectedCount/suspectedTotal);
#endif
#ifdef TRACK_CANDIDATES
		setup->NumCand[curBaseNum+1] = suspectedCount;
#endif
#ifdef ADAPTIVE_TERMINATION
		// This is the code related to the Section "New termination condition based on computational complexity analysis" in the following paper
		// Wanli Ouyang, Federico Tombari, Stefano Mattoccia, Luigi Di Stefano and Wai-Kuen Cham, "Performance Evaluation of Full Search Equivalent Pattern Matching Algorithms ", IEEE Trans. Pattern Analysis and machine Intelligence(TPAMI), Minor revision.
		//examine the operation saved by doing this loop of projection based pattern matching		
		//suspectedCount: candidates after this loop;  suspectedTotal: candidates before this loop
		if (curBaseNum>3)
			OpsProj= OpsPerProj;
		else
			OpsProj= OpsPerProj/2;
		OpsSaved = (float) (OPS_FS*N*(suspectedTotal-suspectedCount) - (OpsProj+OPS_CHECK_REJECTION*suspectedCount));
		OpsStepa = OpsProj+OPS_CHECK_REJECTION*suspectedCount;
		OpsStepb = OPS_FS2*N*suspectedCount;
		//Estimate the next step
		FlagBreak = (OpsSaved < 0) ||(OpsStepa > OpsStepb);
#endif
		suspectedTotal = suspectedCount;
#ifndef ADAPTIVE_TERMINATION
		FlagBreak = FlagBreak ||(suspectedTotal < Count2);
#endif
		if (FlagBreak) 
		{
			curBaseNum++;
			break;
		}
		// compute projection values when more are needed
		if ( (BasesComputed - curBaseNum ==  1) && (BasesComputed<setup->Bases_Num) )
		{
			setIncImageGCK(setup, BasesComputed, BasesComputed+1);
			BasesComputed++;
		}
		
	}//for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++)
	suspectedCount = 0;
	threshold = (int) (thresholdDistT);
	sourcePtrUint8 = imPixels(setup->curImage) + matCols(setup->curImage) * setup->Boundary_Size_Pat + setup->Boundary_Size_Pat;
	sourceDif = imCols(setup->curImage) - BLOCK_SIZE_IMG;
	prevImageProj = setup->prevImageProj[0];
	destDif = imCols(setup->prevImage) - BLOCK_SIZE_IMG;
#ifdef TRACK_CANDIDATES
	for (i=curBaseNum; i<setup->Bases_Num; i++) setup->NumCand[i] = 0;
	setup->NumCand[setup->Bases_Num] = suspectedTotal;
#endif
	i = 0;
	while (i<suspectedTotal)
	{
		int xpos, ypos;
		int offsetNow = matchesOffset[i];// + initNumOfCols;
		i++;
		ypos = offsetNow / matCols(prevImageProj);
		xpos = offsetNow - matCols(prevImageProj) * ypos;
//		xpos = offsetNow % matCols(setup->prevImageProj[0]);
		ssd = calcSAD(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
		if (ssd < threshold)
		{
			setup->match[suspectedCount] = ssd;
			setup->xmatch[suspectedCount] = ypos;
			setup->ymatch[suspectedCount] = xpos;
			suspectedCount++;
		}
	}
	setup->count = suspectedCount;
	setup->BasesComputed = curBaseNum;

}


void PMGCKSAD_FWHT(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases) {

	u_int16 maxValidX = setup->Img_Width_With_Boundary - BLOCK_SIZE_IMG;	// max valid coordinates for the
	u_int16 maxValidY = setup->Img_Height_With_Boundary - BLOCK_SIZE_IMG;	// upper left corner of candidate blocks

	int32 curBaseNum;
	int32 *sourcePtr, *initsourcePtr;
	distanceT2 *destPtr , *initDestPtr, *matchesDistPtr;
	u_int16 sourceDif;
	u_int16 destDif, initDestDif;
	u_int16 cols;
	u_int16 numOfRows, initNumOfRows;
	u_int16 initNumOfCols;
	int32 startBase;
	u_int8 *sourcePtrUint8;
	int32 suspectedCount, suspectedTotal, Count2;

	Matrix_Dist *distMat = setup->distances;
	u_int32 distMatSize = matSize(distMat) * sizeof(distanceT2);
	int32 i, bestSadIndex = 0;
	int32 ssd;
	int32 threshold = (setup->Threshold*setup->Block_size_pat*setup->Block_size_pat);
	int32 BasicThreshold = threshold;
	distanceT2 thresholdDistT;


	const float OpsPerProj= (float) 2.0*maxValidX*maxValidY;
	float OpsProj = OpsPerProj;
	const float N= (float) setup->Block_size_pat*setup->Block_size_pat;
	double OpsSaved, OpsStepa, OpsStepb;

	const int32 PatIdx = 0;
	int32 BasesComputed;
	Matrix *prevImageProj;
#ifdef MY_DEBUG
	int32 CompareReturn;
#endif
	// -------------- Rejection Step ---------------
	matchesDistPtr = (int*) matchesDist;
	if (WANT_DC) 
		startBase = 0;
	else
		startBase = 1;
	// switch between current and previous image
#ifdef SHOW_MY_STATS	
		printf("Warning: collecting Wanli GCK stats...\n");
#endif
	copyImageWithBoundary(pImage, setup->prevImage, BOUNDARY_SIZE_IMG);
	BasesComputed=1;
	CalcImageDiff2(setup, setup->prevImage, setup->diffImage);
	projDiffWHDC_Norm(setup, setup->diffImage, setup->prevImageProj[4], setup->colsProj, BLOCK_SIZE_IMG, BLOCK_SIZE_IMG>>2);
	setIncImageGCK_FWHT_Basis0(setup);
	BasesComputed=1;
	initNumOfRows = setup->Img_Heihgt - BLOCK_SIZE_IMG + 1; 
	initNumOfCols = setup->Img_Width - BLOCK_SIZE_IMG + 1;
	initDestPtr = (int*) distMat->cellValues;
	initDestDif = matCols(distMat) - initNumOfCols;
	memset(distMat->cellValues, 0, distMatSize);	// make distance matrix zeros
	sourceDif = matCols(setup->prevImageProj[0]) - initNumOfCols;
	destDif = initDestDif;
	suspectedTotal = suspectedCount = initNumOfCols*initNumOfRows;
#ifdef TRACK_CANDIDATES
		setup->NumCand[0] = suspectedCount;
#endif
	Count2 = (int) (suspectedCount * setup->Percent);

	//for each basis vector
	for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++) {
		distanceT2 tmp;
		int32 ProjValue_Pat, *pOffset;
		int32 FlagBreak = 0;
		int32 CurBasePos = curBaseNum&3;
		distanceT2 *pDist; 
		suspectedCount = 0;
		prevImageProj = setup->prevImageProj[CurBasePos];
		ProjValue_Pat = PatternWHTCoef[curBaseNum];
		initsourcePtr = prevImageProj->cellValues + matCols(prevImageProj) * BOUNDARY_SIZE_IMG + BOUNDARY_SIZE_IMG;
		sourcePtr = initsourcePtr;

		// At first time, try all of the canditate points
		pDist = matchesDistPtr;
		pOffset = matchesOffset;
		if (curBaseNum == startBase)
		{
			int itmp;
			destPtr = initDestPtr;
			numOfRows = initNumOfRows; 
			while (numOfRows--) {
				cols = initNumOfCols;
				while (cols--) {
					itmp = ProjValue_Pat - *sourcePtr;
					tmp = abs(itmp);
					if ( tmp < threshold)
					{
						matchesOffset[suspectedCount++] = sourcePtr - initsourcePtr;
					}
					sourcePtr++;
				}						
				sourcePtr += sourceDif;
			}
			thresholdDistT = (distanceT2) threshold;
		}
		else
		// Later on, try canditate points that are not rejected before
		{
			for (i = 0; i<suspectedTotal; i++)
			{
				sourcePtr = initsourcePtr + pOffset[i];
				tmp = abs (ProjValue_Pat - *sourcePtr );
				if ( tmp<BasicThreshold )
				{
					pOffset[suspectedCount++] = pOffset[i];
				} 
			}
		}
#ifdef SHOW_MY_STATS	
		printf("suspectedTotal: %d for %d projections, Ratios: %f\n", suspectedCount, curBaseNum, (float)suspectedCount/suspectedTotal);
#endif
#ifdef TRACK_CANDIDATES
		setup->NumCand[curBaseNum+1] = suspectedCount;
#endif
#ifdef ADAPTIVE_TERMINATION
		// This is the code related to the Section "New termination condition based on computational complexity analysis" in the following paper
		// Wanli Ouyang, Federico Tombari, Stefano Mattoccia, Luigi Di Stefano and Wai-Kuen Cham, "Performance Evaluation of Full Search Equivalent Pattern Matching Algorithms ", IEEE Trans. Pattern Analysis and machine Intelligence(TPAMI), Minor revision.
		//examine the operation saved by doing this loop of projection based pattern matching		
		//suspectedCount: candidates after this loop;  suspectedTotal: candidates before this loop
		if (curBaseNum>3)
			OpsProj= OpsPerProj;
		else
			OpsProj= OpsPerProj/2;
		OpsSaved = (float) (OPS_FS*N*(suspectedTotal-suspectedCount) - (OpsProj+OPS_CHECK_REJECTION*suspectedCount));
		//Estimate the next step
		OpsStepa = OpsProj+OPS_CHECK_REJECTION*suspectedCount;
		OpsStepb = OPS_FS2*N*suspectedCount;
		FlagBreak = (OpsSaved < 0) ||(OpsStepa > OpsStepb);
#endif

		suspectedTotal = suspectedCount;
#ifndef ADAPTIVE_TERMINATION
		FlagBreak = FlagBreak ||(suspectedTotal < Count2);
#endif
		//To see if we should jump to directly computing the Euclidean distance
		if (FlagBreak) 
		{
			curBaseNum++;
			break;
		}
		// compute projection values when more are needed
		if ( (BasesComputed - curBaseNum ==  1) && (BasesComputed<setup->Bases_Num) )
		{
			BasesComputed += setIncImageGCK_FWHT(setup, BasesComputed);
		}		
	}//for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++)
	suspectedCount = 0;
	sourcePtrUint8 = imPixels(setup->curImage) + matCols(setup->curImage) * setup->Boundary_Size_Pat + setup->Boundary_Size_Pat;
	sourceDif = imCols(setup->curImage) - BLOCK_SIZE_IMG;
	prevImageProj = setup->prevImageProj[0];
	destDif = imCols(setup->prevImage) - BLOCK_SIZE_IMG;
	i = 0;
	threshold = BasicThreshold;
#ifdef TRACK_CANDIDATES
	for (i=curBaseNum; i<setup->Bases_Num; i++) setup->NumCand[i] = 0;
	setup->NumCand[setup->Bases_Num] = suspectedTotal;
#endif
	i = 0;
	while (i<suspectedTotal)
	{
		int xpos, ypos;
		int offsetNow = matchesOffset[i];// + initNumOfCols;
		i++;
		ypos = offsetNow / matCols(prevImageProj);
		xpos = offsetNow - matCols(prevImageProj) * ypos;
		ssd = calcSAD(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
		if (ssd < threshold)
		{
			setup->match[suspectedCount] = ssd;
			setup->xmatch[suspectedCount] = ypos;
			setup->ymatch[suspectedCount] = xpos;
			suspectedCount++;
		}
	}
	setup->count = suspectedCount;
	setup->BasesComputed = curBaseNum;
}

#pragma inline_recursion(off)
#pragma inline_depth()
