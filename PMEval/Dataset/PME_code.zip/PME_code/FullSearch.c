
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "pm.h"
#include "BoxFilter.h"


int SsdTh(information *info){

	unsigned char *Image=info->Image;
	unsigned char *Template=info->Template;
	int ImageWidth=info->ImageWidth;
	int ImageHeight=info->ImageHeight;
	int TemplateWidth=info->TemplateWidth;
	int TemplateHeight=info->TemplateHeight;

	 int i,j;
	 int x,y;

	 int SSD=0;
	 int temp;
	 int count = 0;
	 int SSD_MIN = info->SsdThreshold; 
	 int index = 0;

	 for (y=0;y<=(ImageHeight-TemplateHeight);y++){
		 for (x=0;x<=(ImageWidth-TemplateWidth);x++){

			 SSD=0;
 
			 for (i=0;i<TemplateHeight;i++){
			  for (j=0;j<TemplateWidth;j++){
			   temp = Image[(y+i)*ImageWidth+(x+j)] - Template[i*TemplateWidth+j];
			   SSD = SSD + (temp*temp);
			   }
			  }  
			 if (SSD<SSD_MIN ) {
			  info->match[count] = SSD;
			  info->xmatch[count] = y;
			  info->ymatch[count] = x;
			  count++;
			 }
			 info->FSDist[index++] = SSD;
		 }
	 }
   
	info->count = count;

	return 0;
}


#define INT_MAX  1073741824

int SsdBest(information *info){

	unsigned char *Image=info->Image;
	unsigned char *Template=info->Template;
	int ImageWidth=info->ImageWidth;
	int ImageHeight=info->ImageHeight;
	int TemplateWidth=info->TemplateWidth;
	int TemplateHeight=info->TemplateHeight;

	 int i,j;
	 int x,y;

	 int bestX=-1;
	 int bestY=-1;

	 int SSD=0;
	 int temp;
	 int SSD_MIN = INT_MAX; 
  
	 for (y=0;y<=(ImageHeight-TemplateHeight);y++){
	 for (x=0;x<=(ImageWidth-TemplateWidth);x++){

	  SSD=0;
 
	 for (i=0;i<TemplateHeight;i++){
	  for (j=0;j<TemplateWidth;j++){
	   temp = Image[(y+i)*ImageWidth+(x+j)] - Template[i*TemplateWidth+j];
	   SSD = SSD + (temp*temp);
	  }
	 }
  
	 if (SSD<SSD_MIN ) {
	  SSD_MIN = SSD;
	 bestX = y;
	  bestY = x; 
	 }
	 }}
   
	info->SsdMin=SSD_MIN;
	info->position_x = bestX;
	info->position_y = bestY;
   
	return 0;
}



int SsdCountNMatch(information *info){

	unsigned char *Image=info->Image;
	unsigned char *Template=info->Template;
	int ImageWidth=info->ImageWidth;
	int ImageHeight=info->ImageHeight;
	int TemplateWidth=info->TemplateWidth;
	int TemplateHeight=info->TemplateHeight;

	 int i,j;
	 int x,y;

	 int SSD=0;
	 int temp;
	 int count = 0;
	  int SSD_MIN = info->SsdThreshold; 

	 for (y=0;y<=(ImageHeight-TemplateHeight);y++){
	 for (x=0;x<=(ImageWidth-TemplateWidth);x++){

	  SSD=0;
 
	 for (i=0;i<TemplateHeight;i++){
	 for (j=0;j<TemplateWidth;j++){
	   temp = Image[(y+i)*ImageWidth+(x+j)] - Template[i*TemplateWidth+j];
	   SSD = SSD + (temp*temp);
	   }
	  }
  
	 if (SSD<SSD_MIN ) {
	  count++;
	 }
	}}
   
	info->count = count;
  
	return 0;
}




int SadTh(information *info){

	unsigned char *Image=info->Image;
	unsigned char *Template=info->Template;
	int ImageWidth=info->ImageWidth;
	int ImageHeight=info->ImageHeight;
	int TemplateWidth=info->TemplateWidth;
	int TemplateHeight=info->TemplateHeight;

	int i,j;
	int x,y;

	int count = 0;
	int SAD;
	int SAD_MIN = info->SsdThreshold;
	int index = 0;

	for (y=0;y<=(ImageHeight-TemplateHeight);y++){
		for (x=0;x<=(ImageWidth-TemplateWidth);x++){

			SAD=0;

			for (i=0;i<TemplateHeight;i++){
			for (j=0;j<TemplateWidth;j++){
				SAD += abs(Image[(y+i)*ImageWidth+(x+j)] - Template[i*TemplateWidth+j]);
			}}
			
			if (SAD<SAD_MIN ) {
				info->match[count] = SAD;
				info->xmatch[count] = y;
				info->ymatch[count] = x;
				count++;	
			}
			info->FSDist[index++] = SAD;
		}
	}
   
info->count = count;

return 0;
}




int SadBest(information *info){

	unsigned char *Image=info->Image;
	unsigned char *Template=info->Template;
	int ImageWidth=info->ImageWidth;
	int ImageHeight=info->ImageHeight;
	int TemplateWidth=info->TemplateWidth;
	int TemplateHeight=info->TemplateHeight;

	int i,j;
	int x,y;

	int bestX=-1;
	int bestY=-1;

	int SAD;
	int SAD_MIN = TemplateWidth*TemplateHeight*255; 

	for (y=0;y<=(ImageHeight-TemplateHeight);y++){
	for (x=0;x<=(ImageWidth-TemplateWidth);x++){

		SAD=0;

		for (i=0;i<TemplateHeight;i++){
		for (j=0;j<TemplateWidth;j++){
			SAD += abs(Image[(y+i)*ImageWidth+(x+j)] - Template[i*TemplateWidth+j]);
		}}
			
		if (SAD<SAD_MIN ) {
			SAD_MIN = SAD;
			bestX = y;
			bestY = x;	
		}
	}}
   
	info->SsdMin=SAD_MIN;
	info->position_x = bestX;
	info->position_y = bestY;

	return 0;
}


int SadCountNMatch(information *info){

	unsigned char *Image=info->Image;
	unsigned char *Template=info->Template;
	int ImageWidth=info->ImageWidth;
	int ImageHeight=info->ImageHeight;
	int TemplateWidth=info->TemplateWidth;
	int TemplateHeight=info->TemplateHeight;

	int i,j;
	int x,y;

	int count = 0;
	int SAD;
	int SAD_MIN = info->SsdThreshold;

	for (y=0;y<=(ImageHeight-TemplateHeight);y++){
	for (x=0;x<=(ImageWidth-TemplateWidth);x++){

		SAD=0;

		for (i=0;i<TemplateHeight;i++){
		for (j=0;j<TemplateWidth;j++){
			SAD += abs(Image[(y+i)*ImageWidth+(x+j)] - Template[i*TemplateWidth+j]);
		}}
		
		if (SAD<SAD_MIN ) {
			count++;	
		}
	}}
 
	info->count = count;

	return 0;
}

