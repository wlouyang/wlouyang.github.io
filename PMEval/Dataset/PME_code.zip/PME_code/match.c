/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        match.c                                                      *
 *                                                                           *
 * description: Utility for handling a queue of best matches for a block.	 *
 *****************************************************************************/					     
 
#include <stdlib.h>
#include <limits.h>
#include "defs.h"
#include "match.h"


///////////////////////////////// FUNCTIONS /////////////////////////////////

/*****************************************************************************
 * Allocates a matches queue.		                                         *
 *****************************************************************************/
MatchQueue *allocMatchQueue() {

	MatchQueue *result = (MatchQueue *)malloc(sizeof(MatchQueue));
	if (!result)
		exitWithError("ERROR in allocMatchQueue: can't allocate setup.");

	result->largestDist = ULONG_MAX;
	result->largestIndex = 0;

	return result;
}


/*****************************************************************************
 * Initializes a matches queue by assigning infinity to all its distances    *
 *****************************************************************************/
void initMatchQueue(MatchQueue *matchQueue) {

	u_int8 i;

	matchQueue->largestDist = ULONG_MAX;
	matchQueue->largestIndex = 0;

	for (i=0; i < MATCHES_FOR_SAD; i++)
		matchQueueDistance(matchQueue, i) = ULONG_MAX;
}


/*****************************************************************************
 * Destroys the given match queue.									         *
 *****************************************************************************/
void destroyMatchQueue(MatchQueue *matchQueue) {

	free(matchQueue);
}
