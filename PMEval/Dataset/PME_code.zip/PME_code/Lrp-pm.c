
#include <stdlib.h>
#include <stdio.h>

#include "pm.h"
#include "BoxFilter.h"
#include "memory.h"
__inline void CalcIntegral(BYTE* Input, int *Intgr, int *MtxS, int HEIGHT, int WIDTH)
{
//start computing integral image
 //Notice that WIDTH and HEIGHT might not be the original size
 int x, y;
 int imgY;
 int *pMtxS, *pIntgrTmpl;
 int integralImgeW;
 integralImgeW = WIDTH + 1;
 pMtxS = MtxS;
 pIntgrTmpl = Intgr;
 for (y = 0; y<HEIGHT+1; y++)
 {
	 pMtxS[y*integralImgeW] = 0;
	 pIntgrTmpl[y*integralImgeW] = 0;
 }

 pMtxS = MtxS;
 pIntgrTmpl = Intgr;
 for (x = 0; x<integralImgeW; x++)
 {
	 pMtxS[x] = 0;
	 pIntgrTmpl[x] = 0;
 }

 for (y=1; y<HEIGHT+1; y++)//i: y   j: x
	 for (x=1; x<WIDTH+1; x++)
	 {
		 imgY=Input[(y-1)*WIDTH+x-1];//img(x-1, y-1)
		 MtxS[y*integralImgeW+x] = MtxS[(y-1)*integralImgeW+x] + imgY;//S(x,y) = S(x, y-1) + img(x-1, y-1)
		 Intgr[y*integralImgeW+x]= Intgr[(y)*integralImgeW+x-1]+MtxS[(y)*integralImgeW+x];
	 }
}

__inline void CalcRectSumByInt(int* IntgrTmpl, int *Proj, int N1, int rStart, int cStart, int rEnd, int cEnd, int WIDTH)
{
	int row, col;
	int integralImgeW;
	int N2 = N1;
	integralImgeW = WIDTH + 1;
	for (row = rStart; row < rEnd; row++)
	{
		for (col=cStart; col<cEnd; col++)
		{
			Proj[row*WIDTH+col] = IntgrTmpl[(row+N2)*integralImgeW+col+N1] - IntgrTmpl[row*integralImgeW+col+N1] 
				- IntgrTmpl[(row+N2)*integralImgeW+col] + IntgrTmpl[row*integralImgeW+col];
		}
	}
}

void HierarchicalSumUC(unsigned char *Image, int ImageWidth, int ImageHeight, int SumW, int SumH, int *ResultImage, int coarseness){

	int x,y,i,j;

	for(y=0; y<ImageHeight-SumH*coarseness+1; y++)
		for(x=0; x<ImageWidth-SumW*coarseness+1; x++){
			
			ResultImage[y* ImageWidth + x] = 0;

			for(j=0; j<SumH; j++)
				for(i=0; i<SumW; i++)
					ResultImage[y* ImageWidth + x] += Image[(y+j*coarseness)*ImageWidth+x+i*coarseness];

		}
}

void HierarchicalSum(int *Image, int ImageWidth, int ImageHeight, int SumW, int SumH, int *ResultImage, int coarseness){

	int x,y,i,j;

	for(y=0; y<ImageHeight-SumH*coarseness+1; y++)
		for(x=0; x<ImageWidth-SumW*coarseness+1; x++){
			
			ResultImage[y* ImageWidth + x] = 0;

			for(j=0; j<SumH; j++)
				for(i=0; i<SumW; i++)
					ResultImage[y* ImageWidth + x] += Image[(y+j*coarseness)*ImageWidth+x+i*coarseness];

		}
}


static unsigned char BufList[MAX_IMAGE_SIZE];
static int BufSum[MAX_PAT_L][MAX_INTEGRAL_IMAGE_SIZE];
static int BufTempl[MAX_PAT_L][MAX_PAT*MAX_PAT];

int SsdLrpSAT(information *info){

	unsigned char *Image=info->Image;
	unsigned char *Template=info->Template;
	int ImageWidth=info->ImageWidth;
	int ImageHeight=info->ImageHeight;
	int TemplateWidth=info->TemplateWidth;
	int TemplateHeight=info->TemplateHeight;

	int SsdThreshold = info->SsdThreshold;

	int i,k,j;
	int x,y;

	//Number of levels
	int L = info->N;

	//Sizes of reduced templates
	int *TR = (int *)malloc( (L+1) * sizeof(int));
	int temp2 = 2;
	int ITW=ImageWidth-TemplateWidth+1;
	int ITH=ImageHeight-TemplateHeight+1;
	double temp = 0.0;
	double D;
	double SSD;	
	//double *ssdlist = (double *) malloc ( ITW * ITH * sizeof (double) );
	#ifdef ALLC_INLOOP
	unsigned char *list = (unsigned char *) calloc ( ITW * ITH, sizeof (unsigned char) );
	#else
	unsigned char *list = BufList;
	#endif
	int **templateR = (int **)malloc( L * sizeof(int *));
	int *ImageSum;
	int *normA = (int *)malloc( L * sizeof(int));
	int is=0;
	#ifdef RETURN_STATS
	int skipped[12];
	int c;
	#endif			
	#ifdef TRACK_CANDIDATES
		int NumCands;
	#endif

	#ifdef RETURN_STATS
	//int skipped[L];
	//printf("Warning: collecting stats...\n");
	for(c = 0; c<L; c++)
		skipped[c] = 0;
	#endif	
			
	TR[0] = 1;
	for(i=1; i<(L+1); i++){
		TR[i]=temp2;
		temp2 = temp2 * 2;
	} 
	for(k=0; k<12; k++) info->NumCand[k] = 0;
		
				
	#ifdef ALLC_INLOOP
	for(i=0; i<L; i++)
		templateR[i] = (int *)malloc(TR[i] * TR[i] * sizeof(int) );
	ImageSum = (int *)malloc(ImageHeight*ImageWidth*sizeof(int));
	#else
	memset(list, 0, ITW * ITH);
	for(i=0; i<L; i++)
		templateR[i] = BufTempl[i];
	ImageSum = BufSum[0];
	#endif

	//int *ImageSum[L];
	//for(i=0; i<L; i++)
	//	ImageSum[i] = (int *)malloc(ImageHeight*ImageWidth*sizeof(int));
		
	//int normA[6] = {4096, 1024, 256, 64, 16, 4};
	temp2 = 4;
	for(i=L-1; i>=0; i--){	
		normA[i] = temp2;
		temp2 = 4*temp2;	
	}
		
	// ################## BOX FILTERING ###################

	SatSum(Image, ImageWidth, ImageHeight, ImageSum);
	//for(i=0; i<L; i++)
	 //  	BoxFilteringSum(Image, ImageWidth, ImageHeight, TR[L-i], TR[L-i], ImageSum[i]);
  		
	for(i=0; i<TR[L-1]; i++)
	for (j=0;j<TR[L-1]; j++){
		templateR[L-1][i*TR[L-1] + j] = (int)(Template[2*i*TemplateWidth + 2*j]+Template[2*i*TemplateWidth + 2*j + 1] + Template[(2*i+1)*TemplateWidth + 2*j] + Template[(2*i+1)*TemplateWidth + 2*j + 1]);
	}

	for(k=L-2; k>=0; k--) 	
	for(i=0; i<TR[k]; i++)
	for (j=0;j<TR[k]; j++) {
		templateR[k][i*TR[k] + j] = (int)(templateR[k+1][2*i*TR[k+1] + 2*j]+templateR[k+1][2*i*TR[k+1] + 2*j + 1] + templateR[k+1][(2*i+1)*TR[k+1] + 2*j] + templateR[k+1][(2*i+1)*TR[k+1] + 2*j + 1]);
	}
	for(k=0; k<12; k++) info->NumCand[k] = 0;
	//All levels a part from the last one
	for(k=0; k<L-1; k++){
	#ifdef TRACK_CANDIDATES
		NumCands=0;
	#endif

		D = 1.0 * SsdThreshold * normA[k];

		//STEP 1: compute SSDs at low resolution of non-skipped candidates
		for (y=0;y<ITH;y++)
		for (x=0;x<ITW;x++){
		if(list[y*ITW+x] == 0){	
			SSD = 0.0;
		
			for(i=0; i<TR[k] ;i++){
			for (j=0;j<TR[k];j++){		
				if( (y+i>0) && (x+j>0))
					is = ImageSum[(y+(i+1)*TR[L-k]-1)*ImageWidth+(x+TR[L-k]*(j+1)-1)] + ImageSum[(y+i*TR[L-k]-1)*ImageWidth+(x+TR[L-k]*j-1)] - ImageSum[(y+(i+1)*TR[L-k]-1)*ImageWidth+(x+TR[L-k]*j-1)] - ImageSum[(y+i*TR[L-k]-1)*ImageWidth+(x+TR[L-k]*(j+1)-1)];	
				else{
					if( (y+i==0) && (x+j==0))
						is = ImageSum[(TR[L-k]-1)*ImageWidth + TR[L-k]-1];
					if( (y+i>0) && (x+j==0))
						is = ImageSum[(y+(i+1)*TR[L-k]-1)*ImageWidth + TR[L-k]-1] - ImageSum[(y+i*TR[L-k]-1)*ImageWidth + TR[L-k]-1];
					if( (y+i==0) && (x+j>0))
						is = ImageSum[(TR[L-k]-1)*ImageWidth + x+TR[L-k]*(j+1)-1] - ImageSum[(TR[L-k]-1)*ImageWidth + x+TR[L-k]*j-1];
				}	
				temp = (double)(1.0*is - templateR[k][i*TR[k]+j]);
				SSD += temp*temp;
			}}

			if( SSD>=D )
				list[y*ITW+x] = 1;

	#ifdef TRACK_CANDIDATES
			NumCands++;
	#endif

			//ssdlist[y*ITW + x] = SSD;
		}}
	#ifdef TRACK_CANDIDATES
		info->NumCand[k] = NumCands;	// Number of candidates at each step
	#endif

		//STEP 3: Compute skippable candidates by the current bound
		//for (y=0;y<ITH;y++)
		//for (x=0;x<ITW;x++){
		////if(list[y*ITW+x] ==0){
		//if( (ssdlist[y*ITW+x]>D) && (list[y*ITW+x] ==0) ){
		//		#ifdef RETURN_STATS
		//		skipped[k]++;
		//		#endif
		//		list[y*ITW+x] = 1;
		//}}//}
		
	}//for(k=0; k<L-1; k++) All levels a part from the last one
	
//Last level
	D = 1.0 * SsdThreshold * normA[L-1];

	#ifdef TRACK_CANDIDATES
		NumCands=0;
	#endif

	for (y=0;y<ITH;y++)
	for (x=0;x<ITW;x++){
	if(list[y*ITW+x] == 0){

		SSD = 0.0;
		for(i=0; i<TR[L-1] ;i++){
		for (j=0;j<TR[L-1] ;j++){
				if( (y+i>0) && (x+j>0))
					is = ImageSum[(y+i*2+1)*ImageWidth+(x+2*j+1)] + ImageSum[(y+i*2-1)*ImageWidth+(x+2*j-1)] - ImageSum[(y+i*2+1)*ImageWidth+(x+2*j-1)] - ImageSum[(y+i*2-1)*ImageWidth+(x+2*j+1)];
				else{
					if( (y+i==0) && (x+j==0))
						is = ImageSum[ImageWidth + 1];
					if( (y+i>0) && (x+j==0))
						is = ImageSum[(y+i*2+1)*ImageWidth + 1] - ImageSum[(y+i*2-1)*ImageWidth + 1];
					if( (y+i==0) && (x+j>0))
						is = ImageSum[ImageWidth + x+2*j+1] - ImageSum[ImageWidth + x+2*j-1];
				}
			temp = (double)(1.0*is - templateR[L-1][i*TR[L-1]+j]);
			SSD += temp*temp;
		}}

		if( SSD>=D)
			list[y*ITW+x] = 1;
	#ifdef TRACK_CANDIDATES
			NumCands++;
	#endif

		//ssdlist[y*ITW + x] = SSD;
	}
	}//for (y=0;y<ITH;y++) 	for (x=0;x<ITW;x++)
	
//for (y=0;y<ITH;y++)
//for (x=0;x<ITW;x++){
//if( (ssdlist[y*ITW+x]>D) && (list[y*ITW+x] ==0) ){
//	#ifdef RETURN_STATS
//	skipped[L-1]++;
//	#endif
//	list[y*ITW+x] = 1;
//}}
	
//Final brute force for remaining candidates
#ifdef TRACK_CANDIDATES
	info->NumCand[k++] = NumCands;	// Number of candidates at each step
	NumCands=0;
#endif

	info->count = 0;
	for (y=0;y<ITH;y++)
	for (x=0;x<ITW;x++){
	if(list[y*ITW+x] == 0){
#ifdef TRACK_CANDIDATES
		NumCands++;
#endif
	
		SSD = 0.0;
		for(i=0; i<TemplateHeight ;i++){
		for (j=0;j<TemplateWidth;j++){
			temp = (double)(1.0*Image[(y+i)*ImageWidth + (x+j)] - Template[i*TemplateWidth+j]);
			SSD += temp*temp;
		}}
				
		if (SSD<SsdThreshold ) {
			info->match[info->count] = (int) SSD;
			info->xmatch[info->count]= y;
			info->ymatch[info->count]= x;
			info->count++;
		}	
	}}
#ifdef TRACK_CANDIDATES
	info->NumCand[k++] = NumCands;	// Number of candidates at each step
#endif
	
	free(templateR);

	//free(ssdlist);
#ifdef ALLC_INLOOP
	free(ImageSum);
	for(i=0; i<L; i++)
		free(templateR[i]);
	free(list);
#endif
	free(TR);
	free(normA);

#ifdef RETURN_STATS
	// Statistics (if enabled during compilation)
	info->total_points=ITW*ITH;
	for (k=0; k<L; k++){
		info->skipped_points[k]=skipped[k];
	}
#endif

return 0;
}





int SsdLrpBF(information *info){

	unsigned char *Image=info->Image;
	unsigned char *Template=info->Template;
	int ImageWidth=info->ImageWidth;
	int ImageHeight=info->ImageHeight;
	int TemplateWidth=info->TemplateWidth;
	int TemplateHeight=info->TemplateHeight;

	int SsdThreshold = info->SsdThreshold;
	#ifdef TRACK_CANDIDATES
		int NumCands;
	#endif
	int i,k,j;
	int x,y;

	//Number of levels
	int L = info->N;

	//Sizes of reduced templates
	int *TR = (int *)malloc( (L+2) * sizeof(int));
	int temp2 = 2;



	int ITW=ImageWidth-TemplateWidth+1;
	int ITH=ImageHeight-TemplateHeight+1;
	double temp = 0.0;
	double D;
	double SSD;	
//double *ssdlist = (double *) malloc ( ITW * ITH * sizeof (double) );
#ifdef ALLC_INLOOP
	unsigned char *list = (unsigned char *) calloc ( ITW * ITH, sizeof (unsigned char) );
#else
	unsigned char *list = BufList;
#endif
	int *normA = (int *)malloc( L * sizeof(int));
	int **templateR = (int **)malloc( L * sizeof(int *));
	int **ImageSum = (int **)malloc( (L+1) * sizeof(int *));
#ifdef OBTAIN_BOUND
	int Candj = 0;
#endif
	

#ifdef RETURN_STATS
//printf("Warning: collecting stats...\n");
int skipped[12];
int c;
for(c = 0; c<L; c++)
	skipped[c] = 0;
#endif	
		
#ifndef ALLC_INLOOP
memset(list, 0, ITW * ITH);
#endif
	
	for(k=0; k<12; k++) info->NumCand[k] = 0;

	TR[0] = 1;
	for(i=1; i<(L+2); i++){
		TR[i]=temp2;
		temp2 = temp2 * 2;
	} 

#ifdef OBTAIN_BOUND
	for(i=0; i<L; i++){info->Bound[i]=0.0;}
#endif
			
#ifdef ALLC_INLOOP
	for(i=0; i<L; i++)
		templateR[i] = (int *)malloc(TR[i] * TR[i] * sizeof(int) );
	for(i=0; i<L+1; i++)
		ImageSum[i] = (int *)malloc((ImageHeight+1)*(ImageWidth+1)*sizeof(int));
#else
	for(i=0; i<L; i++)
		templateR[i] = BufTempl[i];
	for(i=0; i<L+1; i++)
		ImageSum[i] = BufSum[i];
#endif

	temp2 = 4;
	for(i=L-1; i>=0; i--){	
		normA[i] = temp2;
		temp2 = 4*temp2;	
}
	
// ################## BOX FILTERING ###################
//for(i=0; i<L; i++)
//   	BoxFilteringSum(Image, ImageWidth, ImageHeight, TR[L-i], TR[L-i], ImageSum[i]);
// ################## SAT ###################
	CalcIntegral(Image, ImageSum[L], ImageSum[0], ImageHeight, ImageWidth);
	for(i=0; i<L; i++)
		CalcRectSumByInt(ImageSum[L], ImageSum[i], TR[L-i], 0, 0, ITH+(TR[i]-1)*TR[L-i], ITW+(TR[i]-1)*TR[L-i], ImageWidth);	
  		
	for(i=0; i<TR[L-1]; i++)
	for (j=0;j<TR[L-1]; j++){
		templateR[L-1][i*TR[L-1] + j] = (int)(Template[2*i*TemplateWidth + 2*j]+Template[2*i*TemplateWidth + 2*j + 1] + Template[(2*i+1)*TemplateWidth + 2*j] + Template[(2*i+1)*TemplateWidth + 2*j + 1]);
	}

	for(k=L-2; k>=0; k--) 	
	for(i=0; i<TR[k]; i++)
	for (j=0;j<TR[k]; j++) {
		templateR[k][i*TR[k] + j] = (int)(templateR[k+1][2*i*TR[k+1] + 2*j]+templateR[k+1][2*i*TR[k+1] + 2*j + 1] + templateR[k+1][(2*i+1)*TR[k+1] + 2*j] + templateR[k+1][(2*i+1)*TR[k+1] + 2*j + 1]);
	}

//All levels apart from the last one
for(k=0; k<L-1; k++){
#ifdef TRACK_CANDIDATES
	NumCands=0;
#endif

	D = 1.0 * SsdThreshold * normA[k];

#ifdef OBTAIN_BOUND
	Candj = 0;
#endif

	//Step 1: compute SSDs on low resolution candidates
	for (y=0;y<ITH;y++)
	for (x=0;x<ITW;x++){

		if(list[y*ITW+x] == 0){	
#ifdef OBTAIN_BOUND
		Candj = y*ITW+x;
#endif
			SSD = 0.0;
		
			for(i=0; i<TR[k] ;i++){
			for (j=0;j<TR[k];j++){
				temp = (double)(1.0*ImageSum[k][(y+TR[L-k]*i)*ImageWidth + (x+TR[L-k]*j)] - templateR[k][i*TR[k]+j]);
				SSD += temp*temp;
			}}
#ifdef OBTAIN_BOUND
	   info->Bound[k] += SSD/((float)info->FSDist[Candj]*normA[k]);
#endif

			if (SSD>=D) //&& (list[y*ITW+x] ==0) ){
				list[y*ITW+x] = 1;
			//}
	#ifdef TRACK_CANDIDATES
			NumCands++;
	#endif

			//ssdlist[y*ITW + x] = SSD;
		}
	}


#ifdef TRACK_CANDIDATES
	info->NumCand[k] = NumCands;	// Number of candidates at each step
#endif
	
	
	
	//FASE 3: PRUNING;
	//for (y=0;y<ITH;y++)
	//for (x=0;x<ITW;x++){     
	////if(list[y*ITW+x] ==0){
	//if( (ssdlist[y*ITW+x]>D) && (list[y*ITW+x] ==0) ){
	//	#ifdef RETURN_STATS
	//	skipped[k]++;
	//	#endif
	//	list[y*ITW+x] = 1;
	//}}//}
	
	} //k
	
//Last level
D = 1.0 * SsdThreshold * normA[L-1];

#ifdef TRACK_CANDIDATES
	NumCands=0;
#endif

	for (y=0;y<ITH;y++)
	for (x=0;x<ITW;x++){
	if(list[y*ITW+x] == 0){

		SSD = 0.0;
		for(i=0; i<TR[L-1] ;i++){
		for (j=0;j<TR[L-1] ;j++){
			temp = (double)(1.0*ImageSum[L-1][(y+2*i)*ImageWidth + (x+2*j)] - templateR[L-1][i*TR[L-1]+j]);
			SSD += temp*temp;
		}}
		
		//ssdlist[y*ITW + x] = SSD;
		if(SSD>=D)
			list[y*ITW+x] = 1;
	#ifdef TRACK_CANDIDATES
			NumCands++;
	#endif
	}}


#ifdef TRACK_CANDIDATES
	info->NumCand[k++] = NumCands;	// Number of candidates at each step
	NumCands=0;
#endif
	
//D = 1.0 * SsdThreshold * normA[L-1];
//	
//for (y=0;y<ITH;y++)
//for (x=0;x<ITW;x++){
//if( (ssdlist[y*ITW+x]>D) && (list[y*ITW+x] ==0) ){
//	#ifdef RETURN_STATS
//	skipped[L-1]++;
//	#endif
//	list[y*ITW+x] = 1;
//}}
	
//Final brute force for remaining candidates
	info->count = 0;
	for (y=0;y<ITH;y++)
	for (x=0;x<ITW;x++){
	if(list[y*ITW+x] == 0){
		
		SSD = 0.0;
		for(i=0; i<TemplateHeight ;i++){
		for (j=0;j<TemplateWidth;j++){
			temp = (double)(1.0*Image[(y+i)*ImageWidth + (x+j)] - Template[i*TemplateWidth+j]);
			SSD += temp*temp;
		}}
				
		if (SSD<SsdThreshold ) {
			info->match[info->count] = (int) SSD;
			info->xmatch[info->count]= y;
			info->ymatch[info->count]= x;
			info->count++;
		}
	#ifdef TRACK_CANDIDATES
			NumCands++;
	#endif
	}}
#ifdef TRACK_CANDIDATES
	info->NumCand[k] = NumCands;	// Number of candidates at each step
#endif
	
	free(templateR);
	free(ImageSum);

//free(ssdlist);
#ifdef ALLC_INLOOP
	for(i=0; i<L; i++){
		free(templateR[i]);
		free(ImageSum[i]);
	}
		free(ImageSum[L]);
	free(list);
#endif
	free(TR);
	free(normA);


#ifdef RETURN_STATS
// Statistics (if enabled during compilation)
	info->total_points=ITW*ITH;
/*for (k=0; k<L; k++){
	info->skipped_points[k]=skipped[k];
}*/
#endif

	return 0;
}


typedef struct TRectangle
{
   int  x0;
   int  y0;
   int  x1;
   int  y1;
} TRectangle ; 

int SsdLrpHierarchical(information *info){

unsigned char *Image=info->Image;
unsigned char *Template=info->Template;
int ImageWidth=info->ImageWidth;
int ImageHeight=info->ImageHeight;
int TemplateWidth=info->TemplateWidth;
int TemplateHeight=info->TemplateHeight;

int SsdThreshold = info->SsdThreshold;

#ifdef TRACK_CANDIDATES
	int NumCands;
#endif

int i,k,j;
int x,y;

//Number of levels
int L = info->N;

//Sizes of reduced templates
int *TR = (int *)malloc( (L+2) * sizeof(int));
int temp2 = 2;

int ITW=ImageWidth-TemplateWidth+1;
int ITH=ImageHeight-TemplateHeight+1;
double temp = 0.0;
double D;
double SSD;	
int is=0;

#ifdef ALLC_INLOOP
unsigned char *list = (unsigned char *) calloc ( ITW * ITH, sizeof (unsigned char) );
#else
unsigned char *list = BufList;
#endif
int *normA = (int *)malloc( L * sizeof(int));
int **templateR = (int **)malloc( L * sizeof(int *));
int **ImageSum = (int **)malloc( (L+1) * sizeof(int *));
int *pImageSum;

#ifdef RETURN_STATS
//printf("Warning: collecting stats...\n");
int skipped[12];
int c;
for(c = 0; c<L; c++)
	skipped[c] = 0;
#endif			

for(k=0; k<12; k++) 
	info->NumCand[k] = 0;
	
info->NumCand[0] = ITW * ITH;	// Number of candidates at each step

TR[0] = 1;
for(i=1; i<(L+2); i++){
	TR[i]=temp2;
	temp2 = temp2 * 2;
} 
#ifdef ALLC_INLOOP
for(i=0; i<L; i++)
	templateR[i] = (int *)malloc(TR[i] * TR[i] * sizeof(int) );
for(i=0; i<L+1; i++)
	ImageSum[i] = (int *)malloc((ImageHeight+1)*(ImageWidth+1)*sizeof(int));
#else
memset(list, 0, ITW * ITH);
for(i=0; i<L; i++)
	templateR[i] = BufTempl[i];
for(i=0; i<L+1; i++)
	ImageSum[i] = BufSum[i];
#endif
/*
for(i=0; i<L; i++)
	templateR[i] = (int *)malloc(TR[i] * TR[i] * sizeof(int) );
			
for(i=0; i<L+1; i++)
	ImageSum[i] = (int *)malloc((ImageHeight+1)*(ImageWidth+1)*sizeof(int));*/
	
temp2 = 4;
for(i=L-1; i>=0; i--){	
	normA[i] = temp2;
	temp2 = 4*temp2;	
}
	
// ################## BOX FILTERING ###################
//	CalcIntegral(Image, ImageSum[0], ImageSum[1], ImageHeight, ImageWidth);

//level L-1
HierarchicalSumUC(Image, ImageWidth, ImageHeight, 2, 2, ImageSum[L-1], TR[0]);
for(i=L-1; i>0; i--)
	HierarchicalSum(ImageSum[i], ImageWidth, ImageHeight, 2, 2, ImageSum[i-1], TR[L-i]);
 	
for(i=0; i<TR[L-1]; i++)
for (j=0;j<TR[L-1]; j++){
	templateR[L-1][i*TR[L-1] + j] = (int)(Template[2*i*TemplateWidth + 2*j]+Template[2*i*TemplateWidth + 2*j + 1] + Template[(2*i+1)*TemplateWidth + 2*j] + Template[(2*i+1)*TemplateWidth + 2*j + 1]);
}

for(k=L-2; k>=0; k--) 	
for(i=0; i<TR[k]; i++)
for (j=0;j<TR[k]; j++) {
	templateR[k][i*TR[k] + j] = (int)(templateR[k+1][2*i*TR[k+1] + 2*j]+templateR[k+1][2*i*TR[k+1] + 2*j + 1] + templateR[k+1][(2*i+1)*TR[k+1] + 2*j] + templateR[k+1][(2*i+1)*TR[k+1] + 2*j + 1]);
}
//All levels apart from the last one
for(k=0; k<L; k++){
#ifdef TRACK_CANDIDATES
	NumCands=0;
#endif

	D = 1.0 * SsdThreshold * normA[k];
	
	//Step 1: compute SSDs on low resolution candidates
	pImageSum = ImageSum[k];
//	pImageSum = ImageSum[k+1];
	
	for (y=0;y<ITH;y++)
	for (x=0;x<ITW;x++){
		if(list[y*ITW+x] == 0){	
			SSD = 0.0;
				
			for(i=0; i<TR[k] ;i++){
			for (j=0;j<TR[k];j++){
				temp = (double)(1.0*pImageSum[(y+TR[L-k]*i)*ImageWidth + (x+TR[L-k]*j)] - templateR[k][i*TR[k]+j]);
				SSD += temp*temp;
			}}

//	printf("Hierarchical SSD: %f\n", SSD);
			if (SSD>=D) 
				list[y*ITW+x] = 1;
//			else
//				{
//			}
			#ifdef TRACK_CANDIDATES
					NumCands++;
			#endif
		}
	}
	
#ifdef TRACK_CANDIDATES
	info->NumCand[k+1] = NumCands;	// Number of candidates at each step
//	printf("Hierarchical %d cands: %d\n", k+1, NumCands);
#endif
	} //k
	k=L;

//Final brute force for remaining candidates
#ifdef TRACK_CANDIDATES
	NumCands=0;
#endif

info->count = 0;
for (y=0;y<ITH;y++)
for (x=0;x<ITW;x++){
if(list[y*ITW+x] == 0){
	
	int SSD = 0;
	
	for(i=0; i<TemplateHeight ;i++){
	for (j=0;j<TemplateWidth;j++){
		int temp = Image[(y+i)*ImageWidth + (x+j)] - Template[i*TemplateWidth+j];
//		double temp = (double)(1.0*Image[(y+i)*ImageWidth + (x+j)] - Template[i*TemplateWidth+j]);
		SSD += temp*temp;
	}}
			
	if (SSD<SsdThreshold ) {
		info->match[info->count] = (int) SSD;
		info->xmatch[info->count]= y;
		info->ymatch[info->count]= x;
		info->count++;
	}
#ifdef TRACK_CANDIDATES
		NumCands++;
#endif
}}
#ifdef TRACK_CANDIDATES
	info->NumCand[k] = NumCands;	// Number of candidates at each step
#endif
	
#ifdef ALLC_INLOOP
for(i=0; i<L; i++){
	free(templateR[i]);
	free(ImageSum[i]);
}
	free(ImageSum[L]);
free(list);
#endif
free(templateR);
free(ImageSum);

//free(ssdlist);
free(TR);
free(normA);


#ifdef RETURN_STATS
// Statistics (if enabled during compilation)
info->total_points=ITW*ITH;
/*for (k=0; k<L; k++){
	info->skipped_points[k]=skipped[k];
}*/
#endif

return 0;
}

int SadLrpSAT(information *info){

	unsigned char *Image=info->Image;
	unsigned char *Template=info->Template;
	int ImageWidth=info->ImageWidth;
	int ImageHeight=info->ImageHeight;
	int TemplateWidth=info->TemplateWidth;
	int TemplateHeight=info->TemplateHeight;

TRectangle PosRect, PosRectNew;
int ExtraSize;
int *pImageSum;
int integralImgeW = ImageWidth+1;
	int SadThreshold = info->SsdThreshold;

	int i,k,j;
	int x,y;

	//Number of levels
	int L = info->N;

	//Sizes of reduced templates
	int *TR = (int *)malloc( (L+2) * sizeof(int));
	int temp2 = 2;
	int ITW=ImageWidth-TemplateWidth+1;
	int ITH=ImageHeight-TemplateHeight+1;
	double temp = 0.0;
	int D;
	int SAD;	
#ifdef ALLC_INLOOP
	unsigned char *list = (unsigned char *) calloc ( ITW * ITH, sizeof (unsigned char) );	
#else
	unsigned char *list = BufList;
#endif
	int **templateR = (int **)malloc( L * sizeof(int *));
	int **ImageSum = (int **)malloc( (L+1) * sizeof(int *));
#ifdef TRACK_CANDIDATES
	int NumCands=0;
#endif


	#ifdef RETURN_STATS
//	printf("Warning: collecting stats...\n");
	int totale_punti=ITW*ITH;
	int skipped[12];
	int c;
	for(c = 0; c<L; c++)
		skipped[c] = 0;
	#endif			

for(k=0; k<12; k++) info->NumCand[k] = 0;
	TR[0] = 1;
	for(i=1; i<(L+2); i++){
		TR[i]=temp2;
		temp2 = temp2 * 2;
	} 

#ifndef ALLC_INLOOP
memset(list, 0, ITW * ITH);
#endif

#ifdef ALLC_INLOOP
for(i=0; i<L; i++)
	templateR[i] = (int *)malloc(TR[i] * TR[i] * sizeof(int) );
			
for(i=0; i<L+1; i++)
	ImageSum[i] = (int *)malloc((ImageHeight+1)*(ImageWidth+1)*sizeof(int));
#else
for(i=0; i<L; i++)
	templateR[i] = BufTempl[i];
for(i=0; i<L+1; i++)
	ImageSum[i] = BufSum[i];
#endif


/*	for(i=0; i<L; i++)
   		BoxFilteringSum(Image, ImageWidth, ImageHeight, TR[L-i], TR[L-i], ImageSum[i]);
*/
	PosRect.x0 = PosRect.y0 = 0;
	PosRect.x1 = ITW;
	PosRect.y1 = ITH;
  	CalcIntegral(Image, ImageSum[0], ImageSum[1], ImageHeight, ImageWidth);
	
	for(i=0; i<TR[L-1]; i++)
	for (j=0;j<TR[L-1]; j++){
		templateR[L-1][i*TR[L-1] + j] = (int)(Template[2*i*TemplateWidth + 2*j]+Template[2*i*TemplateWidth + 2*j + 1] + Template[(2*i+1)*TemplateWidth + 2*j] + Template[(2*i+1)*TemplateWidth + 2*j + 1]);
	}

	for(k=L-2; k>=0; k--) 	
	for(i=0; i<TR[k]; i++)
	for (j=0;j<TR[k]; j++) {
		templateR[k][i*TR[k] + j] = (int)(templateR[k+1][2*i*TR[k+1] + 2*j]+templateR[k+1][2*i*TR[k+1] + 2*j + 1] + templateR[k+1][(2*i+1)*TR[k+1] + 2*j] + templateR[k+1][(2*i+1)*TR[k+1] + 2*j + 1]);
	}
	

for(k=0; k<L; k++){
#ifdef TRACK_CANDIDATES
	NumCands=0;
#endif

	D = SadThreshold;
	PosRectNew.x0 = PosRectNew.y0 = ITW;
	PosRectNew.x1 = 0;
	PosRectNew.y1 = 0;
	ExtraSize = (TR[k]-1)*TR[L-k];
	//All levels 
	{
		pImageSum = ImageSum[0];
		for (y=0;y<ITH;y++)
			for (x=0;x<ITW;x++)
			{
			if(list[y*ITW+x] == 0){	
			SAD = 0;
		
			for(i=0; i<TR[k] ;i++){
			for (j=0;j<TR[k];j++){
				int is = pImageSum[(y+(i+1)*TR[L-k])*integralImgeW+(x+TR[L-k]*(j+1))] + pImageSum[(y+i*TR[L-k])*integralImgeW+(x+TR[L-k]*j)] - pImageSum[(y+(i+1)*TR[L-k])*integralImgeW+(x+TR[L-k]*j)] - pImageSum[(y+i*TR[L-k])*integralImgeW+(x+TR[L-k]*(j+1))];	
				SAD += abs(is - templateR[k][i*TR[k]+j]);
			}}

			if( SAD>=D )
				list[y*ITW+x] = 1;
			else
			{
#ifdef TRACK_CANDIDATES
				NumCands++;
#endif
			}
			//ssdlist[y*ITW + x] = SSD;
			} 
		}
	}
	

#ifdef TRACK_CANDIDATES
	info->NumCand[k+1] = NumCands;	// Number of candidates at each step
#endif
	} //k

	//Final brute force for remaining candidates
	info->count = 0;
	
#ifdef TRACK_CANDIDATES
	info->NumCand[k++] = NumCands;	// Number of candidates at each step
	NumCands=0;
#endif
	for (y=0;y<ITH;y++)
	for (x=0;x<ITW;x++){
	if(list[y*ITW+x] == 0){
	
		SAD = 0;
		for(i=0; i<TemplateHeight ;i++){
		for (j=0;j<TemplateWidth;j++){
			SAD += abs(Image[(y+i)*ImageWidth + (x+j)] - Template[i*TemplateWidth+j]);
		}}
			
		if (SAD<SadThreshold ) {
			info->match[info->count] = SAD;
			info->xmatch[info->count]= y;
			info->ymatch[info->count]= x;
			info->count++;
		}
#ifdef TRACK_CANDIDATES
		NumCands++;
#endif
	}}
#ifdef TRACK_CANDIDATES
	info->NumCand[k++] = NumCands;	// Number of candidates at each step
#endif
	
	free(templateR);
	free(ImageSum);

#ifdef ALLC_INLOOP
	for(i=0; i<L; i++){
		free(templateR[i]);
		free(ImageSum[i]);
	}
	free(ImageSum[L]);
	free(list);
#endif
	free(TR);
	
	#ifdef RETURN_STATS
	// Statistics (if enabled during compilation)
	info->total_points=ITW*ITH;
/*	for (k=0; k<L; k++){
		info->skipped_points[k]=skipped[k];
	}*/
	#endif

return 0;
}

int SadLrpBF(information *info){

	unsigned char *Image=info->Image;
	unsigned char *Template=info->Template;
	int ImageWidth=info->ImageWidth;
	int ImageHeight=info->ImageHeight;
	int TemplateWidth=info->TemplateWidth;
	int TemplateHeight=info->TemplateHeight;

	int SadThreshold = info->SsdThreshold;

	int i,k,j;
	int x,y;

	//Number of levels
	int L = info->N;

	//Sizes of reduced templates
	int *TR = (int *)malloc( (L+2) * sizeof(int));
	int temp2 = 2;
	int ITW=ImageWidth-TemplateWidth+1;
	int ITH=ImageHeight-TemplateHeight+1;
	double temp = 0.0;
	int D;
	int SAD;	
#ifdef ALLC_INLOOP
	unsigned char *list = (unsigned char *) calloc ( ITW * ITH, sizeof (unsigned char) );	
#else
	unsigned char *list = BufList;
#endif
	int **templateR = (int **)malloc( L * sizeof(int *));
	int **ImageSum = (int **)malloc( (L+1) * sizeof(int *));
#ifdef TRACK_CANDIDATES
	int NumCands=0;
#endif


	#ifdef RETURN_STATS
//	printf("Warning: collecting stats...\n");
	int totale_punti=ITW*ITH;
	int skipped[12];
	int c;
	for(c = 0; c<L; c++)
		skipped[c] = 0;
	#endif			

for(k=0; k<12; k++) info->NumCand[k] = 0;
	TR[0] = 1;
	for(i=1; i<(L+2); i++){
		TR[i]=temp2;
		temp2 = temp2 * 2;
	} 

#ifndef ALLC_INLOOP
memset(list, 0, ITW * ITH);
#endif


#ifdef ALLC_INLOOP
for(i=0; i<L; i++)
	templateR[i] = (int *)malloc(TR[i] * TR[i] * sizeof(int) );
			
for(i=0; i<L+1; i++)
	ImageSum[i] = (int *)malloc((ImageHeight+1)*(ImageWidth+1)*sizeof(int));
#else
for(i=0; i<L; i++)
	templateR[i] = BufTempl[i];
for(i=0; i<L+1; i++)
	ImageSum[i] = BufSum[i];
#endif
		
//int normA[6] = {4096, 1024, 256, 64, 16, 4};
//int normA[L];
//temp2 = 4;
//for(i=L-1; i>=0; i--){	
//	normA[i] = temp2;
//	temp2 = 4*temp2;	
//}
	
//	for(i=0; i<L; i++)
//   		BoxFilteringSum(Image, ImageWidth, ImageHeight, TR[L-i], TR[L-i], ImageSum[i]);
// ################## SAT ###################
	CalcIntegral(Image, ImageSum[L], ImageSum[0], ImageHeight, ImageWidth);
for(i=0; i<L; i++)
	CalcRectSumByInt(ImageSum[L], ImageSum[i], TR[L-i], 0, 0, ITH+(TR[i]-1)*TR[L-i], ITW+(TR[i]-1)*TR[L-i], ImageWidth);	

  	
	for(i=0; i<TR[L-1]; i++)
	for (j=0;j<TR[L-1]; j++){
		templateR[L-1][i*TR[L-1] + j] = (int)(Template[2*i*TemplateWidth + 2*j]+Template[2*i*TemplateWidth + 2*j + 1] + Template[(2*i+1)*TemplateWidth + 2*j] + Template[(2*i+1)*TemplateWidth + 2*j + 1]);
	}

	for(k=L-2; k>=0; k--) 	
	for(i=0; i<TR[k]; i++)
	for (j=0;j<TR[k]; j++) {
		templateR[k][i*TR[k] + j] = (int)(templateR[k+1][2*i*TR[k+1] + 2*j]+templateR[k+1][2*i*TR[k+1] + 2*j + 1] + templateR[k+1][(2*i+1)*TR[k+1] + 2*j] + templateR[k+1][(2*i+1)*TR[k+1] + 2*j + 1]);
	}
	

	//All levels apart from the last one
	for(k=0; k<L-1; k++){
#ifdef TRACK_CANDIDATES
	NumCands=0;
#endif
		
		D = SadThreshold;
		
		//FASE 3: PRUNING;
		for (y=0;y<ITH;y++)
		for (x=0;x<ITW;x++){
		if(list[y*ITW+x] ==0){
			
			SAD = 0;
			
			for(i=0; i<TR[k] ;i++){
			for (j=0;j<TR[k];j++){
				SAD += abs(ImageSum[k][(y+TR[L-k]*i)*ImageWidth + (x+TR[L-k]*j)] - templateR[k][i*TR[k]+j]);
			}}

			if (SAD>=D)
				list[y*ITW+x] = 1;
#ifdef TRACK_CANDIDATES
		NumCands++;
#endif
	}}
#ifdef TRACK_CANDIDATES
	info->NumCand[k] = NumCands;	// Number of candidates at each step
#endif
	}
	
	//Last level
	D = SadThreshold;
#ifdef TRACK_CANDIDATES
	NumCands=0;
#endif
	
	for (y=0;y<ITH;y++)
	for (x=0;x<ITW;x++){
	if(list[y*ITW+x] ==0){
	
		SAD = 0;
		for(i=0; i<TR[L-1] ;i++){
		for (j=0;j<TR[L-1] ;j++){
			SAD += abs(ImageSum[L-1][(y+2*i)*ImageWidth + (x+2*j)] - templateR[L-1][i*TR[L-1]+j]);
		}}
		
		if(SAD>=D)
			list[y*ITW+x] = 1;
#ifdef TRACK_CANDIDATES
		NumCands++;
#endif
	}}
	
	//Final brute force for remaining candidates
	info->count = 0;
	
#ifdef TRACK_CANDIDATES
	info->NumCand[k++] = NumCands;	// Number of candidates at each step
	NumCands=0;
#endif
	for (y=0;y<ITH;y++)
	for (x=0;x<ITW;x++){
	if(list[y*ITW+x] == 0){
	
		SAD = 0;
		for(i=0; i<TemplateHeight ;i++){
		for (j=0;j<TemplateWidth;j++){
			SAD += abs(Image[(y+i)*ImageWidth + (x+j)] - Template[i*TemplateWidth+j]);
		}}
			
		if (SAD<SadThreshold ) {
			info->match[info->count] = SAD;
			info->xmatch[info->count]= y;
			info->ymatch[info->count]= x;
			info->count++;
		}
#ifdef TRACK_CANDIDATES
		NumCands++;
#endif
	}}
#ifdef TRACK_CANDIDATES
	info->NumCand[k++] = NumCands;	// Number of candidates at each step
#endif
	
	free(templateR);
	free(ImageSum);

#ifdef ALLC_INLOOP
	for(i=0; i<L; i++){
		free(templateR[i]);
		free(ImageSum[i]);
	}
	free(ImageSum[L]);
	free(list);
#endif
	free(TR);
	
	#ifdef RETURN_STATS
	// Statistics (if enabled during compilation)
	info->total_points=ITW*ITH;
/*	for (k=0; k<L; k++){
		info->skipped_points[k]=skipped[k];
	}*/
	#endif

return 0;
}

int SadLrpHierarchical(information *info){

	unsigned char *Image=info->Image;
	unsigned char *Template=info->Template;
	int ImageWidth=info->ImageWidth;
	int ImageHeight=info->ImageHeight;
	int TemplateWidth=info->TemplateWidth;
	int TemplateHeight=info->TemplateHeight;

	int SadThreshold = info->SsdThreshold;

	int i,k,j;
	int x,y;

	//Number of levels
	int L = info->N;

	//Sizes of reduced templates
	int *TR = (int *)malloc( (L+2) * sizeof(int));
	int temp2 = 2;
	int ITW=ImageWidth-TemplateWidth+1;
	int ITH=ImageHeight-TemplateHeight+1;
	double temp = 0.0;
	int D;
	int SAD;	
#ifdef ALLC_INLOOP
	unsigned char *list = (unsigned char *) calloc ( ITW * ITH, sizeof (unsigned char) );	
#else
	unsigned char *list = BufList;
#endif
	int **templateR = (int **)malloc( L * sizeof(int *));
	int **ImageSum = (int **)malloc( (L+1) * sizeof(int *));
#ifdef TRACK_CANDIDATES
	int NumCands=0;
#endif


	#ifdef RETURN_STATS
//	printf("Warning: collecting stats...\n");
	int totale_punti=ITW*ITH;
	int skipped[12];
	int c;
	for(c = 0; c<L; c++)
		skipped[c] = 0;
	#endif			

for(k=0; k<12; k++) info->NumCand[k] = 0;
	TR[0] = 1;
	for(i=1; i<(L+2); i++){
		TR[i]=temp2;
		temp2 = temp2 * 2;
	} 

#ifndef ALLC_INLOOP
memset(list, 0, ITW * ITH);
#endif


#ifdef ALLC_INLOOP
for(i=0; i<L; i++)
	templateR[i] = (int *)malloc(TR[i] * TR[i] * sizeof(int) );
			
for(i=0; i<L+1; i++)
	ImageSum[i] = (int *)malloc((ImageHeight+1)*(ImageWidth+1)*sizeof(int));
#else
for(i=0; i<L; i++)
	templateR[i] = BufTempl[i];
for(i=0; i<L+1; i++)
	ImageSum[i] = BufSum[i];
#endif
		
// ################## HIERARCHICAL METHOD ###################
 	//level L-1
	HierarchicalSumUC(Image, ImageWidth, ImageHeight, 2, 2, ImageSum[L-1], TR[0]);
	//other levels..
	for(i=L-1; i>0; i--)
		HierarchicalSum(ImageSum[i], ImageWidth, ImageHeight, 2, 2, ImageSum[i-1], TR[L-i]);

	for(i=0; i<TR[L-1]; i++)
	for (j=0;j<TR[L-1]; j++){
		templateR[L-1][i*TR[L-1] + j] = (int)(Template[2*i*TemplateWidth + 2*j]+Template[2*i*TemplateWidth + 2*j + 1] + Template[(2*i+1)*TemplateWidth + 2*j] + Template[(2*i+1)*TemplateWidth + 2*j + 1]);
	}

	for(k=L-2; k>=0; k--) 	
	for(i=0; i<TR[k]; i++)
	for (j=0;j<TR[k]; j++) {
		templateR[k][i*TR[k] + j] = (int)(templateR[k+1][2*i*TR[k+1] + 2*j]+templateR[k+1][2*i*TR[k+1] + 2*j + 1] + templateR[k+1][(2*i+1)*TR[k+1] + 2*j] + templateR[k+1][(2*i+1)*TR[k+1] + 2*j + 1]);
	}
	

	//All levels apart from the last one
	for(k=0; k<L; k++){
#ifdef TRACK_CANDIDATES
	NumCands=0;
#endif
		
		D = SadThreshold;
		
		//FASE 3: PRUNING;
		for (y=0;y<ITH;y++)
		for (x=0;x<ITW;x++){
		if(list[y*ITW+x] ==0){
			
			SAD = 0;
			
			for(i=0; i<TR[k] ;i++){
			for (j=0;j<TR[k];j++){
				SAD += abs(ImageSum[k][(y+TR[L-k]*i)*ImageWidth + (x+TR[L-k]*j)] - templateR[k][i*TR[k]+j]);
			}}

			if (SAD>=D)
				list[y*ITW+x] = 1;
#ifdef TRACK_CANDIDATES
		NumCands++;
#endif
	}}
#ifdef TRACK_CANDIDATES
	info->NumCand[k] = NumCands;	// Number of candidates at each step
#endif
	}
		
	//Final brute force for remaining candidates
	info->count = 0;
	
#ifdef TRACK_CANDIDATES
	info->NumCand[k++] = NumCands;	// Number of candidates at each step
	NumCands=0;
#endif
	for (y=0;y<ITH;y++)
	for (x=0;x<ITW;x++){
	if(list[y*ITW+x] == 0){
	
		SAD = 0;
		for(i=0; i<TemplateHeight ;i++){
		for (j=0;j<TemplateWidth;j++){
			SAD += abs(Image[(y+i)*ImageWidth + (x+j)] - Template[i*TemplateWidth+j]);
		}}
			
		if (SAD<SadThreshold ) {
			info->match[info->count] = SAD;
			info->xmatch[info->count]= y;
			info->ymatch[info->count]= x;
			info->count++;
		}
#ifdef TRACK_CANDIDATES
		NumCands++;
#endif
	}}
#ifdef TRACK_CANDIDATES
	info->NumCand[k++] = NumCands;	// Number of candidates at each step
#endif
	
	free(templateR);
	free(ImageSum);

#ifdef ALLC_INLOOP
	for(i=0; i<L; i++){
		free(templateR[i]);
		free(ImageSum[i]);
	}
	free(ImageSum[L]);
	free(list);
#endif
	free(TR);
	
	#ifdef RETURN_STATS
	// Statistics (if enabled during compilation)
	info->total_points=ITW*ITH;
/*	for (k=0; k<L; k++){
		info->skipped_points[k]=skipped[k];
	}*/
	#endif

return 0;
}
