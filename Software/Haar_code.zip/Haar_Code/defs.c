/*****************************************************************************
  *           Real Time Motion Estimation Using Gray Code Kernels            *
 *****************************************************************************
 * file:        defs.c                                                       *
 *                                                                           *
 * description: Project's common definitions.                                *
 *****************************************************************************/

#include <stdlib.h>
#include <stdio.h>


///////////////////////////////// FUNCTIONS /////////////////////////////////


/*****************************************************************************
 * Prints the given error message and halts the program.	                 *
 *****************************************************************************/
void exitWithError(char *message) {
    printf("%s\n", message);  
    exit(1);
}
