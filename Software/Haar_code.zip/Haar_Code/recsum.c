#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "recsum.h"


void CalcIntegral(BYTE* Input, int *Intgr, int HEIGHT, int WIDTH)
{
//start computing integral image
 //Notice that WIDTH and HEIGHT might not be the original size
 int x, y;
// int *pIntgrTmpl;
 int integralImgeH;
 int integralImgeW;
 integralImgeW = WIDTH + 1;
 integralImgeH = HEIGHT+1;

// pIntgrTmpl = Intgr;
 for (x = 0; x<integralImgeW; x++)
 {
	 Intgr[x] = 0;
 }


 for (y=1; y<integralImgeH; y++)//i: y   j: x
 {
	 int OneRowSum;
	 Intgr[y*integralImgeW]=0;
	 for (OneRowSum=0, x=1; x<integralImgeW; x++)
	 {
		 int t = Input[(y-1)*WIDTH+x-1];
		 OneRowSum += t;
		 Intgr[y*integralImgeW+x]= Intgr[(y-1)*integralImgeW+x]+OneRowSum;
	 }
 }
}

void CalcHStripSum(int* IntgrTmpl, int *StpSumTmpl, int N2, int HEIGHT, int WIDTH)
{
	int col, row;
	HEIGHT = HEIGHT - N2 + 1;
	for (row=0; row<HEIGHT; row++)//i: row   j: col
		for (col=0; col<WIDTH; col++)
		{
			StpSumTmpl[row*WIDTH+col] = IntgrTmpl[(row+N2)*WIDTH+col] - IntgrTmpl[row*WIDTH+col];
		}

}

void CalcRectSumByHStrip(int *StripSum, int *Proj, int N1, int rows, int cols, int WIDTH)
{
	int row, col;
	int integralImgeW;
	integralImgeW = WIDTH + 1;
	for (row = 0; row < rows; row++)
		for (col = 0; col < cols; col++)
		{
			Proj[row*integralImgeW+col] = StripSum[row*integralImgeW+col+N1] -  StripSum[row*integralImgeW+col];
		}
}

void CalcRectSumByHStrip2(int* IntgrTmpl, int *StripSum, int *Proj, int N1, int N2, int rows, int cols, int WIDTH)
{
	int row, col;
	for (row = 0; row < rows; row++)
	{
		for (col = 0; col < N1; col++)
			Proj[row*WIDTH+col] =IntgrTmpl[row*WIDTH+col] - IntgrTmpl[(row+N2)*WIDTH+col];
		for (; col < cols+N1; col++)
		{
			int strip1;
			Proj[row*WIDTH+col] = strip1 =IntgrTmpl[row*WIDTH+col] - IntgrTmpl[(row+N2)*WIDTH+col];
			Proj[row*WIDTH+col-N1] -= strip1;
		}
	}
}


void CalcRectSumByInt(int* IntgrTmpl, int *StripSum, int *Proj, int N1, int rows, int cols, int WIDTH)
{
	int row, col;
	int integralImgeW;
	int N2 = N1;
	integralImgeW = WIDTH + 1;
	for (row = 0; row < rows; row++)
	{
		for (col=0; col<integralImgeW; col++)
		{
			Proj[row*integralImgeW+col] = IntgrTmpl[(row+N2)*integralImgeW+col+N1] - IntgrTmpl[row*integralImgeW+col+N1] -  (IntgrTmpl[(row+N2)*integralImgeW+col] - IntgrTmpl[row*integralImgeW+col]);
		}
	}
}
