#include "defs.h"
#include "HaarMatch.h"
#include "recsum.h"
#include <stdlib.h>
#include <stdio.h>
#include <memory.h> 
int32 matchesCol[1280*960];
int32 matchesRow[1280*960];
distanceT matchesDist[1280*960];



// Compute 2 Haar-like features in a sliding window manner using strip sum
// For example, OHT basis 1, 2, 3
// A Haar-like feature may correspond to multiple OHT bases. 
// For example, the 2nd Haar-like feature correspond to OHT bases 2, 3
#ifdef INLINE_HAAR
__inline
#endif
 void Compute2HaarProjs_SLD(int* IntgrImg, int **Proj, int *StripSum, int startIdx, int BlkSize, int rows, int cols, int width, int StartRow)
{
	int *proj0, *proj1;
	int row, col;
	int BlkSizeby2 = BlkSize << 1;
	proj0 = Proj[startIdx];
	proj1 = Proj[startIdx+1];
	cols -= BlkSize;

	for (row=StartRow; row < StartRow+rows; row++)
	{
		for (col = 0; col < cols+BlkSizeby2; col++)//buffering. Strip sum of one row is required
			StripSum[col] = IntgrImg[(row+BlkSize)*width+col] - IntgrImg[row*width+col];
		for (col = 0; col < cols+BlkSize; col++)
			proj1[row*width+col] = StripSum[col+BlkSize] -  StripSum[col];
		for (col = 0; col < cols; col++)
		{
			proj1[row*width+col] -= proj1[row*width+col+BlkSize];
		}
		for (col = 0; col < cols; col++)
		{
			proj0[row*width+col] = StripSum[col+BlkSizeby2] -  StripSum[col]; // the first Haar-like feature. For example, for OHT basis (1), (4, 5, 6, 7)
		}
		if (row>=StartRow+BlkSize)
			for (col = 0; col < cols; col++)
			{
				proj0[(row-BlkSize)*width+col] -= proj0[(row)*width+col]; // the second Haar-like feature. For example, for OHT basis (2,3), (8, 9, ..., 15)
			}
	}
}


// Compute 2 Haar-like features in a sliding window manner using integral image
// For example, OHT basis 1, 2, 3
// A Haar-like feature may correspond to multiple OHT bases. 
// For example, the 2nd Haar-like feature correspond to OHT bases 2, 3
#ifdef INLINE_HAAR
__inline
#endif
 void Compute2HaarProjs_INT(int **Proj, int *Intgr, int startIdx, int BlkSize, int rows, int cols, int width)
{
	int *proj0, *proj1;
	int row, col;
	int BlkSizeby2 = BlkSize << 1;
	int integralImgeW = width + 1;
	proj0 = Proj[startIdx];
	proj1 = Proj[startIdx+1];
	cols -= BlkSize;
	rows -= BlkSize;
	for (row = 0; row < rows; row++)
	{
		int StripSum1, StripSum2, StripSum3, StripSum4;
			int dc1, dc2;
		for (col = 0; col < cols; col++)
		{
			StripSum1 = Intgr[(row+BlkSize)*integralImgeW+col+BlkSizeby2] - Intgr[row*integralImgeW+col+BlkSizeby2];
			StripSum2 = Intgr[(row+BlkSize)*integralImgeW+col]-Intgr[row*integralImgeW+col];
			dc1 = StripSum1 - StripSum2;
			StripSum1 = Intgr[(row+BlkSize+BlkSize)*integralImgeW+col+BlkSizeby2] - Intgr[(row+BlkSize)*integralImgeW+col+BlkSizeby2];
			StripSum2 = Intgr[(row+BlkSize+BlkSize)*integralImgeW+col]-Intgr[(row+BlkSize)*integralImgeW+col];
			dc2 = StripSum1 - StripSum2;
			proj0[row*integralImgeW+col] = dc1 - dc2; // the first Haar-like feature. For example, for OHT basis (1), (4, 5, 6, 7)


			StripSum3 = Intgr[(row+BlkSize)*integralImgeW+col+BlkSize]-Intgr[row*integralImgeW+col+BlkSize];
			StripSum4 = Intgr[(row+BlkSize)*integralImgeW+col]-Intgr[row*integralImgeW+col];
			dc1 = StripSum3 - StripSum4;
			StripSum3 = Intgr[(row+BlkSize)*integralImgeW+col+BlkSize+BlkSize]-Intgr[(row)*integralImgeW+col+BlkSize+BlkSize];
			StripSum4 = Intgr[(row+BlkSize)*integralImgeW+col+BlkSize]-Intgr[(row)*integralImgeW+col+BlkSize];
			dc2 = StripSum3 - StripSum4;
			proj1[row*integralImgeW+col] = dc1 - dc2; // the second Haar-like feature. For example, for OHT basis (2,3), (8, 9, ..., 15)
		}
	}
	for (; row < rows+BlkSize; row++)
		for (col = 0; col < cols; col++)
		{
			int  StripSum3, StripSum4;
			int dc1, dc2;
			StripSum3 = Intgr[(row+BlkSize)*integralImgeW+col+BlkSize]-Intgr[row*integralImgeW+col+BlkSize];
			StripSum4 = Intgr[(row+BlkSize)*integralImgeW+col]-Intgr[row*integralImgeW+col];
			dc1 = StripSum3 - StripSum4;
			StripSum3 = Intgr[(row+BlkSize)*integralImgeW+col+BlkSize+BlkSize]-Intgr[(row)*integralImgeW+col+BlkSize+BlkSize];
			StripSum4 = Intgr[(row+BlkSize)*integralImgeW+col+BlkSize]-Intgr[(row)*integralImgeW+col+BlkSize];
			dc2 = StripSum3 - StripSum4;
			proj1[row*integralImgeW+col] = dc1 - dc2;
		}


}

// Compute 2 Haar-like features in random access manner using integral image. Only used for template in this code
// For example, OHT basis 1, 2, 3
// A Haar-like feature may correspond to multiple OHT bases. 
// For example, the 2nd Haar-like feature correspond to OHT bases 2, 3
#ifdef INLINE_HAAR
__inline
#endif
 void Compute2HaarProjsJump_INT(int **Proj, int *Intgr, int startIdx, int BlkSize, int rowStart, int colStart, int rows, int cols, int width)
{
	int *proj0, *proj1;
	int row, col;
	int BlkSizeby2 = BlkSize << 1;
	int integralImgeW = width + 1;
// 0 1
// 2 3
	
	proj0 = Proj[startIdx];
	proj1 = Proj[startIdx+1];
	cols -= BlkSize;
	rows -= BlkSize;
	for (row = rowStart; row < rows; row+=BlkSizeby2)
	{
		int StripSum1, StripSum2;
			int dc1, dc2;
		for (col = colStart; col < cols; col+=BlkSizeby2)
		{
			StripSum1 = Intgr[(row+BlkSize)*integralImgeW+col+BlkSizeby2] - Intgr[row*integralImgeW+col+BlkSizeby2];
			StripSum2 = Intgr[(row+BlkSize)*integralImgeW+col]-Intgr[row*integralImgeW+col];
			dc1 = StripSum1 - StripSum2;

			StripSum1 = Intgr[(row+BlkSize+BlkSize)*integralImgeW+col+BlkSizeby2] - Intgr[(row+BlkSize)*integralImgeW+col+BlkSizeby2];
			StripSum2 = Intgr[(row+BlkSize+BlkSize)*integralImgeW+col]-Intgr[(row+BlkSize)*integralImgeW+col];
			dc2 = StripSum1 - StripSum2;
			proj0[row*integralImgeW+col] = dc1-dc2;
		}

	}
	for (row = rowStart; row < rows+BlkSize; row+=BlkSize)
		for (col = colStart; col < cols+BlkSize; col+=BlkSizeby2)
		{
			int StripSum3, StripSum4;
			int dc1, dc2;
			StripSum3 = Intgr[(row+BlkSize)*integralImgeW+col+BlkSize]-Intgr[row*integralImgeW+col+BlkSize];
			StripSum4 = Intgr[(row+BlkSize)*integralImgeW+col]-Intgr[row*integralImgeW+col];
			dc1 = StripSum3 - StripSum4;

			StripSum3 = Intgr[(row+BlkSize)*integralImgeW+col+BlkSize+BlkSize]-Intgr[row*integralImgeW+col+BlkSize+BlkSize];
			StripSum4 = Intgr[(row+BlkSize)*integralImgeW+col+BlkSize]-Intgr[row*integralImgeW+col+BlkSize];
			dc2 = StripSum3 - StripSum4;
			proj1[row*integralImgeW+col] = dc1-dc2;
		}

}

// Compute 2 Haar-like features in random access manner using strip sum. Only used for template in this code
// For example, OHT basis 1, 2, 3
// A Haar-like feature may correspond to multiple OHT bases. 
// For example, the 2nd Haar-like feature correspond to OHT bases 2, 3
#ifdef INLINE_HAAR
__inline
#endif
 void Compute2HaarProjsJump_STP(int **Proj, int *Intgr, int startIdx, int BlkSize, int rows, int cols, int width)
{
	int *proj0, *proj1;
	int row, col;
	int BlkSizeby2 = BlkSize << 1;
	int integralImgeW = width + 1;
	
	proj0 = Proj[startIdx];
	proj1 = Proj[startIdx+1];
	cols -= BlkSize;
	for (row = 0; row < rows; row+=BlkSize)
	{
		int StripSum1, StripSum2, StripSum3, StripSum4;
		for (col = 0; col < cols; col+=BlkSize)
		{
			StripSum1 = Intgr[(row+BlkSize)*integralImgeW+col+BlkSizeby2] - Intgr[row*integralImgeW+col+BlkSizeby2];
			StripSum2 = Intgr[(row+BlkSize)*integralImgeW+col]-Intgr[row*integralImgeW+col];
			proj0[row*integralImgeW+col] = StripSum1 - StripSum2;

		}
		for (col = 0; col < cols+BlkSize; col+=BlkSize)
		{
			StripSum3 = Intgr[(row+BlkSize)*integralImgeW+col+BlkSize]-Intgr[row*integralImgeW+col+BlkSize];
			StripSum4 = Intgr[(row+BlkSize)*integralImgeW+col]-Intgr[row*integralImgeW+col];
			proj1[row*integralImgeW+col] = StripSum3 - StripSum4;
		}
	}
// a0 a1
// a2 a3
// proj0: a0+a1-a2-a3   proj1: a0-a1

	rows -= BlkSize;
	for (row = 0; row < rows; row+=BlkSizeby2)
		for (col = 0; col < cols; col+=BlkSizeby2)
		{
			proj0[row*integralImgeW+col] -= proj0[(row+BlkSize)*integralImgeW+col];
		}
	for (row = 0; row < rows+BlkSize; row+=BlkSize)
		for (col = 0; col < cols; col+=BlkSizeby2)
		{
			proj1[row*integralImgeW+col] -= proj1[row*integralImgeW+col+BlkSize];
		}
}




extern u_int32 SqrDiff[2*MAX_DIFF+1];
__inline u_int32 calcSSD2(u_int8 *sourcePtr, int32 sourceDif, u_int8 *destPtr, u_int16 destDif, int BLOCK_SIZE_IMG) 
{
	 
	  register u_int32 sad;
	  register u_int16 cols;
	  register u_int16 rows;
	  u_int32 *pSqrDiff = SqrDiff+MAX_DIFF;
	 sad = 0;

	 rows = BLOCK_SIZE_IMG;
     cols = BLOCK_SIZE_IMG;

	 do {
		 do { 
			 sad += pSqrDiff[*destPtr-*sourcePtr];
			sourcePtr++;
			destPtr++;
			cols--;
		 }while(cols!=0);		
		 sourcePtr += sourceDif;
		 destPtr += destDif;
		 cols = BLOCK_SIZE_IMG;
		 rows--;
	 } while(rows!=0);
	 return sad;
 }

//Pattern matching using OHT. OHT computed by strip sum
char listMem[1280*960];
void HaarPatternMatch(HaarSetup *setup)
{
	int i, j, loop;
	int L = setup->L;
	int rows, cols;
	int row, col;
	int size;
	BYTE *Template = setup->Template;
	BYTE *Image = setup->Image;
	int *TR = setup->TR;
	int ImageWidth = setup->ImageWidth;
	int ImageHeight = setup->ImageHeight;
	int PatternSize = setup->TemplateHeight;
	float *ssdlist = setup->ssdlist;
	char *Skipped = setup->Skipped;
	int *ImgProj;
	int *TplProj;
	int AbsProjThreshold=setup->Threshold*PatternSize*PatternSize;
	float SqrProjThreshold;
	u_int32 SsdThreshold;
	int TemplateWidth = setup->TemplateWidth;
	int TemplateHeight = setup->TemplateHeight;
	int suspectedCount, suspectedTotal;
	int SkippedCount;
	int JumpCount = (int) (setup->Percent*ImageWidth*ImageHeight+1);
	int integralImgeW;
	int integralTmplW;
	int count=0;
	
	int NumProjs = (ImageWidth-PatternSize+1)*(ImageHeight-PatternSize+1);
	int EndCol;
	int32 *pmatchesCol = &matchesCol[1];
	int32 *pmatchesRow = matchesRow;
	char *list = listMem;
	float* pmatchesDist = matchesDist;
	integralImgeW = ImageWidth + 1;
	integralTmplW = PatternSize+1;
	memset(list, 1, sizeof(char)*ImageWidth*ImageHeight);

	matchesCol[0]=-1000;
	// Calculate integral image
	CalcIntegral(setup->Template, setup->IntegralTmpl, TemplateHeight, TemplateWidth);//???
	CalcIntegral(setup->Image, setup->IntegralImg, ImageHeight, ImageWidth);
	size = setup->TR[L];
	size = setup->TR[L];
	//The 0th OHT (DC component) for template
	setup->TemplateProj[0][0] = setup->IntegralTmpl[size*integralTmplW+size] - setup->IntegralTmpl[size] -  (setup->IntegralTmpl[size*integralTmplW] - setup->IntegralTmpl[0]);

	rows = setup->ImageHeight - size + 1;
	cols = setup->ImageWidth  - size  + 1;
	//The 0th OHT (DC component) for image
	CalcRectSumByHStrip2(setup->IntegralImg, setup->StripSumImg[0], setup->ImageProj[0], size, size, rows, cols, integralImgeW);
	setup->OPs = NumProjs*4;//Interal image and the first rectangle sum
	setup->OPs += NumProjs * 3; //distance for the first projection


	ImgProj = setup->ImageProj[0];
	TplProj = setup->TemplateProj[0];
	suspectedCount = 0;
	SkippedCount = 0;
	EndCol = 0;
	for (row=0; row<rows; row++)
	{
		for (col=0; col<cols; col++)
		{
			int idiff = abs(ImgProj[row*integralImgeW + col] - TplProj[0]);
			if (idiff < AbsProjThreshold)
			{
				float fdiff = (float)idiff;
				pmatchesCol[suspectedCount] = col;
				pmatchesRow[suspectedCount] = row;
				pmatchesDist[suspectedCount]  = fdiff * fdiff;
				suspectedCount++;
			}
			else
				list[row*integralImgeW + col] = 0;
		}
		if (pmatchesCol[suspectedCount-1] > EndCol) 
			EndCol = pmatchesCol[suspectedCount-1];
	}
	suspectedTotal = suspectedCount;
#ifdef SHOW_MY_STATS
	printf("in HAAR_STP Proj 0 suspectedCount %d \n", suspectedCount);
#endif
	SqrProjThreshold = (float) AbsProjThreshold;
	SqrProjThreshold *= SqrProjThreshold;
	suspectedCount = 0;
	i = 1;
	j = 0;
	for (i=1; (i<L)&&(suspectedTotal >= JumpCount); i++)
	{
		//The projection for template
		int MultVal;
		int ShiftVal;
		int JumpOPs, SldOPs;
		int StartRow, EndRow;
		ShiftVal = (i-1)<<1;
		size = TR[L-i];

		MultVal = TR[i-1];
		MultVal *= MultVal;
		JumpOPs = size*size*suspectedTotal*2;

		rows = TemplateHeight - size + 1;
		cols = TemplateWidth  - size  + 1;
		Compute2HaarProjsJump_STP(setup->TemplateProj, setup->IntegralTmpl, i*2-1, size, rows, cols, TemplateWidth);
		StartRow = pmatchesRow[0];
		EndRow = pmatchesRow[suspectedTotal-1];
		rows = EndRow-StartRow+1+TR[L] - size;
		if (rows > setup->ImageHeight - size + 1)
			rows = setup->ImageHeight - size + 1;
		cols = EndCol + 1 + TR[L] - size;
		if (cols > setup->ImageWidth  - size  + 1)
			cols = setup->ImageWidth  - size  + 1;
		NumProjs = cols * rows;
		SldOPs = 5*NumProjs;
		JumpOPs = 13*TR[i-1]*TR[i-1]*suspectedTotal;
		{
			//Use Strip sum to compute OHT for images
			setup->OPs += SldOPs; //Projection
			Compute2HaarProjs_SLD(setup->IntegralImg, setup->ImageProj, setup->StripSumImg[0], i*2-1, size, rows, cols, integralImgeW, StartRow);

			size <<= 1;
			// Compute lower bound and eliminate mismatching windows
			for (j = 0; (j<2); j++) // for the 2 Haar-like features computed
			{
				int rblk, cblk;
				int blkSize = TR[i-1];
				int sizeRow, sizeCol;
				sizeRow = size>>j;
				sizeCol = size;
				MultVal <<= j;
//				ShiftVal += j;
				setup->OPs += ((3*blkSize*blkSize*suspectedTotal)<<j)+suspectedTotal; // Distance + normalization
				ImgProj = setup->ImageProj[i*2-1+j];
				TplProj = setup->TemplateProj[i*2-1+j];
				suspectedCount = 0;
				SkippedCount = 0;
				for (loop = 0; loop < suspectedTotal; loop++)
				{
					float diff;
					float Accdiff=0;
					row = pmatchesRow[loop]; 
					col = pmatchesCol[loop];
					for (rblk = 0; rblk < (blkSize<<j); rblk++)
						for (cblk = 0; cblk < blkSize; cblk++)
						{ 
							diff = (float) (ImgProj[(row+sizeRow*rblk)*integralImgeW + (col+sizeCol*cblk)] - TplProj[sizeRow*rblk*integralTmplW+sizeCol*cblk]);
							Accdiff += diff * diff;
						}
//					Accdiff <<= ShiftVal;
					Accdiff *= MultVal; //This can be implemented by shifting as above, although implemented by multiplication here
					Accdiff += pmatchesDist[loop]; //Lower bound is obtained now
					if (Accdiff < SqrProjThreshold)
					{
						// The candidate remain in the set of candidates
						pmatchesCol[suspectedCount] = col;
						pmatchesRow[suspectedCount] = row;
						pmatchesDist[suspectedCount]  = Accdiff;
						suspectedCount++;
					}
					else
						// eliminate mismatching windows
						list[row*integralImgeW + col] = 0;
				}
				suspectedTotal = suspectedCount;
	#ifdef SHOW_MY_STATS
				printf("in HAAR_STP full level %d suspectedCount %d Skipped %d\n", i*2-1+j, suspectedCount, SkippedCount);
	#endif
			}
		}

	}
	setup->count = 0;
	size = setup->TR[L];
	SsdThreshold = (int) (SqrProjThreshold/(PatternSize*PatternSize));
	if ( (2*(i-1)+j-2) > 0)
		setup->BasesComputed = 1<<(2*(i-1));
	else
		setup->BasesComputed = 1<<(2*(i-1));
#if COUNT_SSDOPS
	setup->OPs += 3*(double)suspectedTotal * TemplateWidth*TemplateHeight;// actual distance
#endif;

	// Remaining candidates undergo FS
	for (loop = 0; loop < suspectedTotal; loop++)
	{	
		u_int32 SSD;
		row = pmatchesRow[loop]; 
		col = pmatchesCol[loop];
		SSD = calcSSD2(&Image[row*ImageWidth+col], ImageWidth-TemplateWidth, Template, 0, size);
				
		if (SSD<SsdThreshold ) {
			setup->match[setup->count] = SSD;
			setup->xmatch[setup->count]= row;
			setup->ymatch[setup->count]= col;
			setup->count++;
		}
	}
}

//Pattern matching using OHT. OHT computed by integral image
void HaarPatternMatch_INT(HaarSetup *setup)
{
	int i, j, loop;
	int L = setup->L;
	int rows, cols;
	int row, col;
	int size;
	BYTE *Template = setup->Template;
	BYTE *Image = setup->Image;
	int *TR = setup->TR;
	int ImageWidth = setup->ImageWidth;
	int ImageHeight = setup->ImageHeight;
	int PatternSize = setup->TemplateHeight;
	float *ssdlist = setup->ssdlist;
	char *Skipped = setup->Skipped;
	int *ImgProj;
	int *TplProj;
	int AbsProjThreshold=setup->Threshold*PatternSize*PatternSize;
	float SqrProjThreshold;
	u_int32 SsdThreshold;
	int TemplateWidth = setup->TemplateWidth;
	int TemplateHeight = setup->TemplateHeight;
	int suspectedCount, suspectedTotal;
	int SkippedCount;
	int JumpCount = (int) (setup->Percent*ImageWidth*ImageHeight+1);
	int integralImgeW;
	int integralTmplW;
	
	int NumProjs = (ImageWidth-PatternSize+1)*(ImageHeight-PatternSize+1);
	int32 *pmatchesCol = matchesCol;
	int32 *pmatchesRow = matchesRow;
	distanceT* pmatchesDist = matchesDist;
	integralImgeW = ImageWidth + 1;
	integralTmplW = PatternSize+1;
	memset(ssdlist, 0, sizeof(float)*ImageWidth*ImageHeight);
	memset(Skipped, 0, sizeof(char)*ImageWidth*ImageHeight);
	// Calculate integral image
	CalcIntegral(setup->Template, setup->IntegralTmpl, TemplateHeight, TemplateWidth);//???
	CalcIntegral(setup->Image, setup->IntegralImg, ImageHeight, ImageWidth);
	// Calculate strip sum
	size = setup->TR[L];
	size = setup->TR[L];

	//The 0th projection (DC component) for template
	rows = TemplateHeight - size + 1;
	cols = TemplateWidth  - size  + 1;
	setup->TemplateProj[0][0] = setup->IntegralTmpl[size*integralTmplW+size] - setup->IntegralTmpl[size] -  (setup->IntegralTmpl[size*integralTmplW] - setup->IntegralTmpl[0]);

	//The 0th projection (DC component) for image
	rows = setup->ImageHeight - size + 1;
	cols = setup->ImageWidth  - size  + 1;
	CalcRectSumByInt(setup->IntegralImg, setup->StripSumImg[0], setup->ImageProj[0], size, rows, cols, ImageWidth);
	setup->OPs = NumProjs*5;//Interal image and the first rectangle sum
	setup->OPs += NumProjs * 3; //distance for the first projection


	ImgProj = setup->ImageProj[0];
	TplProj = setup->TemplateProj[0];
	suspectedCount = 0;
	SkippedCount = 0;
	for (row=0; row<rows; row++)
		for (col=0; col<cols; col++)
		{
			int idiff = abs(ImgProj[row*integralImgeW + col] - TplProj[0]);
			if (idiff < AbsProjThreshold)
			{
				float fdiff = (float)idiff;
				pmatchesCol[suspectedCount] = col;
				pmatchesRow[suspectedCount] = row;
				pmatchesDist[suspectedCount]  = fdiff * fdiff;
				suspectedCount++;
			}
		}
	suspectedTotal = suspectedCount;
#ifdef SHOW_MY_STATS
	printf("in HAAR_STP Proj 0 suspectedCount %d \n", suspectedCount);
#endif
	SqrProjThreshold = (float) AbsProjThreshold;
	SqrProjThreshold *= SqrProjThreshold;
	suspectedCount = 0;
	i = 1;
	j = 0;
// L = log4(N). For N_1xN_2 pattern, N=N_1*N_2.
	for (i=1; (i<L)&&(suspectedTotal >= JumpCount); i++)
	{
		//The projection for template
		int MultVal;
		int ShiftVal;
		ShiftVal = (i-1)<<1;

		MultVal = TR[i-1];
		MultVal *= MultVal;

		size = TR[L-i];
		rows = TemplateHeight - size + 1;
		cols = TemplateWidth  - size  + 1;
		Compute2HaarProjsJump_INT(setup->TemplateProj, setup->IntegralTmpl, i*2-1, size, 0, 0, rows, cols, TemplateWidth);
		rows = setup->ImageHeight - size + 1;
		cols = setup->ImageWidth  - size  + 1;


			//Use Strip sum to compute OHT for images
			setup->OPs += 14*NumProjs; //Projection
			Compute2HaarProjs_INT(setup->ImageProj, setup->IntegralImg, i*2-1, size, rows, cols, setup->ImageWidth);

			size <<= 1;
			for (j = 0; (j<2); j++) // for the 3 projections computed
			{
				int rblk, cblk;
				int blkSize = TR[i-1];
				int sizeRow, sizeCol;
				sizeRow = size>>j;
				sizeCol = size;
				MultVal <<= j;
//				ShiftVal += j;
				ImgProj = setup->ImageProj[i*2-1+j];
				TplProj = setup->TemplateProj[i*2-1+j];
				suspectedCount = 0;
				SkippedCount = 0;
				setup->OPs += ((3*blkSize*blkSize*suspectedTotal)<<j)+suspectedTotal; // Distance + normalization
				for (loop = 0; loop < suspectedTotal; loop++)
				{
					float diff;
					float Accdiff;
					Accdiff=0;
					row = pmatchesRow[loop]; 
					col = pmatchesCol[loop];
					// compute the partial SSD
					for (rblk = 0; rblk < (blkSize<<j); rblk++)
						for (cblk = 0; cblk < blkSize; cblk++)
						{ 
							diff = (float) (ImgProj[(row+sizeRow*rblk)*integralImgeW + (col+sizeCol*cblk)] - TplProj[sizeRow*rblk*integralTmplW+sizeCol*cblk]);
							Accdiff += diff * diff;
						}
//					Accdiff <<= ShiftVal;
					Accdiff *= MultVal;
					// Accdiff <<= (i-1);
					Accdiff += pmatchesDist[loop]; // the lower bound (partial SSD) is obtained

					if (Accdiff < SqrProjThreshold) // Check the lower bound
					{// in this case, the candidate remain in the set of candidates; otherwise the candidate is the mismatching window and eliminated
						pmatchesCol[suspectedCount] = col;
						pmatchesRow[suspectedCount] = row;
						pmatchesDist[suspectedCount]  = Accdiff;
						suspectedCount++;
					}
				}
				suspectedTotal = suspectedCount;

	#ifdef SHOW_MY_STATS
				printf("in HAAR_STP full level %d suspectedCount %d Skipped %d\n", i*2-1+j, suspectedCount, SkippedCount);
	#endif
			}

	}
	setup->count = 0;
	size = setup->TR[L];
	rows = setup->ImageHeight - size + 1;
	cols = setup->ImageWidth  - size  + 1;
	SsdThreshold = (int) (SqrProjThreshold/(PatternSize*PatternSize));
	if ( (2*(i-1)+j-2) > 0)
		setup->BasesComputed = 1<<(2*(i-1));
	else
		setup->BasesComputed = 1<<(2*(i-1));
	setup->OPs += 3*suspectedTotal * TemplateWidth*TemplateHeight;// actual distance
	// Remaining candidates undergo FS
	for (loop = 0; loop < suspectedTotal; loop++)
	{
		u_int32 SSD;
		row = pmatchesRow[loop]; 
		col = pmatchesCol[loop];
		SSD = calcSSD2(&Image[row*ImageWidth+col], ImageWidth-TemplateWidth, Template, 0, size);
				
		if (SSD<SsdThreshold ) {
			setup->match[setup->count] = SSD;
			setup->xmatch[setup->count]= row;
			setup->ymatch[setup->count]= col;
			setup->count++;
		}
	}
}

#ifdef OBTAIN_LOWER_BOUND
// This function is used for obtaining the lower bound as a function of the number of basis vectors
void HaarPatternMatch_Bounding(HaarSetup *setup, GCKSetup *gcksetup)
{
	int i, j, loop;
	int L = setup->L;
	int rows, cols;
	int row, col;
	int size;
	BYTE *Template = setup->Template;
	BYTE *Image = setup->Image;
	int *StripSum;
//	int width, height;
	int *TR = setup->TR;
	int ImageWidth = setup->ImageWidth;
	int ImageHeight = setup->ImageHeight;
	int PatternSize = setup->TemplateHeight;
	float *ssdlist = setup->ssdlist;
	char *Skipped = setup->Skipped;
	int *ImgProj;
	int *TplProj;
	int AbsProjThreshold=setup->Threshold*PatternSize*PatternSize;
	float SqrProjThreshold;
	u_int32 SsdThreshold;
	int TemplateWidth = setup->TemplateWidth;
	int TemplateHeight = setup->TemplateHeight;
	int suspectedCount, suspectedTotal;
	int SkippedCount;
	int JumpCount = (int) (setup->Percent*0.01*ImageWidth*ImageHeight+1);
	int integralImgeW;
	int integralTmplW;
	int idx;
	
	int FullCandidate;
	int PartialCandidtate;
	int NumProjs = (ImageWidth-PatternSize+1)*(ImageHeight-PatternSize+1);
	int32 *pmatchesCol = matchesCol;
	int32 *pmatchesRow = matchesRow;
	float* pmatchesDist = matchesDist;
	integralImgeW = ImageWidth + 1;
	integralTmplW = PatternSize+1;
	memset(ssdlist, 0, sizeof(float)*ImageWidth*ImageHeight);
	memset(Skipped, 0, sizeof(char)*ImageWidth*ImageHeight);
	// Calculate integral image
	CalcIntegral(setup->Template, setup->IntegralTmpl,  TemplateHeight, TemplateWidth);//???
	CalcIntegral(setup->Image, setup->IntegralImg, ImageHeight, ImageWidth);
	size = setup->TR[L];
	size = setup->TR[L];
	//The 0th projection (DC component) for template
	setup->TemplateProj[0][0] = setup->IntegralTmpl[size*integralTmplW+size] - setup->IntegralTmpl[size] -  (setup->IntegralTmpl[size*integralTmplW] - setup->IntegralTmpl[0]);


	//The 0th projection (DC component) for image
	rows = setup->ImageHeight - size + 1;
	cols = setup->ImageWidth  - size  + 1;
	CalcRectSumByHStrip2(setup->IntegralImg, setup->StripSumImg[0], setup->ImageProj[0], size, size, rows, cols, integralImgeW);
	setup->OPs = NumProjs*4;//Interal image and the first rectangle sum

	setup->BasesNum = 100;
	for (idx=0; idx<256; idx++)
		setup->EnergyPercent[idx] = 0;

	idx = 0;

	//Obtain the actuall SSD
/*	for (row=0; row<rows; row++)
		for (col=0; col<cols; col++)
		{
			u_int32 ssd;
			double fSSD;
			ssd = calcSSD2(&Image[row*ImageWidth+col], ImageWidth-TemplateWidth, Template, 0, size);
			fSSD = ssd;
			fSSD *= size*size;
			if ((row==1) && (col<10))
				printf("OHT SSD: %ud\n", ssd);
			if (fSSD==0)
				setup->SSDActual[idx++] = BLOCK_SIZE_IMG*BLOCK_SIZE_IMG*255*255;
			else
				setup->SSDActual[idx++] = 1/(fSSD);
		}*/

	ImgProj = setup->ImageProj[0];
	TplProj = setup->TemplateProj[0];
	suspectedCount = 0;
	SkippedCount = 0;
	for (row=0; row<rows; row++)
		for (col=0; col<cols; col++)
		{
			int idiff = abs(ImgProj[row*integralImgeW + col] - TplProj[0]);
			{
				float fdiff = (float)idiff;
				pmatchesCol[suspectedCount] = col;
				pmatchesRow[suspectedCount] = row;
				pmatchesDist[suspectedCount]  = fdiff * fdiff;
				setup->EnergyPercent[0] += (pmatchesDist[suspectedCount])*gcksetup->SSDActual[suspectedCount];
				suspectedCount++;
			}
		}
	suspectedTotal = suspectedCount;
#ifdef SHOW_MY_STATS
	printf("in HAAR_STP Proj 0 suspectedCount %d \n", suspectedCount);
#endif
	SqrProjThreshold = (float) AbsProjThreshold;
	SqrProjThreshold *= SqrProjThreshold;
	suspectedCount = 0;
	i = 1;
	j = 0;
	for (i=1; (i<=L)&&(suspectedTotal >= JumpCount); i++)
	{
		int MultVal,BasesComputed;
		int ShiftVal;
		int JumpOPs, SldOPs;
		int StartRow, EndRow;
		ShiftVal = (i-1)<<1;

		MultVal = TR[i-1];
		MultVal *= MultVal;

		JumpOPs = suspectedTotal<<(i*2);
		JumpOPs *= 2;
		SldOPs = NumProjs;
		size = TR[L-i];
		rows = TemplateHeight - size + 1;
		cols = TemplateWidth  - size  + 1;
		Compute2HaarProjsJump_STP(setup->TemplateProj, setup->IntegralTmpl, i*2-1, size, rows, cols, TemplateWidth);
		rows = setup->ImageHeight - size + 1;
		cols = setup->ImageWidth  - size  + 1;


		if ( (SldOPs<JumpOPs) || (i <= 2) )
		{
			//The projection for image
			setup->OPs += 6*NumProjs; //Projection
			Compute2HaarProjs_SLD(setup->IntegralImg, setup->ImageProj, setup->StripSumImg[0], i*2-1, size, rows, cols, integralImgeW, 0);

			size <<= 1;
			for (j = 0; (j<2); j++) // for the 3 projections computed
			{
				int rblk, cblk;
				int blkSize = TR[i-1];
				int sizeRow, sizeCol;
				int basisNow = 1<<(2*(i-1)+j);
				sizeRow = size>>j;
				sizeCol = size;
				MultVal <<= j;
//				ShiftVal += j;
				setup->OPs += (3*TR[i-1]*suspectedTotal)<<j; // Distance
				ImgProj = setup->ImageProj[i*2-1+j];
				TplProj = setup->TemplateProj[i*2-1+j];
				suspectedCount = 0;
				SkippedCount = 0;
				for (loop = 0; loop < suspectedTotal; loop++)
				{
					double diff;
					double Accdiff=0;
					double Dist;
					int basisidx = 0;
					row = pmatchesRow[loop]; 
					col = pmatchesCol[loop];					
					for (rblk = 0; rblk < (blkSize<<j); rblk++)
						for (cblk = 0; cblk < blkSize; cblk++)
						{ 
							diff = ImgProj[(row+sizeRow*rblk)*integralImgeW + (col+sizeCol*cblk)] - TplProj[sizeRow*rblk*integralTmplW+sizeCol*cblk];
							Accdiff += diff * diff;
							setup->EnergyPercent[basisNow+basisidx] += (pmatchesDist[loop]+Accdiff*MultVal)*gcksetup->SSDActual[loop];
							basisidx++;
						}
					Accdiff *= MultVal;
					// Accdiff <<= (i-1);
					Dist = pmatchesDist[loop] + Accdiff;
					{				
						pmatchesCol[suspectedCount] = col;
						pmatchesRow[suspectedCount] = row;
						pmatchesDist[suspectedCount]  = Dist;
						suspectedCount++;
					}
				}
				suspectedTotal = suspectedCount;
				BasesComputed = 1<<(2*(i-1)+j);
				if (BasesComputed>setup->BasesNum) break;

	#ifdef SHOW_MY_STATS
				printf("in HAAR_STP full level %d suspectedCount %d Skipped %d\n", i*2-1+j, suspectedCount, SkippedCount);
	#endif
			}
		}
	}

	for (idx=0; idx<256; idx++)
	{
		setup->EnergyPercent[idx] /= NumProjs;
	}
#ifdef SHOW_BOUNDING_STATS
	printf("\nHaar Energy:\n");
	for (idx=0; idx<64; idx++)
		printf("%d\t	%f\n", idx, setup->EnergyPercent[idx]);
#endif
	setup->count = 0;
	size = setup->TR[L];
	rows = setup->ImageHeight - size + 1;
	cols = setup->ImageWidth  - size  + 1;
	SsdThreshold = (int) (SqrProjThreshold/(PatternSize*PatternSize));
	if ( (2*(i-1)+j-2) > 0)
		setup->BasesComputed = 1<<(2*(i-1));
	else
		setup->BasesComputed = 1<<(2*(i-1));
	setup->OPs += 3*suspectedTotal * TemplateWidth*TemplateHeight;// actual distance
	for (loop = 0; loop < suspectedTotal; loop++)
	{	
		u_int32 SSD;
		row = pmatchesRow[loop]; 
		col = pmatchesCol[loop];
		SSD = 1/gcksetup->SSDActual[loop];
				
		if (SSD<SsdThreshold ) {
			setup->match[setup->count] = SSD;
			setup->xmatch[setup->count]= row;
			setup->ymatch[setup->count]= col;
			setup->count++;
		}
	}
}
#endif
//skip table haar-transform

HaarSetup *CreateHaarSetup(char* templ, char* img, coordT ImageHeight, 
						 coordT ImageWidth, coordT TemplateHeight, coordT TemplateWidth, int L)
{
	int *TR = (int *)malloc( (L+1) * sizeof(int));
	int *NormA = (int *)malloc( L * sizeof(int));
	int *IntegralImg, *IntegralTmpl;
	int *MtxS;
	int **TemplateProj;
	int **ImageProj;
	int **StripSumImg;
	int i;
	int temp2;
	float *ssdlist; // List storing the SSD for each point
	char *Skipped; // List showing whether this point is skipped or not
	int *dist; // List storing the SSD for each point

	HaarSetup *setup =  (HaarSetup *) malloc(sizeof(HaarSetup));

	setup->Image		= img;
	setup->Template		= templ;
	setup->L			  = L;
	setup->ImageHeight	  = ImageHeight;
	setup->ImageWidth	  = ImageWidth;
	setup->TemplateHeight = TemplateHeight;
	setup->TemplateWidth  = TemplateWidth;

	// allocate memory
	TR[0] = 1;
	temp2 = 2;
	for(i=1; i<(L+1); i++){
		TR[i]=temp2;
		temp2 = temp2 * 2;
	} 
	temp2 = 4;
	for(i=L-1; i>=0; i--){	
		NormA[i] = temp2;
		temp2 = 4*temp2;	
	}

	MtxS = (int *)malloc((ImageHeight+1) * (ImageWidth+1) * sizeof(int) );
	IntegralImg =  (int *)malloc((ImageHeight+1) * (ImageWidth+1) * sizeof(int) );
	IntegralTmpl = (int *)malloc((TemplateHeight+1) * (TemplateWidth+1) * sizeof(int) );
	ssdlist =  (float *)malloc((ImageHeight) * (ImageWidth) * sizeof(float) );
	dist = (int *)malloc((ImageHeight) * (ImageWidth) * sizeof(int) );
	Skipped =  (char *)malloc((ImageHeight) * (ImageWidth) * sizeof(char) );

	StripSumImg = (int **)malloc( sizeof(int *));
		StripSumImg[0] = (int *)malloc((ImageHeight+1) * (ImageWidth+1) * sizeof(int) );

	TemplateProj = (int **)malloc((3*L+1) * sizeof(int *));
	for(i=0; i<(3*L+1); i++)
	{
		TemplateProj[i] = (int *)malloc((TemplateHeight+1) * (TemplateWidth+1) * sizeof(int) );
		if (TemplateProj[i] == NULL)
			printf("error in allocating memory TemplateProj in CreateHaarSetup\n");
	}

	ImageProj = (int **)malloc((3*L+1) * sizeof(int *));
	if (ImageProj == NULL)
		printf("error in allocating memory ImageProj in CreateHaarSetup");
	for(i=0; i<(3*L+1); i++)
	{
		ImageProj[i] = (int *)malloc((ImageHeight+1) * (ImageWidth+1) * sizeof(int) );
		if (ImageProj[i] == NULL)
			printf("error in allocating memory ImageProj in CreateHaarSetup\n");
	}

	setup->NormA		= NormA;
	setup->TR			= TR;
	setup->MtxS			= MtxS;
	setup->IntegralImg	= IntegralImg;
	setup->IntegralTmpl = IntegralTmpl;
	setup->ssdlist		= ssdlist;
	setup->dist			= dist;
	setup->Skipped		= Skipped;
	setup->StripSumImg	= StripSumImg;
//	setup->StripSumTmpl	= StripSumTmpl;
	setup->TemplateProj = TemplateProj;
	setup->ImageProj	= ImageProj;
	return setup;
}

void destroyHaarSetup(HaarSetup *setup) {
	int L = setup->L;
	int i;

	free(setup->TR);
	free(setup->NormA);

	free(setup->MtxS);
	free(setup->IntegralImg);
	free(setup->IntegralTmpl);
	free(setup->ssdlist);
	free(setup->dist);
	free(setup->Skipped);

	free(setup->StripSumImg[0]);
	free(setup->StripSumImg);

	for(i=0; i<(3*L+1); i++){
		free(setup->TemplateProj[i]);
		free(setup->ImageProj[i]);
	}
	free(setup->TemplateProj);
	free(setup->ImageProj);

	free(setup);
}
