fid = fopen('I1_0.bin', 'rb');
Template_height = 160;
Template_width = 120;
T1_0 = uint8(fread(fid, [Template_height Template_width], 'uint8'));
fclose(fid);
imshow(T1_0');