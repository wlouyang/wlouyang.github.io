#include "defs.h"
void CalcIntegral(BYTE* Input, int *Intgr,  int HEIGHT, int WIDTH);
void CalcHStripSum(int* IntgrTmpl, int *StpSumTmpl, int N2, int WIDTH, int HEIGHT);
__inline int RecSumImage(int *InputImg, int x, int y, int N1, int N2, int WIDTH)
{
	int tmp;
	tmp = InputImg[(y+N2)*WIDTH+x+N1] + InputImg[y*WIDTH+x] - InputImg[(y+N2)*WIDTH+x] - InputImg[y*WIDTH+x+N1];
	return tmp;
}

void CalcRectSumByHStrip2(int* IntgrTmpl, int *StripSum, int *Proj, int N1, int N2, int rows, int cols, int WIDTH);
void CalcRectSumByInt(int* IntgrTmpl, int *StripSum, int *Proj, int N1, int rows, int cols, int WIDTH);