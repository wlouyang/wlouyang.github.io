/*****************************************************************************
 *           Fast pattern matching using orthogonal Haar transform           *
 *****************************************************************************
 * file:        HaarMatch.h													 *
 *                                                                           *
 * description: Functions for performing pattern matching using OHT.		 *
 *****************************************************************************/

#include "defs.h"
//#include "gck.h"
typedef struct  {

    // Image and  Image size
    BYTE *Image;
    int ImageWidth;
    int ImageHeight;
    
    // Template and  Template size
    BYTE *Template;
    int TemplateWidth;
    int TemplateHeight;

    // Parameters of the Algorithms
    int SsdThreshold;  
	int Threshold;
	int L; // L = log2(1D_template_size);
	int BasesComputed;
	int BasesNum;

 /*   // Results
	int SsdMin;
    int position_x;
    int position_y;
*/
	//SSD
/*	int SsdThreshold;
	int SsdMin;*/
	
	//matches below thresholds
	int count;
	int match[MAX_MATCH];
	int xmatch[MAX_MATCH];
	int ymatch[MAX_MATCH];
	float Percent;

	int *TR;
	int *NormA;
	int *MtxS;	// temporary value used for obtaining the integral image
	float *ssdlist; // List storing the SSD for each point
	int *dist; // List storing the SSD for each point
	char *Skipped; // List showing whether this point is skipped or not
	int *IntegralImg;
	int *IntegralTmpl;
//	int **StripSumTmpl;
	int **StripSumImg;
	int **TemplateProj;
	int **ImageProj;
	double OPs;
	double EnergyPercent[256]; //The percentage of energy where GCK stops and the direct SSD is used
	double SSDActual[1280*960];
}HaarSetup ;

HaarSetup *CreateHaarSetup(char* templ, char* img, coordT ImageHeight, 
						 coordT ImageWidth, coordT TemplateHeight, coordT TemplateWidth, int L);
void HaarPatternMatch(HaarSetup *setup);
void HaarPatternMatch_INT(HaarSetup *setup);

//typedef struct parameters information;