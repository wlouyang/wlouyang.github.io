/*****************************************************************************
 *           Fast pattern matching using orthogonal Haar transform           *
 *****************************************************************************
 *****************************************************************************/

 /*****************************************************************************
Introduction of the code

This is program shows the fast othorgonal Haar transform (OHT) 
algorithm proposed in [1]. 
Note that this algorithm is used for OHT on sliding windows rather than block WHT. 
There are two novel algorithms for WHT on sliding windows [3][4]. 
We also have a fast algorithm for computing WHT [5], which is faster than [3][4] in computing WHT on sliding windows.


Researchers using this code are highly recomended to cite the following papers:
Reference
[1]	Wanli Ouyang and W. K. Cham, "Fast pattern matching using orthogonal Haar transform", IEEE CVPR 2010,.
[2]	Y. Moshe and H. Hel-Or, "A Fast Block Motion Estimation Algorithm 
Using Gray Code Kernels", IEEE Trans. Image Process., volume 18, pages 2243�C2254, Oct. 2009.
[3]	 Y. Hel-Or and H. Hel-Or, "Real time pattern matching using 
projection kernels," IEEE Trans. Pattern Analysis and Machine 
Intelligence, vol. 27, no. 9, pp. 1430-1445, Sept. 2005.
[4]	 G. Ben-Artzi, H. Hel-Or, and Y. Hel-Or, "The gray-code filter 
kernels," IEEE Trans. Pattern Analysis and Machine Intelligence, vol. 29, 
no. 3,  pp.382 ?C 393, Mar. 2007.
[5]	Wanli Ouyang, Renqi Zhang and W. K. Cham, "Fast Algorithm for Walsh Hadamard 
Transform on Sliding Windows", IEEE Trans. Pattern Anal. Mach. Intell., 32(1):165-171, Jan. 2010.
[6] C. Mak, C. Fong, and W. Cham. Fast motion estimation for H.264/AVC in Walsh Hadamard domain. IEEE Trans. 
Circuits Syst. Video Technol., 18(5):735�C745, Jun. 2008.
[7] F. Tombari, S. Mattoccia, and L. D. Stefano. Full searchequivalent pattern matching with incremental dissimilarity
approximations. IEEE Trans. Pattern Anal. Mach. Intell., 31(1):129�C141, Jan. 2009.
******************************************************************************/

/*
Conditions of Use and Disclaimer:

You are only granted a limited right to use this software for your
personal non-commercial use.

This software is provided as SHAREWARE for testing and evaluating
purposes and cannot be sold or used in any commercial way, or
distributed, with or without consideration and whether on its own or
bundled with any commercial package, or by accompanying books, magazines
or any publication in any media without express written permission from
the owner.

The owner of this software accepts no responsibility for any damages
resulting from any use relating to this software and makes no warranty
or representation, either express or implied, including but not limited
to, any implied warranty of merchantability or fitness for a particular
purpose. This software is provided "AS IS", and you, as a limited right
user, assume all risks when using it.

This software is intended for personal non-commercial use only. 

For any other use of OHT, whether commercial or otherwise, please make
enquiries by writing to:

Technology Licensing Office
The Chinese University of Hong Kong
Shatin, N.T., Hong Kong

Email: tech_license@cuhk.edu.hk
*****************************************************************************/

ACKNOWLEDGMENT
The authors wish to thank Professor Yacov Hel-Or at the Interdisciplinary 
Center and Professor Hagit Hel-Or at the University of Haifa for providing 
the thesis on generalized GCK and their code implementing GCK and WHT, 
Dr. Federico Tombari at the University of Bologna for providing their 
code implementing IDA, image datasets and helpful discussion, 
Professor Antonio Torralba and CSAIL at the MIT for the use of the 
MIT database, Professor Rainer Koster and the Institute for Clinical 
Radiology and Nuclear Medicine of the Lukas Hospital Neuss for the 
use of the medical image database, and NASA for the use of the remote 
sensing image database.
Image dataset is originated from the following three websites:
 ;. http://people.csail.mit.edu/torralba/images. 
 ;. www.data-compression.info/corpora/lukascorpus. 
 ;. http://zulu.ssc.nasa.gov/mrsid. 
 
 
Usage:
Installation:
-------------
Just put the .c & .h files in the same folder and compile - there is no need
for any special makefile. Since running time is important here, it is
recommended to compile with the maximum speed flag.

This package doesn't include any libraries for loading, saving & displaying
images. Since image data is needed as input, the user should provide his own
image libraries. 30 sample images are provided.

This is a C code compilable using VC6.0 with "HaarMatch.dsw" and "HaarMatch.dsp" as the workspace. 
To run the code:
1. compile the .c codes using the "HaarMatch.dsw" provided.
2. run the code without giving any parameters.


Description of files:
defs.c .h:  Project's common definitions, many configurations are available here.
main.c: Example of the usage of the code
fs.c .h: Functions performing Full-Search for pattern matching
HaarMatch.c .h: Functions using OHT for for pattern matching in [1]
recsum.c .h: Functions related to rectangle sum (sum of pixels in a rectangle)

Outputs on screen:
0 Exhaust Time 2.344    Avg.bases: 0.000 OPs: 0.000 Std_Var: 0.007821
2 HAAR_WL Time 0.046    Avg.bases: 4.080 OPs: 178979.083 Std_Var: 0.001526


Illustration
Exhaust: experimental data for Full search
HAAR_WL: experimental data for OHT using Wanli' algorithm in [1]
For OHT using Wanli's algorithm: the execution time is 0.046 seconds; on average 4.080 bases are computed for a image-pattern pair;
about 178979.083 operations are required for an image-pattern pair on average; the standard variantion for execution time is 0.001526.

Ouput on screen also saved in "HAARLog.txt" for further analysis.
"HAARLog2.txt" is used for finding the energy packing ability of OHT as a function of the number of basis.



Main function of OHT:

HaarSetup *CreateHaarSetup(char* templ, char* img, coordT ImageHeight, 
						 coordT ImageWidth, coordT TemplateHeight, coordT TemplateWidth, int L)
						 
Creates and returns a setup required for the later function.
templ: The template. Each pixel is an 8-bit gray level value and the array should be in rows
order, i.e. the top row from left to right, then the second row from left to
right, etc.
img: The image. Each pixel is an 8-bit gray level value and the array should be in rows
order, i.e. the top row from left to right, then the second row from left to
right, etc.
L: L=log(N). For N_1xN_2 pattern, N=N_1*N_2( * means multiply). 



HaarPatternMatch(haarSetup); 
Do the pattern matching using the haarSetup created by function "CreateHaarSetup". 
OHT computed by strip sum.

HaarPatternMatch_INT(haarSetup); 
Do the pattern matching using the haarSetup created by function "CreateHaarSetup". 
OHT computed by integral image.


Sample input 160x120 images are provided in .\Noise_data2\160
A malab file "Showimage.m" used for showing one of the patterns is also provided in this directory

Sample input 16x16 patterns are provided in .\Template\160\T_16
A malab file "ShowTemplate.m" used for showing one of the images is also provided in this directory