fid = fopen('T1_0.bin', 'rb');
Template_height = 16;
Template_width = 16;
T1_0 = uint8(fread(fid, [Template_height Template_width], 'uint8'));
fclose(fid);
imshow(T1_0');