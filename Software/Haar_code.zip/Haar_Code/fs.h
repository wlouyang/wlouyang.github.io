/*****************************************************************************
 *           Fast pattern matching using orthogonal Haar transform           *
 *****************************************************************************
 * file:        fs.h														 *
 *                                                                           *
 * description: Functions for performing Full-Search.						 *
 *****************************************************************************/

#ifndef _fs_h_
#define _fs_h_

#include "image.h"
////#include "match.h"


///////////////////////////////// DATA TYPES ////////////////////////////////

// A setup for motion estimation. Contains motion estimation required data.
// The resulting motion vectors are updated in the motionVecs field.

#endif