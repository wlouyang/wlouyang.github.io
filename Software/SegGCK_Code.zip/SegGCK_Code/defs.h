/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        defs.h                                                       *
 *                                                                           *
 * description: Project's common definitions.                                *
 *****************************************************************************/

#ifndef _defs_h_
#define _defs_h_


///////////////////////////////// CONSTANTS /////////////////////////////////

//Different choices of algorithms
#define CHOICE_EXHAUSTIV	0			// The slow exhaustive search
#define CHOICE_HELOR_GCK	5			// The GCK algorithm of Mr. Ben-Artzi and Prof. Hel-Ors in PAMI2007
#define CHOICE_WANLI_GCK	6			// The fast algorithm for WHT of Wanli and W.K. Cham
#define S1 1
#define S2 2
#define S3 3
#define S4 4

#define ALGORITHM_CHOICE CHOICE_HELOR_GCK

//this is used for debugging
/*
#ifdef _DEBUG
#define MY_DEBUG
#endif
*/
#define SHOW_MY_STATS   0 //Used for fine tuning parameters
//#define RETURN_STATS
#define SHOW_STD_VARIANCE 0
#define PRINT_IMAGE_NUN  1
//#define PRINT_ORDER  1

// general constants

// Image-pattern size choice: 1: S1  2: S2  3: S3  4: S4
//#define IMG_PAT_PAIR_SIZE 1

#define IMAGE_NOISE  0
#define IMAGE_FILTER 1
#define IMAGE_JPEG   2
#define IMAGE_SET_CHOICE  IMAGE_NOISE  //IMAGE_NOISE: Gaussian noise; IMAGE_FILTER: blurring filter; IMAGE_JPEG: JPEG compressed image


#define ADAPTIVE_SSD			//If defined, will use different SSD for different image-pattern pair adaptively
//#define ALL_TEMPLATE_SIZES      //If defined, will use different sizes of patterns for the same image

#define COUNT_OPS 1
#define COUNT_SSDOPS 1
// 30 images, 10 templates, 7 noise levels, 7 algorithms
#define SIZE_START 1
#define SIZE_NUM   1

#define CHOICE_START 5					// The start number of algorithm
#define CHOICE_NUM	 2					// Number of algorithms evaluated

#define NOISE_START 4					// The start number of noise
#define NOISE_NUM   1					// Number of noise levels 5
#define IMG_NUM		30					// Number of images
#define PAT_NUM		10					// Number of patterns

#define PERCENT1   50
//#define PERCENT2   0.02
//#define PERCENT2   0.005
//#define PERCENT2   0.0005
//#define BASES_NUM 8					// number of Walsh-Hadamard bases to use
#define MAX_BASES 128


#define DEFAULT_BOTTOM_UP_PERCENT 0.10*100 // default percentage under which the bottom up method should be used
#define DEFAULT_DISTANCE_PERCENT 0.02*100 // default percentage under which the direct distance method should be used

/*
#define MMD   (10*(NOISE_START+1))		// The MMD defined by Dr. Federico etc.
#define MATCHING_THRESHOLD (BLOCK_SIZE_PAT*BLOCK_SIZE_PAT*MMD)  // Threshold for GCK and Wanli's paper
#define THRESHOLD  (BLOCK_SIZE_PAT*BLOCK_SIZE_PAT*MMD*MMD)		// Threshold for IDA, this is equivalent to the above
*/

// GCK projections order
#define SNAKE_ORDER					0
#define INCREASING_FREQUENCY_ORDER	1
#define GROUP_ORDER					2
#define GROUP_ORDER2				3
#define GROUP_ORDER3				4

#if (ALGORITHM_CHOICE == CHOICE_WANLI_GCK)
static const int PROJECTIONS_ORDER = GROUP_ORDER3; //INCREASING_FREQUENCY_ORDER  GROUP_ORDER;   // projections order to use
#else
static const int PROJECTIONS_ORDER = INCREASING_FREQUENCY_ORDER; //INCREASING_FREQUENCY_ORDER  GROUP_ORDER;   // projections order to use
#endif


// GCK constants
#define WANT_DC    1				// 0: Don't want DC coef for error  1: want
#define MATCHES_FOR_SAD 5			// number of best matches for each block to compute SAD for

#define SCALE      1				// 1: no scaling		2: scale 2 times
#define MAX_MATCH 1280*960


//max number of parameter N
#define MAX_BOUNDS 16


#define BLOCK_SIZE2 (BLOCK_SIZE_PAT*BLOCK_SIZE_PAT)


/* Snake Order
{
  0   1   8   9  24  25  48  49  80  81 120 121 168 169 224 225
  3   2   7  10  23  26  47  50  79  82 119 122 167 170 223 226
  4   5   6  11  22  27  46  51  78  83 118 123 166 171 222 227
 15  14  13  12  21  28  45  52  77  84 117 124 165 172 221 228
 16  17  18  19  20  29  44  53  76  85 116 125 164 173 220 229
 35  34  33  32  31  30  43  54  75  86 115 126 163 174 219 230
 36  37  38  39  40  41  42  55  74  87 114 127 162 175 218 231
 63  62  61  60  59  58  57  56  73  88 113 128 161 176 217 232
 64  65  66  67  68  69  70  71  72  89 112 129 160 177 216 233
 99  98  97  96  95  94  93  92  91  90 111 130 159 178 215 234
100 101 102 103 104 105 106 107 108 109 110 131 158 179 214 235
143 142 141 140 139 138 137 136 135 134 133 132 157 180 213 236
144 145 146 147 148 149 150 151 152 153 154 155 156 181 212 237
195 194 193 192 191 190 189 188 187 186 185 184 183 182 211 238
196 197 198 199 200 201 202 203 204 205 206 207 208 209 210 239
255 254 253 252 251 250 249 248 247 246 245 244 243 242 241 240
}
{ Sequency Order
  0   2   5  10  16  23  34  44  57  70  86 105 122 143 163 188
  1   3   7  12  18  27  36  46  59  74  89 107 124 145 169 192
  4   6   9  14  21  29  38  51  63  76  93 109 130 151 171 196
  8  11  13  19  26  33  42  53  66  82  97 114 134 153 176 200
 15  17  20  25  30  40  50  61  73  85 101 120 138 159 182 204
 22  24  28  32  39  47  56  68  81  95 111 129 147 168 187 211
 31  35  37  41  49  55  65  78  91 104 119 136 155 178 199 217
 43  45  48  52  60  67  77  88  99 116 132 150 167 184 209 223
 54  58  62  64  72  80  90  98 113 128 142 161 180 202 216 228
 69  71  75  79  84  94 103 115 127 139 157 175 195 213 225 234
 83  87  92  96 100 110 118 131 141 156 172 191 208 221 232 240
102 106 108 112 117 126 135 149 160 174 190 205 219 230 238 245
121 123 125 133 137 146 154 166 179 194 207 218 227 236 243 249
140 144 148 152 158 165 177 183 201 212 220 229 235 241 247 252
162 164 170 173 181 186 198 206 215 224 231 237 242 246 250 254
185 189 193 197 203 210 214 222 226 233 239 244 248 251 253 255
}
*/

/* Order for KHT
  0   4   5   6  32  36  37  38  96 100 101 102   0   0   0   0
  1   7   8   9  33  39  40  41  97 103 104 105   0   0   0   0
  2  10  11  12  34  42  43  44  98 106 107 108   0   0   0   0
  3  13  14  15  35  45  46  47  99 109 110 111   0   0   0   0
 16  20  21  22  48  52  53  54 112 116 117 118   0   0   0   0
 17  23  24  25  49  55  56  57 113 119 120 121   0   0   0   0
 18  26  27  28  50  58  59  60 114 122 123 124   0   0   0   0
 19  29  30  31  51  61  62  63 115 125 126 127   0   0   0   0
 64  68  69  70   0   0   0   0   0   0   0   0   0   0   0   0
 65  71  72  73   0   0   0   0   0   0   0   0   0   0   0   0
 66  74  75  76   0   0   0   0   0   0   0   0   0   0   0   0
 67  77  78  79   0   0   0   0   0   0   0   0   0   0   0   0
 80  84  85  86   0   0   0   0   0   0   0   0   0   0   0   0
 81  87  88  89   0   0   0   0   0   0   0   0   0   0   0   0
 82  90  91  92   0   0   0   0   0   0   0   0   0   0   0   0
 83  93  94  95   0   0   0   0   0   0   0   0   0   0   0   0
*/
#define LOG_FILE_NAME "KHTLog.txt"
/*
#if (IMG_PAT_PAIR_SIZE == 1)
#define IMG_WIDTH 160				// number of columns in the source image
#define IMG_HEIGHT 120				// number of rows in the source image
#define MAX_PATTERN_32
#define PAT_WIDTH 16				// number of columns in the pattern image
#define PAT_HEIGHT 16				// number of rows in the pattern image
#define BLOCK_SIZE_PAT 16			// number of rows and columns in a block for pattern
#define PAT_FILE_NAME "./Test_Data/160/t%d_%d.txt"
#define IMG_FILE_NAME "./Test_Data/160/I%d_%d.txt"
#define IDA_R 4
#define LRP_N 4
#endif

#if (IMG_PAT_PAIR_SIZE == 2)
#define IMG_WIDTH 320				// number of columns in the source image
#define IMG_HEIGHT 240				// number of rows in the source image
#define MAX_PATTERN_32
#define PAT_WIDTH 32				// number of columns in the pattern image
#define PAT_HEIGHT 32				// number of rows in the pattern image
#define BLOCK_SIZE_PAT 32			// number of rows and columns in a block for pattern
#define PAT_FILE_NAME "./Test_Data/320/t%d_%d.txt"
#define IMG_FILE_NAME "./Test_Data/320/I%d_%d.txt"
#define IDA_R 4
#define LRP_N 5
#endif

#if (IMG_PAT_PAIR_SIZE == 3)
#define IMG_WIDTH 640				// number of columns in the source image
#define IMG_HEIGHT 480				// number of rows in the source image
#define MAX_PATTERN_64
#define PAT_WIDTH 64				// number of columns in the pattern image
#define PAT_HEIGHT 64				// number of rows in the pattern image
#define BLOCK_SIZE_PAT 64			// number of rows and columns in a block for pattern
#define PAT_FILE_NAME "./Test_Data/640/t%d_%d.txt"
#define IMG_FILE_NAME "./Test_Data/640/I%d_%d.txt"
#define IDA_R 8
#define LARGE_PATTERN
#define LRP_N 6
#endif

#if (IMG_PAT_PAIR_SIZE == 4)
#define IMG_WIDTH 1280				// number of columns in the source image
#define IMG_HEIGHT 960				// number of rows in the source image
#define MAX_PATTERN_64
#define PAT_WIDTH 128				// number of columns in the pattern image
#define PAT_HEIGHT 128				// number of rows in the pattern image
#define BLOCK_SIZE_PAT 128			// number of rows and columns in a block for pattern
#define PAT_FILE_NAME "./Test_Data/1280/t%d_%d.txt"
#define IMG_FILE_NAME "./Test_Data/1280/I%d_%d.txt"
#define IDA_R 8
#define LARGE_PATTERN
#define LRP_N 7
#endif

#if (IMG_PAT_PAIR_SIZE == 5)
#define IMG_WIDTH 512				// number of columns in the source image
#define IMG_HEIGHT 512				// number of rows in the source image
#define MAX_PATTERN_32
#define PAT_WIDTH 32				// number of columns in the pattern image
#define PAT_HEIGHT 32				// number of rows in the pattern image
#define BLOCK_SIZE_PAT 32			// number of rows and columns in a block for pattern
#define PAT_FILE_NAME "D:/code/KHT/For Pattern/data/Pat_0_%d.txt"
#define IMG_FILE_NAME "D:/code/KHT/For Pattern/data/Img_%d.txt"
#define IDA_R 4
#define LRP_N 5
#endif
*/

// profiling and logging
#define PROFILING_MODE				// if defined, does not stop at the end to wait for pressing a key
//#define LOGGING_MODE					// id defined, log output motion vectors to a text file


///////////////////////////////// DATA TYPES ////////////////////////////////

typedef unsigned char   BYTE;
typedef unsigned char   Byte;
typedef unsigned char   u_char;
typedef signed char     int8;
typedef unsigned char   u_int8;
typedef short           int16;
typedef unsigned short  u_int16;
typedef int            int32;
//typedef long            int32;
typedef unsigned long   u_int32;
typedef float           float32;
typedef double          float64;
typedef unsigned int coordT;
typedef _int8 booleanT;
typedef _int8 signT;
typedef signed int cellValueT;
typedef unsigned int matrixSizeT;
/*
#ifndef LARGE_PATTERN
typedef unsigned int    distanceT;
#else
typedef float           distanceT;
#endif*/
typedef float           distanceT;

/////////////////////////////////// MACROS //////////////////////////////////

// an efficient way to calculate min & max
#ifndef MIN
#define MIN(a, b) ((a) < (b) ? (a) : (b))
#endif
#ifndef MAX
#define MAX(a, b) ((a) > (b) ? (a) : (b))
#endif


// an efficient way to calculate abs (used for calculating SAD)
#define MAX_DIFF        255
#define ABS_DIFF(a, b)  ((absDiff+MAX_DIFF)[a-b])
#define SQR_DIFF(a, b)  ((SqrDiff+MAX_DIFF)[a-b])

//static u_int8 PointSkipped[IMG_HEIGHT][IMG_WIDTH];

static const u_int8 absDiff[2*MAX_DIFF+1] = {
  255,254,253,252,251,250,249,248,247,246,245,244,243,242,241,240,
  239,238,237,236,235,234,233,232,231,230,229,228,227,226,225,224,
  223,222,221,220,219,218,217,216,215,214,213,212,211,210,209,208,
  207,206,205,204,203,202,201,200,199,198,197,196,195,194,193,192,
  191,190,189,188,187,186,185,184,183,182,181,180,179,178,177,176,
  175,174,173,172,171,170,169,168,167,166,165,164,163,162,161,160,
  159,158,157,156,155,154,153,152,151,150,149,148,147,146,145,144,
  143,142,141,140,139,138,137,136,135,134,133,132,131,130,129,128,
  127,126,125,124,123,122,121,120,119,118,117,116,115,114,113,112,
  111,110,109,108,107,106,105,104,103,102,101,100, 99, 98, 97, 96,
   95, 94, 93, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83, 82, 81, 80,
   79, 78, 77, 76, 75, 74, 73, 72, 71, 70, 69, 68, 67, 66, 65, 64,
   63, 62, 61, 60, 59, 58, 57, 56, 55, 54, 53, 52, 51, 50, 49, 48,
   47, 46, 45, 44, 43, 42, 41, 40, 39, 38, 37, 36, 35, 34, 33, 32,
   31, 30, 29, 28, 27, 26, 25, 24, 23, 22, 21, 20, 19, 18, 17, 16,
   15, 14, 13, 12, 11, 10,  9,  8,  7,  6,  5,  4,  3,  2,  1,  0,
    1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15, 16,
   17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32,
   33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48,
   49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64,
   65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
   81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96,
   97, 98, 99,100,101,102,103,104,105,106,107,108,109,110,111,112,
  113,114,115,116,117,118,119,120,121,122,123,124,125,126,127,128,
  129,130,131,132,133,134,135,136,137,138,139,140,141,142,143,144,
  145,146,147,148,149,150,151,152,153,154,155,156,157,158,159,160,
  161,162,163,164,165,166,167,168,169,170,171,172,173,174,175,176,
  177,178,179,180,181,182,183,184,185,186,187,188,189,190,191,192,
  193,194,195,196,197,198,199,200,201,202,203,204,205,206,207,208,
  209,210,211,212,213,214,215,216,217,218,219,220,221,222,223,224,
  225,226,227,228,229,230,231,232,233,234,235,236,237,238,239,240,
  241,242,243,244,245,246,247,248,249,250,251,252,253,254,255
};
static int32 FreqOrder[64][64];
int32 PatternWHTCoef[PAT_NUM][MAX_BASES];

struct parameters {

    // Image and  Image size
    BYTE *Image;
    int ImageWidth;
    int ImageHeight;
    
    // Template and  Template size
    BYTE *Template;
    int TemplateWidth;
    int TemplateHeight;

    // Parameters of the Algorithms
    int SsdThreshold;  
    int N;   

    // Results
	int SsdMin;
    int position_x;
    int position_y;

	//SSD
/*	int SsdThreshold;
	int SsdMin;*/
	
    // Statistics (if enabled during compilation)
    // Hi-Res
    int total_points;
    int skipped_points_bound1;
    int skipped_points_bound2;
    int skipped_points[MAX_BOUNDS];

	//matches below thresholds
	int count;
	int match[MAX_MATCH];
	int xmatch[MAX_MATCH];
	int ymatch[MAX_MATCH];

	//hIDA
	double percent_check;
	double percent_return;
	int step;

	double Ops;

};

typedef struct parameters information;

#ifdef WIN32				
#define START_COUNT_TIME	\
  _ftime (&tstruct1);       \
  time (&ltime1);           


#define END_COUNT_TIME	\
  time (&ltime2);       \
  _ftime (&tstruct2);   \
  tmp_time = (ltime2 * 1000 + tstruct2.millitm) - (ltime1 * 1000 + tstruct1.millitm);

#else						

#define START_COUNT_TIME	\
  _ftime (&tstruct1);       \
  time (&ltime1);           

#define END_COUNT_TIME	\
  time (&ltime2);		\
  ftime (&tstruct2);    \
  tmp_time = (ltime2 * 1000 + tstruct2.millitm) - (ltime1 * 1000 + tstruct1.millitm);

#endif

#define MATCH_COUNT(p)  (p)->count
#define MATCH_X(p, idx)  (p)->xmatch[(idx)]
#define MATCH_Y(p, idx)  (p)->ymatch[(idx)]
#define MATCH_DIST(p, idx)  (p)->match[(idx)]
/////////////////////// PROTOTYPES OF PUBLIC FUNCTIONS //////////////////////

void exitWithError(char *message);
int FullSearchTh(information *info);
int Ida(information *info);
int FullSearchMin(information *info);
int SsdLrpBF(information *info);
int SsdLrpSAT(information *info);
#endif