/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        fs.h                                                        *
 *                                                                           *
 * description: Functions for performing Full-Search motion estimation.      *
 *****************************************************************************/

#include <stdlib.h>
#include <memory.h>
#include <limits.h>
#include "defs.h"
#include "matrix.h"
#include "fs.h"


//////////////////////////////// PROTOTYPES /////////////////////////////////



///////////////////////////////// FUNCTIONS /////////////////////////////////

/*******************************************************************************
* This function returns the matched points below the SSD of info->SsdThreshold *
* in info->SsdMin, plus its coordinates (info->position_x, info->position_y)   *
 ******************************************************************************/
int FullSearchTh(information *info){

unsigned char *Image=info->Image;
unsigned char *Template=info->Template;
int ImageWidth=info->ImageWidth;
int ImageHeight=info->ImageHeight;
int TemplateWidth=info->TemplateWidth;
int TemplateHeight=info->TemplateHeight;

  int i,j;
 int x,y;

 int miglioreX=-1;
 int miglioreY=-1;

 int SSD=0;
 int temp;
 int count = 0;
 int SSD_MIN = info->SsdThreshold; 

 for (y=0;y<(ImageHeight-TemplateHeight+1);y++){
	 for (x=0;x<(ImageWidth-TemplateWidth+1);x++){

		 SSD=0;
		 
		 for (i=0;i<TemplateHeight;i++){
			 for (j=0;j<TemplateWidth;j++){
				 temp = Image[(y+i)*ImageWidth+(x+j)] - Template[i*TemplateWidth+j];
				 SSD = SSD + (temp*temp);
			 }
		 }
		 
		 if (SSD<SSD_MIN ) {
			 if (count<MAX_MATCH)
			 {
				 info->match[count] = SSD;
				 info->xmatch[count] = y;
				 info->ymatch[count] = x;
			 }
			 count++;
		 }
	 }
 }
 info->count = count;
 return 0;
}

/******************************************************************************
* This function returns the best match (global minimum) of the SSD in		  *
* info->SsdMin, plus its coordinates (info->position_x, info->position_y)	  *
 ******************************************************************************/
int FullSearchMin(information *info){

unsigned char *Image=info->Image;
unsigned char *Template=info->Template;
int ImageWidth=info->ImageWidth;
int ImageHeight=info->ImageHeight;
int TemplateWidth=info->TemplateWidth;
int TemplateHeight=info->TemplateHeight;

 int i,j;
 int x,y;

 int bestX=-1;
 int bestY=-1;

 int SSD=0;
 int temp;
 int SSD_MIN = INT_MAX; 
  
 for (y=0;y<(ImageHeight-TemplateHeight);y++)
 {
	 for (x=0;x<(ImageWidth-TemplateWidth);x++)
	 {
		 SSD=0;
		 for (i=0;i<TemplateHeight;i++){
			 for (j=0;j<TemplateWidth;j++){
				 temp = Image[(y+i)*ImageWidth+(x+j)] - Template[i*TemplateWidth+j];
				 SSD = SSD + (temp*temp);
			 }
		 }
		 
		 if (SSD<SSD_MIN ) {
			 SSD_MIN = SSD;
			 bestX = y;
			 bestY = x; 
		 }
	 }
 }
 
 info->SsdMin=SSD_MIN;
 info->position_x = bestX;
 info->position_y = bestY;
   
return 0;
}

