/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        image.h                                                      *
 *                                                                           *
 * description: Utility functions for handling 8-bit graylevel images.       *
 ****************************************************************************/

#ifndef _image_h_
#define _image_h_

#include "defs.h"


///////////////////////////////// DATA TYPES ////////////////////////////////
typedef unsigned char pixelT;

typedef struct {
	u_int16 rows, cols;
	u_int32 size;
	u_int8 *pixels;
	u_int8 **rowsPtr;
} Image;

typedef struct {
	u_int16 rows, cols;
	u_int32 size;
	int16 *pixels;
	int16 **rowsPtr;
} Diff_Image;

/////////////////////////////////// MACROS //////////////////////////////////

#define imRows(image)		(image->rows)
#define imCols(image)		(image->cols)
#define imSize(image)		(image->size)
#define imPixels(image)		(image->pixels)
#define imValD(image, i)	(image->pixels[i])
#define imVal(image, y, x)	(image->rowsPtr[y][x])


#define pixelsPtr(im) (im->pixels)

#define pixelVal(im, y, x) (im->pixels[y * im->cols + x])
#define pixelValD(im, i)   (im->pixels[i])

//Image *createImage(pixelT *pixels, coordT rows, coordT cols);

/////////////////////// PROTOTYPES OF PUBLIC FUNCTIONS //////////////////////

Image *allocImage(coordT rows, coordT cols);
Image *reallocImage(u_int8 *pixels, coordT rows, coordT cols);
Diff_Image *reallocDiffImage(int16 *pixels, coordT rows, coordT cols);
Diff_Image *allocDiffImage(coordT rows, coordT cols);
void destroyImage(Image *image);
void destroyDiffImage(Diff_Image *image);
void copyImage(Image *source, Image *dest);
void copyImageWithBoundary(Image *source, Image *dest, int boundSize);
Image *createImage(pixelT *pixels, coordT rows, coordT cols);

#endif