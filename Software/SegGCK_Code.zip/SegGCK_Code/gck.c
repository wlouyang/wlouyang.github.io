/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        gck.h                                                        *
 *                                                                           *
 * description: Functions for performing motion estimation using 2D Gray     *
 *              Code Kernels and the Walsh-Hadamard transform.               *
 *****************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <memory.h>
#include <limits.h>
#include "defs.h"
#include "gck.h"

#include <sys/types.h>
#include <sys/timeb.h>

///////////////////////////////// CONSTANTS /////////////////////////////////
#pragma inline_recursion(on)
#pragma inline_depth(10)
/*
#ifdef MAX_PATTERN_32
	#pragma inline_depth(10)
#else
	#ifdef MAX_PATTERN_64
		#pragma inline_depth(12)
	#else
		#pragma inline_depth(14)
	#endif
#endif
*/
// Order of increasing frequency for GCK projections. First two columns are the
// coordinats of the projection in the WHT domain. Third column is the index
// of the previous projection. This array is only suitable for blocks with
// dimensions <= 16*16.
static int32 GroupProjOrder[16*16][3];
static u_int8 MtxOffset[128];

static const int32 GroupProjOrderBasis[16][3] = {
//	y, x, prev
	0, 0, 0, // 0
	0, 1, 0, // 1
	0, 2, 1, // 2
	0, 3, 2, // 3
	1, 0, 0, // 4
	2, 0, 4, // 5
	3, 0, 5, // 6
	1, 1, 4, // 7
	2, 1, 5, // 8
	3, 1, 6, // 9
	1, 2, 7, // 10
	2, 2, 8, // 11
	3, 2, 9, // 12
	1, 3, 10, //13
	2, 3, 11, //14
	3, 3, 12, //15
};

static const int32 GroupProjOrderBasis3[16][3] = {
//	y, x, prev
	0, 0, 0, // 0
	1, 0, 0, // 1
	2, 0, 1, // 2
	3, 0, 2, // 3
	0, 1, 0, // 4
	1, 1, 1, // 5
	2, 1, 2, // 6
	3, 1, 3, // 7
	0, 2, 4, // 8
	1, 2, 8, // 9
	2, 2, 9, // 10
	3, 2, 10, // 11
	0, 3, 8, // 12
	1, 3, 12, //13
	2, 3, 13, //14
	3, 3, 14, //15
};

static const int32 incFreqProjOrder[16*16][3] = {
	0,0,0,
	1,0,0,
	0,1,0,
	1,1,1,
	2,0,1,
	0,2,2,
	2,1,3,
	1,2,3,
	3,0,4,
	2,2,6,
	0,3,5,
	3,1,6,
	1,3,7,
	3,2,9,
	2,3,9,
	4,0,8,
	0,4,10,
	4,1,11,
	1,4,12,
	3,3,13,
	4,2,13,
	2,4,14,
	5,0,15,
	0,5,16,
	5,1,17,
	4,3,19,
	3,4,19,
	1,5,18,
	5,2,20,
	2,5,21,
	4,4,25,
	6,0,22,
	5,3,25,
	3,5,26,
	0,6,23,
	6,1,24,
	1,6,27,
	6,2,28,
	2,6,29,
	5,4,30,
	4,5,30,
	6,3,32,
	3,6,33,
	7,0,31,
	0,7,34,
	7,1,35,
	1,7,36,
	5,5,39,
	7,2,37,
	6,4,39,
	4,6,40,
	2,7,38,
	7,3,41,
	3,7,42,
	8,0,43,
	6,5,47,
	5,6,47,
	0,8,44,
	8,1,45,
	1,8,46,
	7,4,49,
	4,7,50,
	8,2,48,
	2,8,51,
	8,3,52,
	6,6,55,
	3,8,53,
	7,5,55,
	5,7,56,
	9,0,54,
	0,9,57,
	9,1,58,
	8,4,60,
	4,8,61,
	1,9,59,
	9,2,62,
	2,9,63,
	7,6,65,
	6,7,65,
	9,3,64,
	8,5,67,
	5,8,68,
	3,9,66,
	10,0,69,
	9,4,72,
	4,9,73,
	0,10,70,
	10,1,71,
	7,7,77,
	1,10,74,
	8,6,77,
	6,8,78,
	10,2,75,
	2,10,76,
	9,5,80,
	5,9,81,
	10,3,79,
	3,10,82,
	8,7,88,
	7,8,88,
	10,4,84,
	4,10,85,
	11,0,83,
	9,6,90,
	6,9,91,
	0,11,86,
	11,1,87,
	1,11,89,
	11,2,92,
	2,11,93,
	10,5,94,
	5,10,95,
	11,3,96,
	8,8,98,
	3,11,97,
	9,7,98,
	7,9,99,
	11,4,100,
	10,6,103,
	6,10,104,
	4,11,101,
	12,0,102,
	0,12,105,
	12,1,106,
	1,12,107,
	12,2,108,
	11,5,110,
	9,8,113,
	8,9,113,
	5,11,111,
	2,12,109,
	10,7,115,
	7,10,116,
	12,3,112,
	3,12,114,
	11,6,118,
	6,11,119,
	12,4,117,
	4,12,120,
	9,9,127,
	13,0,121,
	10,8,127,
	8,10,128,
	0,13,122,
	13,1,123,
	1,13,124,
	12,5,126,
	5,12,129,
	13,2,125,
	11,7,131,
	7,11,132,
	2,13,130,
	13,3,133,
	3,13,134,
	12,6,135,
	6,12,136,
	10,9,139,
	9,10,139,
	13,4,137,
	4,13,138,
	11,8,141,
	8,11,142,
	14,0,140,
	0,14,143,
	14,1,144,
	13,5,146,
	12,7,149,
	7,12,150,
	5,13,147,
	1,14,145,
	14,2,148,
	2,14,151,
	10,10,156,
	14,3,152,
	11,9,156,
	9,11,157,
	3,14,153,
	13,6,154,
	6,13,155,
	12,8,160,
	8,12,161,
	14,4,158,
	4,14,159,
	13,7,166,
	7,13,167,
	15,0,162,
	14,5,165,
	5,14,168,
	0,15,163,
	15,1,164,
	11,10,172,
	10,11,172,
	1,15,169,
	15,2,170,
	12,9,174,
	9,12,175,
	2,15,171,
	15,3,173,
	14,6,177,
	6,14,178,
	3,15,176,
	13,8,179,
	8,13,180,
	15,4,181,
	4,15,182,
	11,11,190,
	14,7,183,
	12,10,190,
	10,12,191,
	7,14,184,
	15,5,186,
	5,15,187,
	13,9,194,
	9,13,195,
	15,6,198,
	14,8,201,
	8,14,202,
	6,15,199,
	12,11,205,
	11,12,205,
	13,10,207,
	10,13,208,
	15,7,206,
	7,15,209,
	14,9,212,
	9,14,213,
	15,8,215,
	12,12,218,
	8,15,216,
	13,11,218,
	11,13,219,
	14,10,220,
	10,14,221,
	15,9,224,
	9,15,225,
	13,12,227,
	12,13,227,
	14,11,229,
	11,14,230,
	15,10,231,
	10,15,232,
	13,13,235,
	14,12,235,
	12,14,236,
	15,11,237,
	11,15,238,
	14,13,241,
	13,14,241,
	15,12,242,
	12,15,243,
	14,14,246,
	15,13,246,
	13,15,247,
	15,14,250,
	14,15,250,
	15,15,253 };


//////////////////////////////// PROTOTYPES /////////////////////////////////

Matrix *createWHBaseVectors();
void calcWHMat(Matrix *mat, u_int16 dim);
Matrix *snakeVectorsOrder();
Matrix *GroupedOrder();
Matrix *GroupedOrder2();
Matrix *GroupedOrder3();
Matrix *incFreqVectorsOrder();
void createWHBase(Matrix* baseVectors, Matrix *base, u_int16 i, u_int16 j);
void projWHDC(GCKSetup *setup, Image *image, Matrix *dcProj, Matrix *tmpProj);
void projWHDC_Pattern(GCKSetup *setup, Image *image, Matrix *dcProj, Matrix *tmpProj);
void calcGCKOffset(int32 *offset, int32 *sign, Matrix *basesVectors, int32 curVecNum, int32 prevVecNum);
//void singleWHProjByRow(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign);
//void singleWHProjByCol(Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign);
void singleWHProjByRow_Pattern(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign);
void singleWHProjByCol_Pattern(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign);
void insertMatch (MatchQueue *matchQueue, u_int16 y, u_int16 x, u_int32 distance);
u_int32 calcSAD(Image *curImage, u_int16 curY, u_int16 curX, Image *prevImage, u_int16 prevY, u_int16 prevX);
void setBoundaryZerosProjs(GCKSetup *setup, Matrix **prvImgProj, basisT BaseStart, basisT BaseEnd);


///////////////////////////////// FUNCTIONS /////////////////////////////////

/******************************************************************************
 * Creates and returns a GCKSetup.                                            *
 ******************************************************************************/
int32 BasesInOneCol[128];
int32 BasesInOneRow[128];
int BOUNDARY_SIZE_IMG, BLOCK_SIZE_IMG;

void PrepareBasis(GCKSetup *setup, int BasisNum)
{
	int32 i, j;
	int32 counter;
	int32 NumBases, Maxi, Maxj;
	NumBases = 64;
	Maxi = 8;
	Maxj = 8;
	for (counter = 0; counter<NumBases; counter++)
	{
		i = matVal(setup->baseVectorsOrder,counter,0);
		j = matVal(setup->baseVectorsOrder,counter,1);
		setup->Idx[i][j] = counter;
		FreqOrder[i][j] = counter;
	}
	for (j=0; j<Maxj; j++)
	{	
		BasesInOneCol[j] = 0;
		for (i=0; i<Maxi; i++)
		{
			if (setup->Idx[i][j]<BasisNum)
				BasesInOneCol[j]++;
		}
	}	
	for (i=0; i<Maxi; i++)
	{	
		BasesInOneRow[j] = 0;
		for (j=0; j<Maxj; j++)
		{
			if (setup->Idx[i][j]<BasisNum)
				BasesInOneRow[i]++;
		}
	}	
}

__inline u_int32 calcSSD(u_int8 *sourcePtr, u_int16 sourceDif, u_int8 *destPtr, u_int16 destDif, int BLOCK_SIZE_IMG) 
{
	 
	  register u_int32 sad;
/*	  u_int8 *destPtr;
	  u_int16 destDif;*/
	  register u_int16 cols;
	  register u_int16 rows;
/*	  int32 DstWidth = destDif+BLOCK_SIZE_IMG;
	  int32 SrcWidth = sourceDif+BLOCK_SIZE_IMG;*/
	  u_int32 *pSqrDiff = SqrDiff+MAX_DIFF;
	  int i, j;
	 sad = 0;

	 rows = BLOCK_SIZE_IMG;
     cols = BLOCK_SIZE_IMG;
#if 1
	 do {
		 do { 
/*			 int32 tmp;
			 tmp = *destPtr - *sourcePtr;
            sad += tmp*tmp;*/
 /*			 tmp = *destPtr - *sourcePtr;
            sad += SQR_DIFF(tmp);*/
			 sad += pSqrDiff[*destPtr-*sourcePtr];
			sourcePtr++;
			destPtr++;
			cols--;
		 }while(cols!=0);		
		 sourcePtr += sourceDif;
		 destPtr += destDif;
		 cols = BLOCK_SIZE_IMG;
		 rows--;
	 } while(rows!=0);
#endif
/*	 for (i=0; i<BLOCK_SIZE_IMG; i++)
		 for (j=0; j<BLOCK_SIZE_IMG; j++) {
			 int temp2 = (int)destPtr[i*DstWidth+j]-sourcePtr[i*SrcWidth+j];
			 sad += temp2*temp2;
		 }*/

	 /*
	  * This version is simpler to understand but slower
			
	 for (i=curX; i<maxX; i++)
		 for (j=curY; j<maxY; j++) {
			 sad += ABS_DIFF(matVal(curImage, j, i), matVal(prevImage, j-offsetY, i-offsetX));
		 }
	 */

	 return sad;
 }

__inline Matrix *GroupedOrder2() {

	Matrix *result = allocMatrix(BLOCK_SIZE_IMG * BLOCK_SIZE_IMG, 3);
	int16 i, j, counter;
	counter = 0;
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis[counter][1];
			GroupProjOrder[counter][1] = GroupProjOrderBasis[counter][0];
			GroupProjOrder[counter][2] = GroupProjOrderBasis[counter][2];
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis[counter-16][1]+4;
			GroupProjOrder[counter][1] = GroupProjOrderBasis[counter-16][0];
			GroupProjOrder[counter][2] = GroupProjOrderBasis[counter-16][2]+16;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis[counter-32][1];
			GroupProjOrder[counter][1] = GroupProjOrderBasis[counter-32][0]+4;
			GroupProjOrder[counter][2] = GroupProjOrderBasis[counter-32][2]+32;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis[counter-48][1]+4;
			GroupProjOrder[counter][1] = GroupProjOrderBasis[counter-48][0]+4;
			GroupProjOrder[counter][2] = GroupProjOrderBasis[counter-48][2]+48;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis[counter-64][1]+8;
			GroupProjOrder[counter][1] = GroupProjOrderBasis[counter-64][0];
			GroupProjOrder[counter][2] = GroupProjOrderBasis[counter-64][2]+64;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis[counter-80][1];
			GroupProjOrder[counter][1] = GroupProjOrderBasis[counter-80][0]+8;
			GroupProjOrder[counter][2] = GroupProjOrderBasis[counter-80][2]+80;
			counter++;
		}
	GroupProjOrder[0][2] = 0;
	GroupProjOrder[16][2] = 3;
	GroupProjOrder[32][2] = 6;
	GroupProjOrder[48][2] = 22;
	GroupProjOrder[64][2] = 19;
	GroupProjOrder[80][2] = 38;
//	GroupProjOrder[19][2] = 18;
	GroupProjOrder[32][2] = 6;
	GroupProjOrder[51][2] = 32;
	memcpy(result->cellValues, GroupProjOrder, MAX_BASES*3*sizeof(int32));
	return result;
}

__inline Matrix *GroupedOrder8() {

	Matrix *result = allocMatrix(BLOCK_SIZE_IMG * BLOCK_SIZE_IMG, 3);
	int16 i, j, counter;
	counter = 0;
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis[counter][1];
			GroupProjOrder[counter][1] = GroupProjOrderBasis[counter][0];
			GroupProjOrder[counter][2] = GroupProjOrderBasis[counter][2];
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis[counter-16][1]+4;
			GroupProjOrder[counter][1] = GroupProjOrderBasis[counter-16][0];
			GroupProjOrder[counter][2] = GroupProjOrderBasis[counter-16][2]+16;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis[counter-32][1];
			GroupProjOrder[counter][1] = GroupProjOrderBasis[counter-32][0]+4;
			GroupProjOrder[counter][2] = GroupProjOrderBasis[counter-32][2]+32;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis[counter-48][1]+4;
			GroupProjOrder[counter][1] = GroupProjOrderBasis[counter-48][0]+4;
			GroupProjOrder[counter][2] = GroupProjOrderBasis[counter-48][2]+48;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis[counter-64][1]+8;
			GroupProjOrder[counter][1] = GroupProjOrderBasis[counter-64][0];
			GroupProjOrder[counter][2] = GroupProjOrderBasis[counter-64][2]+64;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis[counter-80][1]+12;
			GroupProjOrder[counter][1] = GroupProjOrderBasis[counter-80][0];
			GroupProjOrder[counter][2] = GroupProjOrderBasis[counter-80][2]+80;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis[counter-96][1];
			GroupProjOrder[counter][1] = GroupProjOrderBasis[counter-96][0]+8;
			GroupProjOrder[counter][2] = GroupProjOrderBasis[counter-96][2]+96;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis[counter-112][1]+4;
			GroupProjOrder[counter][1] = GroupProjOrderBasis[counter-112][0]+8;
			GroupProjOrder[counter][2] = GroupProjOrderBasis[counter-112][2]+112;
			counter++;
		}
	GroupProjOrder[0][2] = 0;
	GroupProjOrder[16][2] = 3;
	GroupProjOrder[32][2] = 6;
	GroupProjOrder[48][2] = 22;
	GroupProjOrder[64][2] = 19;
	GroupProjOrder[80][2] = 67;
//	GroupProjOrder[19][2] = 18;
	GroupProjOrder[32][2] = 6;
	GroupProjOrder[96][2] = 38;
	GroupProjOrder[112][2] = 54;
	memcpy(result->cellValues, GroupProjOrder, MAX_BASES*3*sizeof(int32));
	return result;
}

GCKSetup *createKHTSetup(int AlgChoice, coordT sourceRows, 
						 coordT sourceCols, coordT patternRows, basisT numOfBasis)
{

	int32 i, j;
	int32 counter;
	int32 NumBases;
	int32 NumBasesToPrint, Maxi, Maxj;
	int32 Max_offset, Boundary_Size_Pat;

	GCKSetup *setup = (GCKSetup *)malloc(sizeof(GCKSetup));

	if (!setup)
		exitWithError("ERROR in createGCKSetup: can't allocate setup.");
	setup->Img_Heihgt = sourceRows;
	setup->Img_Width = sourceCols;
	setup->Block_size_img = patternRows*SCALE;
	setup->Block_size_pat = patternRows;
	setup->Bases_Num = numOfBasis;
	Max_offset = setup->Block_size_img>>1;
	setup->Boundary_Size_Img = setup->Block_size_img+Max_offset;

	Boundary_Size_Pat = setup->Block_size_pat+Max_offset;
	setup->Img_Width_With_Boundary = setup->Img_Width + setup->Boundary_Size_Img;
	setup->Img_Height_With_Boundary= setup->Img_Heihgt+ setup->Boundary_Size_Img;
	setup->Pat_Width_With_Boundary = setup->Block_size_pat + Boundary_Size_Pat;
	setup->Pat_Height_With_Boundary= setup->Block_size_pat + Boundary_Size_Pat;
	setup->Boundary_Size_Pat = Boundary_Size_Pat;
	BOUNDARY_SIZE_IMG = setup->Boundary_Size_Img;
	BLOCK_SIZE_IMG = setup->Block_size_img;
	setup->ImgProj_Width =setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG+1;
	setup->ImgProj_Height =setup->Img_Height_With_Boundary-BLOCK_SIZE_IMG+1;
	setup->PatProj_Width =setup->Pat_Width_With_Boundary-BLOCK_SIZE_IMG+1;
	setup->PatProj_Height =setup->Pat_Height_With_Boundary-BLOCK_SIZE_IMG+1;

	setup->ProjExtraH = 0;

	setup->prevImage = allocImage(setup->Img_Height_With_Boundary, setup->Img_Width_With_Boundary);
	setup->curImage = allocImage(setup->Pat_Height_With_Boundary, setup->Pat_Width_With_Boundary);

	setup->diffImage = allocDiffImage(setup->Img_Height_With_Boundary, setup->Img_Width_With_Boundary);
	setup->baseVectors = createWHBaseVectors();
	setup->baseVectorsOrder = GroupedOrder2();

		NumBasesToPrint = MAX_BASES ;
		Maxi = 16;
		Maxj = 16;
	for (i=0; i<Maxi; i++)
	{
		for (j=0; j<Maxj; j++)
			setup->Idx[i][j]=0;
	}
	for (counter = 0; counter<NumBasesToPrint; counter++)
	{
		i = matVal(setup->baseVectorsOrder,counter,0);
		j = matVal(setup->baseVectorsOrder,counter,1);
		setup->Idx[i][j] = counter;
		FreqOrder[i][j] = counter;
	}

//this code is used for showing the order information
#if SHOW_MY_STATS	
	for (i=0; i<Maxi; i++)
	{
		for (j=0; j<Maxj; j++)
		{
			printf("%3d ", setup->Idx[i][j]);
		}
		printf("\n", setup->Idx[i][j]);
	}
#endif

	setup->colsProj = allocMatrix(setup->Img_Height_With_Boundary+1, setup->Img_Width_With_Boundary+1);
	setup->tmpProj = allocMatrix(setup->Img_Height_With_Boundary, setup->Img_Width_With_Boundary);
	setup->tmpProjPat = allocMatrix(setup->Pat_Height_With_Boundary, setup->Pat_Width_With_Boundary);
	
	setup->bestMatches = allocMatchQueue(MATCHES_FOR_SAD);

	setup->curImageProj = (Matrix **)malloc(sizeof(Matrix *) * (MAX_BASES+4));
	setup->prevImageProj = (Matrix **)malloc(sizeof(Matrix *) * (MAX_BASES+4));
	setup->distances = allocMatrix_Dist(setup->Img_Heihgt, setup->Img_Width);
#ifdef MY_DEBUG
	setup->curImageProj2 = (Matrix **)malloc(sizeof(Matrix *) * (MAX_BASES+4));
	for (i=0; i<MAX_BASES+4; i++) {
		setup->curImageProj2[i] = allocMatrix(setup->Img_Height_With_Boundary, setup->ImgProj_Width);
	}
#endif
	for (i=0; i<MAX_BASES+4; i++) {
		setup->prevImageProj[i] = allocMatrix(setup->Img_Height_With_Boundary, setup->ImgProj_Width);
	}
	NumBases = (MAX_BASES+4);
	for (i=0; i<NumBases; i++) {
		setup->curImageProj[i] = allocMatrix(setup->Pat_Height_With_Boundary, setup->Pat_Width_With_Boundary);
	}

	// arrange pointers for projection values
	i = 7;
	while (i<MAX_BASES)
	{
		Matrix *pProjCur, *pProjPrev;
		int32 ImgProjRowOffset = (setup->Block_size_img/4);//row offsef from one projection to another
		int ProjExtraH = setup->Block_size_pat - (setup->Block_size_pat/4)-1;
		if ( (i&15) == 0)
		{
			i+=1;
			for (j=0; j<3; j++)
			{
				int row;
				// for image
				pProjCur = setup->prevImageProj[i+j];
				pProjPrev = setup->prevImageProj[i+j-1];
				for (row = 0; row < setup->ImgProj_Height+ProjExtraH; row++) {
					pProjCur->rowsPtr[row] = pProjPrev->rowsPtr[row+ImgProjRowOffset];
				}

				// for pattern
				pProjCur = setup->curImageProj[i+j];
				pProjPrev = setup->curImageProj[i+j-1];
				for (row = 0; row < setup->PatProj_Height+ProjExtraH; row++) {
					pProjCur->rowsPtr[row] = pProjPrev->rowsPtr[row+ImgProjRowOffset];
				}
			}
			i+=6;
		}
		for (j=0; j<3; j++)
		{
			int row;
				// for image
//				printf( " image  ");
			pProjCur = setup->prevImageProj[i+j];
			pProjPrev = setup->prevImageProj[i+j-3];
//			printf( "setup->Img_Height_With_Boundary:  %d  rows: %d \n", setup->Img_Height_With_Boundary, setup->ImgProj_Height+ProjExtraH);
//			printf( "ImgProjRowOffset: %d \n", ImgProjRowOffset);
//				printf( "i+j-3: %d, pProjCur:  %x  pProjPrev: %x", i+j-3, pProjCur->rowsPtr[0], pProjPrev->rowsPtr[ImgProjRowOffset]);
			for (row = 0; row < setup->ImgProj_Height+ProjExtraH; row++) {
//				printf( "row: %d pProjCur:  %x  pProjPrev: %x \n", row, pProjCur->rowsPtr[row], pProjPrev->rowsPtr[row+ImgProjRowOffset]);
				pProjCur->rowsPtr[row] = pProjPrev->rowsPtr[row+ImgProjRowOffset];
			} 
//				printf( " pattern  ");
			
				// for pattern
			pProjCur = setup->curImageProj[i+j];
			pProjPrev = setup->curImageProj[i+j-3];
			for (row = 0; row < setup->PatProj_Height+ProjExtraH; row++) {
				pProjCur->rowsPtr[row] = pProjPrev->rowsPtr[row+ImgProjRowOffset];
			}
		}
		i+=3;
	}
	// arrange memory status

	setBoundaryZerosProjs(setup, setup->prevImageProj, 0, numOfBasis);
	PrepareBasis(setup, numOfBasis);
	return setup;
}

//Segmenting by 8
GCKSetup *createKHTSetup8(int AlgChoice, coordT sourceRows, 
						 coordT sourceCols, coordT patternRows, basisT numOfBasis)
{
	int32 i, j;
	int32 counter;
	int32 NumBases;
	int32 NumBasesToPrint, Maxi, Maxj;
	int32 Max_offset, Boundary_Size_Pat;

	GCKSetup *setup = (GCKSetup *)malloc(sizeof(GCKSetup));

	if (!setup)
		exitWithError("ERROR in createGCKSetup: can't allocate setup.");
	setup->Img_Heihgt = sourceRows;
	setup->Img_Width = sourceCols;
	setup->Block_size_img = patternRows*SCALE;
	setup->Block_size_pat = patternRows;
	setup->Bases_Num = numOfBasis;
	Max_offset = setup->Block_size_img>>1;
	setup->Boundary_Size_Img = setup->Block_size_img+Max_offset;

	Boundary_Size_Pat = setup->Block_size_pat+Max_offset;
	setup->Img_Width_With_Boundary = setup->Img_Width + setup->Boundary_Size_Img;
	setup->Img_Height_With_Boundary= setup->Img_Heihgt+ setup->Boundary_Size_Img;
	setup->Pat_Width_With_Boundary = setup->Block_size_pat + Boundary_Size_Pat;
	setup->Pat_Height_With_Boundary= setup->Block_size_pat + Boundary_Size_Pat;
	setup->Boundary_Size_Pat = Boundary_Size_Pat;
	BOUNDARY_SIZE_IMG = setup->Boundary_Size_Img;
	BLOCK_SIZE_IMG = setup->Block_size_img;
	setup->ImgProj_Width =setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG+1;
	setup->ImgProj_Height =setup->Img_Height_With_Boundary-BLOCK_SIZE_IMG+1;
	setup->PatProj_Width =setup->Pat_Width_With_Boundary-BLOCK_SIZE_IMG+1;
	setup->PatProj_Height =setup->Pat_Height_With_Boundary-BLOCK_SIZE_IMG+1;

	setup->ProjExtraH = 0;

	setup->prevImage = allocImage(setup->Img_Height_With_Boundary, setup->Img_Width_With_Boundary);
	setup->curImage = allocImage(setup->Pat_Height_With_Boundary, setup->Pat_Width_With_Boundary);

	setup->diffImage = allocDiffImage(setup->Img_Height_With_Boundary, setup->Img_Width_With_Boundary);
	setup->baseVectors = createWHBaseVectors();
	setup->baseVectorsOrder = GroupedOrder8();

		NumBasesToPrint = MAX_BASES ;
		Maxi = 16;
		Maxj = 16;
	for (i=0; i<Maxi; i++)
	{
		for (j=0; j<Maxj; j++)
			setup->Idx[i][j]=0;
	}
	for (counter = 0; counter<NumBasesToPrint; counter++)
	{
		i = matVal(setup->baseVectorsOrder,counter,0);
		j = matVal(setup->baseVectorsOrder,counter,1);
		setup->Idx[i][j] = counter;
		FreqOrder[i][j] = counter;
	}

//this code is used for showing the order information
#if SHOW_MY_STATS	
	for (i=0; i<Maxi; i++)
	{
		for (j=0; j<Maxj; j++)
		{
			printf("%3d ", setup->Idx[i][j]);
		}
		printf("\n", setup->Idx[i][j]);
	}
#endif

	setup->colsProj = allocMatrix(setup->Img_Height_With_Boundary+1, setup->Img_Width_With_Boundary+1);
	setup->tmpProj = allocMatrix(setup->Img_Height_With_Boundary, setup->Img_Width_With_Boundary);
	setup->tmpProjPat = allocMatrix(setup->Pat_Height_With_Boundary, setup->Pat_Width_With_Boundary);
	
	setup->bestMatches = allocMatchQueue(MATCHES_FOR_SAD);

	setup->curImageProj = (Matrix **)malloc(sizeof(Matrix *) * (MAX_BASES+4));
	setup->prevImageProj = (Matrix **)malloc(sizeof(Matrix *) * (MAX_BASES+4));
	setup->distances = allocMatrix_Dist(setup->Img_Heihgt, setup->Img_Width);
#ifdef MY_DEBUG
	setup->curImageProj2 = (Matrix **)malloc(sizeof(Matrix *) * (MAX_BASES+4));
	for (i=0; i<MAX_BASES+4; i++) {
		setup->curImageProj2[i] = allocMatrix(setup->Img_Height_With_Boundary, setup->ImgProj_Width);
	}
#endif
	for (i=0; i<MAX_BASES+4; i++) {
		setup->prevImageProj[i] = allocMatrix(setup->Img_Height_With_Boundary, setup->ImgProj_Width);
	}
	NumBases = (MAX_BASES+4);
	for (i=0; i<NumBases; i++) {
		setup->curImageProj[i] = allocMatrix(setup->Pat_Height_With_Boundary, setup->Pat_Width_With_Boundary);
	}

	// arrange pointers for projection values
	i = 7;
	while (i<MAX_BASES)
	{
		Matrix *pProjCur, *pProjPrev;
		int32 ImgProjRowOffset = (setup->Block_size_img/8);//row offsef from one projection to another
		int ProjExtraH = setup->Block_size_pat - (setup->Block_size_pat/8)-1;
		if ( (i&15) == 0)
		{
			if (i==16)
			{
					static int offset[4] = {13, 7, 7, 7};
					static int ProjOffset[4] = {0, 4, 5, 6};
				int ImgProjRowOffset2 = ImgProjRowOffset*2;
				int row;
				for (j=0; j<4; j++)
				{
					int row;
					// for image
					pProjCur = setup->prevImageProj[i+ProjOffset[j]];
					pProjPrev = setup->prevImageProj[i+ProjOffset[j]-16];
					if (j!=0)
					for (row = 0; row < setup->ImgProj_Height+ProjExtraH; row++) {
						pProjCur->rowsPtr[row] = pProjPrev->rowsPtr[row+ImgProjRowOffset*4];
					}

					// for pattern
					pProjCur = setup->curImageProj[i+ProjOffset[j]];
					pProjPrev = setup->curImageProj[i+ProjOffset[j]-16];
					for (row = 0; row < setup->PatProj_Height+ProjExtraH; row++) {
						pProjCur->rowsPtr[row] = pProjPrev->rowsPtr[row+ImgProjRowOffset*4];
					}
				}
				i++;
				for (j=0; j<3; j++)
				{
					int row;
					// for image
					pProjCur = setup->prevImageProj[i+j];
					pProjPrev = setup->prevImageProj[i+j-1];
					for (row = 0; row < setup->ImgProj_Height+ProjExtraH - (setup->Block_size_pat/8); row++) 
						pProjCur->rowsPtr[row] = pProjPrev->rowsPtr[row+ImgProjRowOffset2];
					// for pattern
					pProjCur = setup->curImageProj[i+j];
					pProjPrev = setup->curImageProj[i+j-1];
					for (row = 0; row < setup->PatProj_Height+ProjExtraH; row++) 
						pProjCur->rowsPtr[row] = pProjPrev->rowsPtr[row+ImgProjRowOffset];					
				}
				i+=6;
			}
			else 
			{
				if ((i&16) == 0)
					i+=1;
				if ((i&16) != 0)
				{
					int row;
					static int offset[4] = {13, 7, 7, 7};
					static int ProjOffset[4] = {0, 4, 5, 6};
					// for image
					for (j=0; j<4; j++)
					{
						pProjCur = setup->prevImageProj[i+ProjOffset[j]];
						pProjPrev = setup->prevImageProj[i+ProjOffset[j]-16];
						for (row = 0; row < setup->ImgProj_Height+ProjExtraH; row++) {
							pProjCur->rowsPtr[row] = pProjPrev->rowsPtr[row+ImgProjRowOffset*4];
						}

						// for pattern
						pProjCur = setup->curImageProj[i+ProjOffset[j]];
						pProjPrev = setup->curImageProj[i+ProjOffset[j]-16];
						for (row = 0; row < setup->PatProj_Height+ProjExtraH; row++) {
							pProjCur->rowsPtr[row] = pProjPrev->rowsPtr[row+ImgProjRowOffset*4];
						}
					}
					i+=1;
				}
				for (j=0; j<3; j++)
				{
					int row;
					// for image
					pProjCur = setup->prevImageProj[i+j];
					pProjPrev = setup->prevImageProj[i+j-1];
					for (row = 0; row < setup->ImgProj_Height+ProjExtraH; row++) {
						pProjCur->rowsPtr[row] = pProjPrev->rowsPtr[row+ImgProjRowOffset];
					}

					// for pattern
					pProjCur = setup->curImageProj[i+j];
					pProjPrev = setup->curImageProj[i+j-1];
					for (row = 0; row < setup->PatProj_Height+ProjExtraH; row++) {
						pProjCur->rowsPtr[row] = pProjPrev->rowsPtr[row+ImgProjRowOffset];
					}
				}
				i+=6;
			}
		}
		for (j=0; j<3; j++)
		{
			int row;
				// for image
//				printf( " image  ");
			pProjCur = setup->prevImageProj[i+j];
			pProjPrev = setup->prevImageProj[i+j-3];
//			printf( "setup->Img_Height_With_Boundary:  %d  rows: %d \n", setup->Img_Height_With_Boundary, setup->ImgProj_Height+ProjExtraH);
//			printf( "ImgProjRowOffset: %d \n", ImgProjRowOffset);
//				printf( "i+j-3: %d, pProjCur:  %x  pProjPrev: %x", i+j-3, pProjCur->rowsPtr[0], pProjPrev->rowsPtr[ImgProjRowOffset]);
			for (row = 0; row < setup->ImgProj_Height+ProjExtraH; row++) {
//				printf( "row: %d pProjCur:  %x  pProjPrev: %x \n", row, pProjCur->rowsPtr[row], pProjPrev->rowsPtr[row+ImgProjRowOffset]);
				pProjCur->rowsPtr[row] = pProjPrev->rowsPtr[row+ImgProjRowOffset];
			} 
//				printf( " pattern  ");
			
				// for pattern
			pProjCur = setup->curImageProj[i+j];
			pProjPrev = setup->curImageProj[i+j-3];
			for (row = 0; row < setup->PatProj_Height+ProjExtraH; row++) {
				pProjCur->rowsPtr[row] = pProjPrev->rowsPtr[row+ImgProjRowOffset];
			}
		}
		i+=3;
	}
	// arrange memory status

	setBoundaryZerosProjs(setup, setup->prevImageProj, 0, numOfBasis);
	PrepareBasis(setup, numOfBasis);
	return setup;
}

GCKSetup *createGCKSetup(int AlgChoice, coordT sourceRows, 
						 coordT sourceCols, coordT patternRows, basisT numOfBasis)
{

	int32 i, j;
	int32 counter;
	int32 NumBases;
//	int32 Idx[BLOCK_SIZE][BLOCK_SIZE];
	int32 NumBasesToPrint, Maxi, Maxj;
	int32 Max_offset, Boundary_Size_Pat;

	GCKSetup *result = (GCKSetup *)malloc(sizeof(GCKSetup));

	if (!result)
		exitWithError("ERROR in createGCKSetup: can't allocate setup.");
	result->Img_Heihgt = sourceRows;
	result->Img_Width = sourceCols;
	result->Block_size_img = patternRows*SCALE;
	result->Block_size_pat = patternRows;
	result->Bases_Num = numOfBasis;
	Max_offset = result->Block_size_img>>1;
	result->Boundary_Size_Img = result->Block_size_img+Max_offset;

	Boundary_Size_Pat = result->Block_size_pat+Max_offset;
	result->Img_Width_With_Boundary = result->Img_Width + result->Boundary_Size_Img;
	result->Img_Height_With_Boundary= result->Img_Heihgt+ result->Boundary_Size_Img;
	result->Pat_Width_With_Boundary = result->Block_size_pat + Boundary_Size_Pat;
	result->Pat_Height_With_Boundary= result->Block_size_pat + Boundary_Size_Pat;
	result->Boundary_Size_Pat = Boundary_Size_Pat;
//	result->Block_Size_Img_Div4 = result->Block_size_img >> 2;
	BOUNDARY_SIZE_IMG = result->Boundary_Size_Img;
	BLOCK_SIZE_IMG = result->Block_size_img;
	result->ImgProj_Width =result->Img_Width_With_Boundary-BLOCK_SIZE_IMG+1;
	result->ImgProj_Height =result->Img_Height_With_Boundary-BLOCK_SIZE_IMG+1;
	result->ProjExtraH = 0;

	result->prevImage = allocImage(result->Img_Height_With_Boundary, result->Img_Width_With_Boundary);
	result->curImage = allocImage(result->Pat_Height_With_Boundary, result->Pat_Width_With_Boundary);

	result->diffImage = allocDiffImage(result->Img_Height_With_Boundary, result->Img_Width_With_Boundary);
	result->baseVectors = createWHBaseVectors();
	if (AlgChoice == CHOICE_HELOR_GCK)
		result->baseVectorsOrder = GroupedOrder8();
//		result->baseVectorsOrder = incFreqVectorsOrder();

//		result->baseVectorsOrder = GroupedOrder2();
//		result->baseVectorsOrder = snakeVectorsOrder();
	else if (AlgChoice == CHOICE_WANLI_GCK)
		result->baseVectorsOrder = GroupedOrder2();

/*
	if (PROJECTIONS_ORDER == SNAKE_ORDER)
		result->baseVectorsOrder = snakeVectorsOrder();
	else if (PROJECTIONS_ORDER == INCREASING_FREQUENCY_ORDER)
		result->baseVectorsOrder = incFreqVectorsOrder();
	else if (PROJECTIONS_ORDER == GROUP_ORDER)
		result->baseVectorsOrder = GroupedOrder();
	else if (PROJECTIONS_ORDER == GROUP_ORDER2)
		result->baseVectorsOrder = GroupedOrder2();
	else if (PROJECTIONS_ORDER == GROUP_ORDER3)
		result->baseVectorsOrder = GroupedOrder3();
*/

/*	if (PROJECTIONS_ORDER == GROUP_ORDER || PROJECTIONS_ORDER == GROUP_ORDER2|| PROJECTIONS_ORDER == GROUP_ORDER3)
	{
		NumBasesToPrint = 64;
		Maxi = 8;
		Maxj = 8;
	}
	else
	{
		NumBasesToPrint = result->Block_size_pat * result->Block_size_pat;
		Maxi = result->Block_size_pat;
		Maxj = result->Block_size_pat;
	}*/
		NumBasesToPrint = MAX_BASES;
		Maxi = 16;
		Maxj = 16;
	for (i=0; i<Maxi; i++)
	{
		for (j=0; j<Maxj; j++)
			result->Idx[i][j]=0;
	}
	for (counter = 0; counter<NumBasesToPrint; counter++)
	{
		i = matVal(result->baseVectorsOrder,counter,0);
		j = matVal(result->baseVectorsOrder,counter,1);
		result->Idx[i][j] = counter;
		FreqOrder[i][j] = counter;
	}
/*	for (j=0; j<Maxj; j++)
	{	
		BasesInOneCol[j] = 0;
		for (i=0; i<Maxi; i++)
		{
			if (result->Idx[i][j]<numOfBasis)
				BasesInOneCol[j]++;
		}
	}	
	for (i=0; i<Maxi; i++)
	{	
		BasesInOneRow[j] = 0;
		for (j=0; j<Maxj; j++)
		{
			if (result->Idx[i][j]<numOfBasis)
				BasesInOneRow[i]++;
		}
	}	
*/

//this code is used for showing the order information
#if SHOW_MY_STATS	
	for (i=0; i<Maxi; i++)
	{
		for (j=0; j<Maxj; j++)
		{
			printf("%3d ", result->Idx[i][j]);
		}
		printf("\n", result->Idx[i][j]);
	}
#endif

	result->colsProj = allocMatrix(result->Img_Height_With_Boundary+1, result->Img_Width_With_Boundary+1);
	result->tmpProj = allocMatrix(result->Img_Height_With_Boundary, result->Img_Width_With_Boundary);
	result->tmpProjPat = allocMatrix(result->Pat_Height_With_Boundary, result->Pat_Width_With_Boundary);
	result->bestMatches = allocMatchQueue(MATCHES_FOR_SAD);

	result->curImageProj = (Matrix **)malloc(sizeof(Matrix *) * (MAX_BASES+MAX_BASES/4));
	result->prevImageProj = (Matrix **)malloc(sizeof(Matrix *) * (MAX_BASES+MAX_BASES/4));
	result->distances = allocMatrix_Dist(result->Img_Heihgt, result->Img_Width);
#ifdef MY_DEBUG
	result->curImageProj2 = (Matrix **)malloc(sizeof(Matrix *) * (MAX_BASES+MAX_BASES/4));
	for (i=0; i<MAX_BASES+MAX_BASES/4; i++) {
		result->curImageProj2[i] = allocMatrix(result->ImgProj_Height, result->ImgProj_Width);
	}
#endif
	for (i=0; i<MAX_BASES+MAX_BASES/4; i++) {
		result->prevImageProj[i] = allocMatrix(result->ImgProj_Height, result->ImgProj_Width);
	}
	NumBases = (MAX_BASES+MAX_BASES/4);
	for (i=0; i<NumBases; i++) {
		result->curImageProj[i] = allocMatrix(result->Pat_Height_With_Boundary-result->Block_size_pat+1, result->Pat_Width_With_Boundary-result->Block_size_pat+1);
	}
	setBoundaryZerosProjs(result, result->prevImageProj, 0, numOfBasis);
	PrepareBasis(result, numOfBasis);
	return result;
}


/*****************************************************************************
 * Destroys the given GCKSetup.                                               *
 *****************************************************************************/
void destroyGCKSetup(GCKSetup *setup) {

	int32 i;

//	for (i=MAX_BASES+MAX_BASES/4-1; i>=0; i--) {
	for (i=0; i<MAX_BASES+MAX_BASES/4; i++) {
		destroyMatrix(setup->prevImageProj[i]);
#ifdef MY_DEBUG
		destroyMatrix(setup->curImageProj2[i]);
#endif
	}
	for (i=0; i<(MAX_BASES+MAX_BASES/4); i++) {
		destroyMatrix(setup->curImageProj[i]);
	}
	free(setup->curImageProj);
	free(setup->prevImageProj);
#ifdef MY_DEBUG
	free(setup->curImageProj2);
#endif

	destroyMatchQueue(setup->bestMatches);
//	destroyMatrix(setup->distances);
	destroyMatrixDist(setup->distances);
	destroyMatrix(setup->tmpProj);
	destroyMatrix(setup->tmpProjPat);

	destroyMatrix(setup->colsProj);
	destroyMatrix(setup->baseVectorsOrder);
	destroyMatrix(setup->baseVectors);
	destroyImage(setup->prevImage);
	destroyImage(setup->curImage);
	destroyDiffImage(setup->diffImage);
	free(setup);
}


void destroyKHTSetup(GCKSetup *setup) {

	int32 i;

//	for (i=MAX_BASES+MAX_BASES/4-1; i>=0; i--) {
	for (i=0; i<MAX_BASES+4; i++) {
		destroyMatrix(setup->prevImageProj[i]);
#ifdef MY_DEBUG
		destroyMatrix(setup->curImageProj2[i]);
#endif
		destroyMatrix(setup->curImageProj[i]);
	}
	free(setup->curImageProj);
	free(setup->prevImageProj);
#ifdef MY_DEBUG
	free(setup->curImageProj2);
#endif

	destroyMatchQueue(setup->bestMatches);
//	destroyMatrix(setup->distances);
	destroyMatrixDist(setup->distances);
	destroyMatrix(setup->tmpProj);
	destroyMatrix(setup->tmpProjPat);

	destroyMatrix(setup->colsProj);
	destroyMatrix(setup->baseVectorsOrder);
	destroyMatrix(setup->baseVectors);
	destroyImage(setup->prevImage);
	destroyImage(setup->curImage);
	destroyDiffImage(setup->diffImage);
	free(setup);
}


/******************************************************************************
 * Allocates and creates a matrix that contains Walsh-Hadamard base vectors   *
 * as its rows. The vectors are in sequency order.                            *
 ******************************************************************************/
__inline Matrix *createWHBaseVectors() {	

	Matrix *unorderWH = allocMatrix(BLOCK_SIZE_IMG, BLOCK_SIZE_IMG);
	Matrix *unorderWH_conv, *indices, *result;
	Matrix *mask = allocMatrix(1,2);

	matVal(mask,0,0) = 1;
	matVal(mask,0,1) = -1;

	matVal(unorderWH,0,0) = 1;
	matVal(unorderWH,0,1) = 1;
	matVal(unorderWH,1,0) = 1;
	matVal(unorderWH,1,1) = -1;

	calcWHMat(unorderWH, 2);
	unorderWH_conv = conv2Matrix(unorderWH, mask);
	absMatrix(unorderWH_conv);
	indices = sumRowsMatrix(unorderWH_conv); 	// ordered index	
	divMatrixByConst(indices, 2);
	addConstToMatrix(indices, -1);			    // index starts from 0
	result = copyRowsByIndex(unorderWH, indices);

	destroyMatrix(unorderWH);
	destroyMatrix(unorderWH_conv);
	destroyMatrix(indices);
	destroyMatrix(mask);

	return result;
}


/******************************************************************************
 * Builds unordered Walsh-Hadmard vectors of given size recursively.		  *
 ******************************************************************************/
__inline void calcWHMat(Matrix *mat, u_int16 size) {	

	if (size == matRows(mat))
		return;

	copyMatrixSegment(mat, mat, 0, 0,    size, 0, size, size, PLUS);
	copyMatrixSegment(mat, mat, 0, size, size, 0, 0,    size, PLUS);
	copyMatrixSegment(mat, mat, 0, size, size, 0, size, size, MINUS);
	size*=2;
	calcWHMat(mat, size);
}


/******************************************************************************
 * Returns the snakee vectors order. This is an order that preserves the      *
 * alpha-relation property between each vector and the vector that precede    *
 * it.																          *
 ******************************************************************************/
__inline Matrix *snakeVectorsOrder() {

	Matrix *result = allocMatrix(BLOCK_SIZE_IMG * BLOCK_SIZE_IMG, 3);
	int16 i, j ,counter=1;
			
	matVal(result,0,0) = 0;
	matVal(result,0,1) = 0;
	matVal(result,0,2) = 0;		// previous projection

	for (i=1;i<BLOCK_SIZE_IMG;i++)	{
        for (j=0;j<=(int)i ;j++){
            if (i%2 == 1) {
                matVal(result,counter,0) = j;
                matVal(result,counter,1) = i;
            }
            else {
                matVal(result,counter,0) = i;
                matVal(result,counter,1) = j;
			}
			matVal(result,counter,2) = counter-1;	// previous projection
			counter++;
		}
		for (j=i-1;j>=0;j--){
			if (i%2 == 1) {
				matVal(result,counter,0) = i;
				matVal(result,counter,1) = j;	
			}
			else {
				matVal(result,counter,0) = j;
				matVal(result,counter,1) = i;
			}
			matVal(result,counter,2) = counter-1;	// previous projection
			counter++;
		}
	}
	return result;
}

__inline Matrix *GroupedOrder3() {

	Matrix *result = allocMatrix(BLOCK_SIZE_IMG * BLOCK_SIZE_IMG, 3);
	int16 i, j, counter;
	counter = 0;
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis3[counter][1];
			GroupProjOrder[counter][1] = GroupProjOrderBasis3[counter][0];
			GroupProjOrder[counter][2] = GroupProjOrderBasis3[counter][2];
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis3[counter-16][1]+4;
			GroupProjOrder[counter][1] = GroupProjOrderBasis3[counter-16][0];
			GroupProjOrder[counter][2] = GroupProjOrderBasis3[counter-16][2]+16;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis3[counter-32][1];
			GroupProjOrder[counter][1] = GroupProjOrderBasis3[counter-32][0]+4;
			GroupProjOrder[counter][2] = GroupProjOrderBasis3[counter-32][2]+32;
			counter++;
		}
	for (i=0; i<4; i++)
		for (j=0; j<4; j++)
		{
			GroupProjOrder[counter][0] = GroupProjOrderBasis3[counter-48][1]+4;
			GroupProjOrder[counter][1] = GroupProjOrderBasis3[counter-48][0]+4;
			GroupProjOrder[counter][2] = GroupProjOrderBasis3[counter-48][2]+48;
			counter++;
		}
	GroupProjOrder[0][2] = 0;
	GroupProjOrder[16][2] = 12;
	GroupProjOrder[32][2] = 3;
	GroupProjOrder[48][2] = 44;
	memcpy(result->cellValues, GroupProjOrder, 64*3*sizeof(int32));
	return result;
}

/******************************************************************************
 * Returns the increasing frequency vectors order. This is an order that      *
 * preserves the alpha-relation property between each vector and one of the   *
 * vector that precede it. This order gives better results than snake order   *
 * but can be used only when all previous projections are saved in memory     *
 * (always in this code).                                                     *
 ******************************************************************************/
__inline Matrix *incFreqVectorsOrder() {

	Matrix *result = allocMatrix(BLOCK_SIZE_IMG * BLOCK_SIZE_IMG, 3);

	memcpy(result->cellValues, incFreqProjOrder, BLOCK_SIZE_IMG*BLOCK_SIZE_IMG*3*sizeof(int32));

	return result;
}


/******************************************************************************
 * Creates the Walsh-Hadamard base specified by coordinates (i,j) in          *
 * basesVectors and stores it into base.                                      *
 ******************************************************************************/
__inline void createWHBase(Matrix* baseVectors, Matrix *base, u_int16 i, u_int16 j) {

	u_int16 dim = matRows(baseVectors);
	u_int16 k;

	for (k=0; k<dim; k++)
		copyMatrixSegment(baseVectors, base, 0, 0, dim, i, k, 1, matVal(baseVectors,j,k));

	return;		
}


//This is used for comparison
int Compare(GCKSetup *setup, Matrix *Proj1, Matrix *Proj2) {
	u_int16 row, col;
	u_int16 maxCols, maxRows;
	int val1, val2;
	int ret=0;
	maxCols = (u_int16)Proj1->cols;
	maxRows = (u_int16)Proj1->rows;
	for (row=setup->Boundary_Size_Img; row < maxRows; row++)
		for (col=setup->Boundary_Size_Img; col < maxCols; col++)
		{
			val1 = matVal(Proj1,row,col);
			val2 = matVal(Proj2,row,col);
			if (val1 != val2)
			{
				printf("error! should be: %d, Now: %d, row: %d, col: %d\n", val1, val2, row, col);
				return 1;
//				ret=1;
			}
		}
	return ret;
}

/******************************************************************************
 * Calculates the DC component of each window of size BLOCK_SIZE of the given *
 * image using 4 operations per pixel. The result is returned in dcProj       *
 * (which should be pre-allocated with the correct size). tmpProj is a		  *
 * pre-allocated matrix in the size of the image, used for temporary          *
 * calculations.                                                              *
 ******************************************************************************/

__inline void projWHDCDbg(GCKSetup *setup, Image *image, Matrix *dcProj, Matrix *tmpProj) {

	u_int8 *ptr1; 
	int32 *ptr2;
	u_int16 col, row;
	int32 sum;

	u_int16 RLoc, CLoc;
	u_int16 maxCols = setup->ImgProj_Width;
	u_int16 maxRows = setup->ImgProj_Height;

	for (CLoc=0; CLoc<setup->Img_Width_With_Boundary; CLoc++)  {
		ptr1 = &imVal(image, 0, CLoc);
		row = BLOCK_SIZE_IMG;
		sum = 0;

		while (row--) {
			sum += *ptr1;
			ptr1 += setup->Img_Width_With_Boundary;
		}
		matVal(tmpProj,0,CLoc) = sum;

		for (RLoc=1; RLoc<maxRows; RLoc++)
			matVal(tmpProj,RLoc,CLoc) =
					matVal(tmpProj,RLoc-1,CLoc) - imVal(image,RLoc-1,CLoc) + imVal(image,RLoc+BLOCK_SIZE_IMG-1,CLoc);
	}
	
 	for (RLoc=0; RLoc<maxRows;RLoc++)  {
		ptr2 = &imVal(tmpProj, RLoc, 0);
		col = BLOCK_SIZE_IMG;
		sum = 0;

		while (col--) 
			sum += *(ptr2++);
		matVal(dcProj,RLoc,0) = sum;

		for (CLoc=1; CLoc<maxCols; CLoc++)
			matVal(dcProj,RLoc,CLoc) =
				matVal(dcProj,RLoc,CLoc-1) - matVal(tmpProj,RLoc,CLoc-1) + matVal(tmpProj,RLoc,CLoc+BLOCK_SIZE_IMG-1);
	}
}

/******************************************************************************
 * Calculates the DC component of each window of size BLOCK_SIZE of the given *
 * image using 4 operations per pixel. The result is returned in dcProj       *
 * (which should be pre-allocated with the correct size). tmpProj is a		  *
 * pre-allocated matrix in the size of the image, used for temporary          *
 * calculations.                                                              *
 ******************************************************************************/
__inline void projWHDC(GCKSetup *setup, Image *image, Matrix *dcProj, Matrix *tmpProj) {

	u_int8 *ptr1; 
	int32 *ptr2, *ptr3;
	u_int16 col;
	int32 sum;
	int BRowSize = BLOCK_SIZE_IMG;
	int BColSize = BLOCK_SIZE_IMG;
	u_int16 RLoc, CLoc;
	u_int16 maxCols = setup->ImgProj_Width;
	u_int16 maxRows = setup->ImgProj_Height;
//	int32 *currentProjPtr, *prevProjPtr1;
	int stridePrev, strideCur;

	memset(&matVal(tmpProj,0,0), 0, sizeof(int32)*setup->Img_Width_With_Boundary);
	for (RLoc=0; RLoc<BRowSize; RLoc++)
	{
		ptr1 = &imVal(image, 0, 0);
		ptr2 = &matVal(tmpProj,RLoc,0);
		for (CLoc=0; CLoc<setup->Img_Width_With_Boundary; CLoc++)  {
			*ptr2 += *ptr1;
			ptr2++;
			ptr1++;
		}
	}


	for (RLoc=1; RLoc<maxRows; RLoc++)
	{
		ptr2 = &matVal(tmpProj,RLoc-1,0);
		strideCur = &matVal(tmpProj,RLoc,0) - &matVal(tmpProj,RLoc-1,0);
		ptr1 = &imVal(image,RLoc-1,0);
		stridePrev = &matVal(image,RLoc+BRowSize-1,0) - &matVal(image,RLoc-1,0);
		for (CLoc=0; CLoc<setup->Img_Width_With_Boundary; CLoc++)  
		{
			ptr2[strideCur] = *ptr2 - *ptr1 + ptr1[stridePrev];
			ptr2++;
			ptr1++;
		}
	}
	
 	for (RLoc=0; RLoc<maxRows;RLoc++)  {
		ptr2 = &imVal(tmpProj, RLoc, 0);
		col = BColSize;
		sum = 0;

		while (col--) 
			sum += *(ptr2++);
		matVal(dcProj,RLoc,0) = sum;

		ptr2 = &matVal(tmpProj,RLoc,0);
		ptr3 = &matVal(dcProj,RLoc,0);
		for (CLoc=1; CLoc<maxCols; CLoc++)
		{
			ptr3[1] = *ptr3 - *ptr2 + ptr2[BColSize];
			ptr3++;
			ptr2++;
		}
	}
}

__inline void projDCBySAT(GCKSetup *setup, Matrix *dcProj, Matrix *SATProj, int32 height, int32 width, u_int16 maxRows, u_int16 maxCols) {
	int32 *ptr2, *ptr3;
	int BRowSize = BLOCK_SIZE_IMG;
	int BColSize = BLOCK_SIZE_IMG;
	int32 pos1, pos2, pos3;
	u_int16 RLoc, CLoc;
//	u_int16 maxCols = setup->ImgProj_Width+BLOCK_SIZE_IMG-width;
//	u_int16 maxRows = setup->ImgProj_Height+BLOCK_SIZE_IMG-height;//ImgProj_Height =result->Img_Height_With_Boundary-BLOCK_SIZE_IMG+1;

	memset(&matVal(dcProj,0,0), 0, sizeof(int32)*maxCols);
	pos1 = &matVal(SATProj,height,0) - &matVal(SATProj,0,0);
	pos2 = &matVal(SATProj,0,width) - &matVal(SATProj,0,0);
	pos3 = &matVal(SATProj,height,width) - &matVal(SATProj,0,0);
//	dcProj->rows = maxRows;
//	dcProj->cols = maxCols;
	for (RLoc = 1; RLoc < maxRows; RLoc++)
	{
		ptr2 = &matVal(SATProj,RLoc-1,0);
		ptr3 = &matVal(dcProj,RLoc,0);
		*ptr3 = ptr2[pos1] - *ptr2;
		ptr3++;
		for (CLoc=1; CLoc<maxCols; CLoc++)
		{
			*ptr3 = *ptr2 - ptr2[pos1] - ptr2[pos2] + ptr2[pos3];
			ptr2++;
			ptr3++;
		}
	}
}

__inline void HaarFromDC(Matrix *HaarProj, Matrix *dcProj, int32 height, int32 width, int32 FlagVertical, u_int16 maxRows, u_int16 maxCols) {
	int32 *ptr2, *ptr3;
//	int BRowSize = BLOCK_SIZE_IMG;
//	int BColSize = BLOCK_SIZE_IMG;
	int32 pos1, pos2, pos3;
	u_int16 RLoc, CLoc;
//	Matrix *HaarProj = setup->prevImageProj[projNum];
//	u_int16 maxCols = setup->ImgProj_Width+BLOCK_SIZE_IMG-width;
//	u_int16 maxRows = setup->ImgProj_Height+BLOCK_SIZE_IMG-height;//ImgProj_Height =result->Img_Height_With_Boundary-BLOCK_SIZE_IMG+1;
//	HaarProj->rows = maxRows;
//	HaarProj->cols = maxCols;

	memset(&matVal(HaarProj,0,0), 0, sizeof(int32)*maxCols);
	pos1 = &matVal(HaarProj,height,0) - &matVal(HaarProj,0,0);
	for (RLoc = 1; RLoc < maxRows; RLoc++)
	{
		ptr2 = &matVal(dcProj,RLoc,0);
		ptr3 = &matVal(HaarProj,RLoc,0);
//		*ptr3 =  *ptr2 - ptr2[pos1];
//		ptr3++;
		for (CLoc=0; CLoc<maxCols; CLoc++)
		{
			*ptr3 = *ptr2 - ptr2[pos1];
			ptr2++;
			ptr3++;
		}
	}
}


__inline void projDCBySATBy2(Matrix *dcProj, Matrix *SATProj, int32 height, int32 width, u_int16 maxRows, u_int16 maxCols) {
	int32 *ptr2, *ptr3;
	int BRowSize = BLOCK_SIZE_IMG;
	int BColSize = BLOCK_SIZE_IMG;
	int32 pos1, pos2, pos3;
	u_int16 RLoc, CLoc;
//	u_int16 maxCols = setup->ImgProj_Width+BLOCK_SIZE_IMG-width;
//	u_int16 maxRows = setup->ImgProj_Height+BLOCK_SIZE_IMG-height;//ImgProj_Height =result->Img_Height_With_Boundary-BLOCK_SIZE_IMG+1;

	memset(&matVal(dcProj,0,0), 0, sizeof(int32)*maxCols);
	pos1 = &matVal(SATProj,height,0) - &matVal(SATProj,0,0);
	pos2 = &matVal(SATProj,0,width) - &matVal(SATProj,0,0);
	pos3 = &matVal(SATProj,height,width) - &matVal(SATProj,0,0);
//	dcProj->rows = maxRows;
//	dcProj->cols = maxCols;
	for (RLoc = 1; RLoc < maxRows; RLoc++)
	{
		ptr2 = &matVal(SATProj,RLoc-1,0);
		ptr3 = &matVal(dcProj,RLoc,0);
		*ptr3 = ptr2[pos1] - *ptr2;
		ptr3++;
		for (CLoc=1; CLoc<maxCols; CLoc++)
		{
			*ptr3 = (*ptr2 - ptr2[pos1] - ptr2[pos2] + ptr2[pos3])<<1;
			ptr2++;
			ptr3++;
		}
	}
}

__inline void projWHDC_Pattern(GCKSetup *setup, Image *image, Matrix *dcProj, Matrix *tmpProj) {

	u_int8 *ptr1; 
	int32 *ptr2;
	u_int16 col, row;
	int32 sum;

	u_int16 RLoc, CLoc;
	u_int16 maxCols = setup->Pat_Width_With_Boundary-setup->Block_size_pat+1;
	u_int16 maxRows = setup->Pat_Height_With_Boundary-setup->Block_size_pat+1;

	for (CLoc=0; CLoc<setup->Pat_Width_With_Boundary; CLoc++)  {
		ptr1 = &imVal(image, 0, CLoc);
		row = setup->Block_size_pat;
		sum = 0;

		while (row--) {
			sum += *ptr1;
			ptr1 += setup->Pat_Width_With_Boundary;
		}
		matVal(tmpProj,0,CLoc) = sum;

		for (RLoc=1; RLoc<maxRows; RLoc++)
			matVal(tmpProj,RLoc,CLoc) =
					matVal(tmpProj,RLoc-1,CLoc) - imVal(image,RLoc-1,CLoc) + imVal(image,RLoc+setup->Block_size_pat-1,CLoc);
	}
	
 	for (RLoc=0; RLoc<maxRows;RLoc++)  {
		ptr2 = &imVal(tmpProj, RLoc, 0);
		col = setup->Block_size_pat;
		sum = 0;

		while (col--) 
			sum += *(ptr2++);
		matVal(dcProj,RLoc,0) = sum;

		for (CLoc=1; CLoc<maxCols; CLoc++)
			matVal(dcProj,RLoc,CLoc) =
				matVal(dcProj,RLoc,CLoc-1) - matVal(tmpProj,RLoc,CLoc-1) + matVal(tmpProj,RLoc,CLoc+setup->Block_size_pat-1);
	}
}

/******************************************************************************
 * Calculates the offset and sign for GCK projection.                         *
 ******************************************************************************/                                              
 __inline void calcGCKOffset(int32 *offset, int32 *sign, Matrix *basesVectors, int32 curVecNum, int32 prevVecNum) {

	 u_int16 i;

	 for (i=0; i<matRows(basesVectors); i++)
		 if (matVal(basesVectors, curVecNum, i) != matVal(basesVectors, prevVecNum, i))
			 break;

     *offset = i;
	 *sign = -matVal(basesVectors, prevVecNum, i);

	 return;
 }


/*******************************************************************************
 * Calculates the current projection of the image based on previous projection *
 * by rows using GCK (2 operations per pixel).								   *
 ******************************************************************************/ 
__inline void singleWHProjByRow(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign) {

	u_int16 row, col;
	u_int16 maxCols, maxRows;
	u_int16 rows = currentProj->rows;
	u_int16 leftBoundarySize = (u_int16)(sizeof(int32)*offset);
	int32 *currentProjPtr, *prevProjPtr;
	int strideOffset, stride;
	int32 Cols = setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1;
//	int tmp;

	maxCols = (u_int16)(setup->ImgProj_Width);
	maxRows = (u_int16)(setup->ImgProj_Height-offset+setup->ProjExtraH);

	// fill boundary with zeros
	memset(currentProj->cellValues, 0, sizeof(int32)*offset*currentProj->cols);
	for (row=0; row<rows; row++)
		memset(&matVal(currentProj,row,0), 0, leftBoundarySize);

	// calculate non-boundary with 2 operations per pixel
	strideOffset = &matVal(currentProj,offset,0) - &matVal(currentProj,0,0);
	stride = &matVal(currentProj,1,0) - &matVal(currentProj,0,0);
	currentProjPtr = &matVal(currentProj,0,0);
	prevProjPtr = &matVal(prevProj,0,0);
	if (sign == 1)
		for (col=0; col < maxCols; col++)
		{
//			currentProjPtr = &matVal(currentProj,0,col);
//			prevProjPtr1 = &matVal(prevProj,0,col);
			for (row=0; row < maxRows; row++)
			{
/*				matVal(currentProj,row+offset,col) =
                   matVal(currentProj,row,col) - matVal(prevProj,row+offset,col) - matVal(prevProj,row,col);*/
//				currentProjPtr[strideOffset] = *currentProjPtr - prevProjPtr1[strideOffset] - *prevProjPtr1;
//				currentProjPtr+=stride;
//				prevProjPtr1+=stride;
				currentProjPtr[(row+offset)*Cols+col] 
					= currentProjPtr[(row)*Cols+col] - prevProjPtr[(row)*Cols+col] - prevProjPtr[(row+offset)*Cols+col];
			}
		}
	else
		for (col=0; col < maxCols; col++)
		{
//			currentProjPtr = &matVal(currentProj,0,col);
//			prevProjPtr1 = &matVal(prevProj,0,col);
			for (row=0; row < maxRows; row++)
			{
/*                matVal(currentProj,row+offset,col) =
					-matVal(currentProj,row,col) + matVal(prevProj,row,col) - matVal(prevProj,row+offset,col);*/
				currentProjPtr[(row+offset)*Cols+col] 
					= prevProjPtr[(row)*Cols+col] - currentProjPtr[(row)*Cols+col] - prevProjPtr[(row+offset)*Cols+col];
//				currentProjPtr[strideOffset] = *prevProjPtr1 - *currentProjPtr - prevProjPtr1[strideOffset];
//				currentProjPtr+=stride;
//				prevProjPtr1+=stride;
			}
		}
}

/*******************************************************************************
 * Calculates the current projection of the image based on previous projection *
 * by columns using GCK (2 operations per pixel).							   *
 ******************************************************************************/ 
__inline void singleWHProjByCol(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign) {

	u_int16 row, col;
	u_int16 maxCols, maxRows;
	u_int16 rows = currentProj->rows;
	u_int16 leftBoundarySize = (u_int16)(sizeof(int32)*offset);
	int32 *currentProjPtr, *prevProjPtr;
	int32 Cols = setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1;

	maxCols = (u_int16)(setup->ImgProj_Width-offset);
	maxRows = (u_int16)(setup->ImgProj_Height+setup->ProjExtraH);

	// fill boundary with zeros
	memset(currentProj->cellValues, 0, sizeof(int32)*(offset)*currentProj->cols);
	for (row=0; row<rows; row++)
		memset(&matVal(currentProj,row,0), 0, leftBoundarySize);
		
	currentProjPtr = &matVal(currentProj,0,0);
	prevProjPtr = &matVal(prevProj,0,0);
	// calculate non-boundary with 2 operations per pixel
	if (sign == 1)
		for (row=0; row < maxRows; row++)
		{
//			currentProjPtr = &matVal(currentProj,row,0);
//			prevProjPtr1 = &matVal(prevProj,row,0);
			for (col=0; col < maxCols; col++)
			{
				currentProjPtr[row*Cols+offset+col] = 
					currentProjPtr[row*Cols+col] - prevProjPtr[row*Cols+col] - prevProjPtr[row*Cols+offset+col];
//				currentProjPtr[offset] = *currentProjPtr - prevProjPtr1[offset] - *prevProjPtr1;
//				currentProjPtr++;
//				prevProjPtr1++;
/*				matVal(currentProj,row,col+offset) =
                   matVal(currentProj,row,col) - matVal(prevProj,row,col+offset) - matVal(prevProj,row,col);*/
			}
		}
	else
		for (row=0; row < maxRows; row++)
		{
//			currentProjPtr = &matVal(currentProj,row,0);
//			prevProjPtr1 = &matVal(prevProj,row,0);
			for (col=0; col < maxCols; col++)
			{
				currentProjPtr[row*Cols+offset+col] = 
					prevProjPtr[row*Cols+col] - currentProjPtr[row*Cols+col] - prevProjPtr[row*Cols+offset+col];
//				currentProjPtr[offset] = *prevProjPtr1 - *currentProjPtr - prevProjPtr1[offset];
//				currentProjPtr++;
//				prevProjPtr1++;
/*                matVal(currentProj,row,col+offset) =
					-matVal(currentProj,row,col) + matVal(prevProj,row,col) - matVal(prevProj,row,col+offset);*/
			}
		}
}

__inline void singleWHProjByRow_Pattern(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign) {

	u_int16 row, col;
	u_int16 maxCols, maxRows;
	u_int16 rows = currentProj->rows;
	u_int16 leftBoundarySize = (u_int16)(sizeof(int32)*offset);

	maxCols = (u_int16)(setup->Pat_Width_With_Boundary-setup->Block_size_pat+1);
	maxRows = (u_int16)(setup->Pat_Height_With_Boundary-setup->Block_size_pat+1-offset+setup->ProjExtraH);

	// fill boundary with zeros
	memset(&matVal(currentProj,0,0), 0, sizeof(int32)*offset*currentProj->cols);
	for (row=0; row<rows; row++)
		memset(&matVal(currentProj,row,0), 0, leftBoundarySize);

	// calculate non-boundary with 2 operations per pixel
	if (sign == 1)
		for (col=0; col < maxCols; col++)
			for (row=0; row < maxRows; row++)
				matVal(currentProj,row+offset,col) =
                    matVal(currentProj,row,col) - matVal(prevProj,row+offset,col) - matVal(prevProj,row,col);
	else
		for (col=0; col < maxCols; col++)
			for (row=0; row < maxRows; row++)
					matVal(currentProj,row+offset,col) =
						-matVal(currentProj,row,col) + matVal(prevProj,row,col) - matVal(prevProj,row+offset,col);
}


/*******************************************************************************
 * Calculates the current projection of the image based on previous projection *
 * by columns using GCK (2 operations per pixel).							   *
 ******************************************************************************/ 
__inline void singleWHProjByCol_Pattern(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign) {

	u_int16 row, col;
	u_int16 maxCols, maxRows;
	u_int16 rows = currentProj->rows;
	u_int16 leftBoundarySize = (u_int16)(sizeof(int32)*offset);

	maxCols = (u_int16)(setup->Pat_Width_With_Boundary-setup->Block_size_pat+1-offset);
	maxRows = (u_int16)(setup->Pat_Height_With_Boundary-setup->Block_size_pat+1+setup->ProjExtraH);

	// fill boundary with zeros
	memset(&matVal(currentProj,0,0), 0, sizeof(int32)*(offset)*currentProj->cols);
	for (row=0; row<rows; row++)
		memset(&matVal(currentProj,row,0), 0, leftBoundarySize);
		
	// calculate non-boundary with 2 operations per pixel
	if (sign == 1)
		for (row=0; row < maxRows; row++)
			for (col=0; col < maxCols; col++)
				matVal(currentProj,row,col+offset) =
                    matVal(currentProj,row,col) - matVal(prevProj,row,col+offset) - matVal(prevProj,row,col);
	else
		for (row=0; row < maxRows; row++)
			for (col=0; col < maxCols; col++)
                matVal(currentProj,row,col+offset) =
					-matVal(currentProj,row,col) + matVal(prevProj,row,col) - matVal(prevProj,row,col+offset);
}


__inline void projDiffWHDC(GCKSetup *setup, Diff_Image *image, Matrix *dcProj, Matrix *tmpProj, int BRowSize, int BColSize) {


	int16 *ptr1; 
	int32 *ptr2, *ptr3;
	u_int16 col;
	int32 sum;

	u_int16 RLoc, CLoc;
	u_int16 maxCols = setup->ImgProj_Width;
	u_int16 maxRows = setup->ImgProj_Height;
	int stridePrev, strideCur;

	memset(&matVal(tmpProj,0,0), 0, sizeof(int32)*setup->Img_Width_With_Boundary);
	for (RLoc=0; RLoc<BRowSize; RLoc++)
	{
		ptr1 = &imVal(image, 0, 0);
		ptr2 = &matVal(tmpProj,RLoc,0);
		CLoc = setup->Img_Width_With_Boundary;
		while(CLoc--)
			*(ptr2++) += *(ptr1++);
	}


	for (RLoc=1; RLoc<maxRows; RLoc++)
	{
		ptr2 = &matVal(tmpProj,RLoc-1,0);
		strideCur = &matVal(tmpProj,RLoc,0) - &matVal(tmpProj,RLoc-1,0);
		ptr1 = &imVal(image,RLoc-1,0);
		stridePrev = &matVal(image,RLoc+BRowSize-1,0) - &matVal(image,RLoc-1,0);
		for (CLoc=0; CLoc<setup->Img_Width_With_Boundary; CLoc++)  
		{
			ptr2[strideCur] = *ptr2 - *ptr1 + ptr1[stridePrev];
			ptr2++;
			ptr1++;
		}
	}
	
 	for (RLoc=0; RLoc<maxRows;RLoc++)  {
		ptr2 = &imVal(tmpProj, RLoc, 0);
		col = BColSize;
		sum = 0;

		while (col--) 
			sum += *(ptr2++);
		matVal(dcProj,RLoc,0) = sum;

		ptr2 = &matVal(tmpProj,RLoc,0);
		ptr3 = &matVal(dcProj,RLoc,0);
		for (CLoc=1; CLoc<maxCols; CLoc++)
		{
			ptr3[1] = *ptr3 - *ptr2 + ptr2[BColSize];
			ptr3++;
			ptr2++;
		}
	}
}

/******************************************************************************
 * Compute x(i,j)-x(i+k,j)											          *
 *										                                      *
 ******************************************************************************/
__inline void CalcImageDiff(GCKSetup *setup, Image *image, Diff_Image *diff_image)
{
	u_int32 i, j;
	u_int8 *Souce_ptr;
	int16 *diff_ptr;
	Souce_ptr = &imVal(image, 0, 0);
	diff_ptr = &imVal(diff_image, 0, 0);
	for (i = 0; i < setup->ImgProj_Height; i++)
		for (j = 0; j < setup->Img_Width_With_Boundary; j++)
		{
			*(diff_ptr)=*(Souce_ptr)-Souce_ptr[setup->Img_Width_With_Boundary*BLOCK_SIZE_IMG];
			Souce_ptr++;
			diff_ptr++;
		}
}

__inline void CalcImageDiff2(GCKSetup *setup, Image *image, Diff_Image *diff_image)
{
	u_int32 i, j;
	u_int8 *Src_ptr;
	int16 *diff_ptr;
//	int32 diff1;
	Src_ptr = &imVal(image, 0, 0);
	diff_ptr = &imVal(diff_image, 0, 0);
	for (i = 0; i < setup->Img_Height_With_Boundary; i++)
	{
/*		Src_ptr = &imVal(image, i, 0);
		diff_ptr = &imVal(diff_image, i, 0);*/
		for (j = 0; j < setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG; j++)
		{
			*(diff_ptr)=*(Src_ptr)-Src_ptr[BLOCK_SIZE_IMG];
			Src_ptr++;
			diff_ptr++;
		}
		Src_ptr += BLOCK_SIZE_IMG;
		diff_ptr += BLOCK_SIZE_IMG;
	}
}

/* This is easier to understand Wanli's Algorithm for computing four WHT values in one row
__inline void WHTInOneRow(Matrix **prevImageProj, Matrix * tProj, int startRow, int startCol, int numInGroup)
{
	static char ReferIdx[4] = {0, 2, 1, 3};
	Matrix *Proj0, *currentProj;
	Matrix *Proj1;
	Matrix *Proj2;
	Matrix *Proj3;
//	int tmp0, tmp1, tmp2, tmp3, tmp4;//for debugging
	int row, col, currentOrder;
	const int offset = BLOCK_SIZE_IMG>>2;
	u_int16 maxCols = setup->ImgProj_Width;
	u_int16 maxRows = setup->ImgProj_Height;
	int Order0, Order1, Order2, Order3;
	u_int16 leftBoundarySize = (u_int16)(sizeof(int32)*(BLOCK_SIZE_IMG>>1));
	int i;
	int32 sign = startCol & 4;
	Order0 = FreqOrder[startRow][startCol];
	Order1 = FreqOrder[startRow][startCol+1];
	Order2 = FreqOrder[startRow][startCol+2];
	Order3 = FreqOrder[startRow][startCol+3];
	Proj0 = prevImageProj[Order0];
	Proj1 = prevImageProj[Order1];
	Proj2 = prevImageProj[Order2];
	Proj3 = prevImageProj[Order3];
	maxCols = setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1;
	maxRows = setup->ImgProj_Height;
	maxCols -= ((BLOCK_SIZE_IMG>>1))-offset;
	for (i = numInGroup-1; i>=0; i--)
	{
		currentOrder = FreqOrder[startRow][startCol+i];
		currentProj = prevImageProj[currentOrder];
		memset(currentProj->cellValues, 0, sizeof(int32)*(BLOCK_SIZE_IMG>>1)*currentProj->cols);
		for (row=0; row<currentProj->rows; row++)
			memset(&matVal(currentProj,row,0), 0, leftBoundarySize);
	}
	if (0 == sign)
	{
		if (numInGroup>3)
			for (row=BLOCK_SIZE_IMG>>1; row < maxRows; row++)
				for (col=0; col < maxCols; col++)
					matVal(Proj3,row,col+offset) = matVal(tProj,row,col) - matVal(Proj3,row,col);
		for (row=BLOCK_SIZE_IMG>>1; row < maxRows; row++)
		{
			for (col=0; col < maxCols; col++)
			{
				matVal(Proj0,row,col+offset) = matVal(Proj0,row,col) - matVal(tProj,row,col);
				matVal(Proj1,row,col+offset) = matVal(tProj,row,col) - matVal(Proj2,row,col);
				matVal(Proj2,row,col+offset) = matVal(Proj1,row,col) - matVal(tProj,row,col);
			}
		}
	}
	else
	{
		if (numInGroup>3)
			for (row=BLOCK_SIZE_IMG>>1; row < maxRows; row++)
				for (col=0; col < maxCols; col++)
				matVal(Proj3,row,col+offset) =  matVal(Proj3,row,col) - matVal(tProj,row,col);
		for (row=BLOCK_SIZE_IMG>>1; row < maxRows; row++)
			for (col=0; col < maxCols; col++)
			{
				matVal(Proj0,row,col+offset) =  matVal(tProj,row,col) - matVal(Proj0,row,col);
				matVal(Proj1,row,col+offset) =  matVal(Proj2,row,col) - matVal(tProj,row,col);
				matVal(Proj2,row,col+offset) =  matVal(tProj,row,col) - matVal(Proj1,row,col);
			}
	}

}
*/

// Compute 4 projection values in a row by the algorithm proposed by Wanli etc.
__inline void WHTInOneRowG4(GCKSetup *setup, Matrix **prevImageProj, Matrix * tProj, int startRow, int startCol)
{
//	Matrix *Proj1, *Proj0;
//	Matrix *Proj2;
//	Matrix *Proj3;
//	register int32 *ptr0, *ptr1, *ptr2, *ptr3, *ptrt;
	register int32 *ptrt;
	 int32 *ptr[4];
//	register int32 *ptrPoff0, *ptrPoff1, *ptrPoff2, *ptrPoff3;
	register int col;
//	register int offset4, offset1, offset2, offset3, offset31;
	int row;
	const int offset = BLOCK_SIZE_IMG>>2;
	const int32 size1 = sizeof(int32)*(BLOCK_SIZE_IMG>>1);
//	int32 size2;
//	int i;
	int32 sign = startCol & 4;
	int32 maxCols;
	int32 maxRows;
	maxCols = setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1;
	maxRows = setup->ImgProj_Height;
	maxCols -= ((BLOCK_SIZE_IMG>>1));
	if (0 != sign)
	{
		ptr[0] = &matVal(prevImageProj[FreqOrder[startRow][startCol+3]], BLOCK_SIZE_IMG>>1,(BLOCK_SIZE_IMG>>1)-offset);
		ptr[1] = &matVal(prevImageProj[FreqOrder[startRow][startCol+2]], BLOCK_SIZE_IMG>>1,((BLOCK_SIZE_IMG>>1))-offset);
		ptr[2] = &matVal(prevImageProj[FreqOrder[startRow][startCol+1]], BLOCK_SIZE_IMG>>1,((BLOCK_SIZE_IMG>>1))-offset);
		ptr[3] = &matVal(prevImageProj[FreqOrder[startRow][startCol]], BLOCK_SIZE_IMG>>1,((BLOCK_SIZE_IMG>>1))-offset);
	}
	else
	{
		ptr[0] = &matVal(prevImageProj[FreqOrder[startRow][startCol]], BLOCK_SIZE_IMG>>1,((BLOCK_SIZE_IMG>>1))-offset);
		ptr[1] = &matVal(prevImageProj[FreqOrder[startRow][startCol+1]], BLOCK_SIZE_IMG>>1,((BLOCK_SIZE_IMG>>1))-offset);
		ptr[2] = &matVal(prevImageProj[FreqOrder[startRow][startCol+2]], BLOCK_SIZE_IMG>>1,((BLOCK_SIZE_IMG>>1))-offset);
		ptr[3] = &matVal(prevImageProj[FreqOrder[startRow][startCol+3]], BLOCK_SIZE_IMG>>1,((BLOCK_SIZE_IMG>>1))-offset);
	}
	ptrt = &matVal(tProj,BLOCK_SIZE_IMG>>1,((BLOCK_SIZE_IMG>>1))-offset);

	row = BLOCK_SIZE_IMG>>1;
	col = maxCols;	

//	maxCols -= offset;

	while (row<maxRows)
	{
		col = maxCols;	
		while (col--) {
			register int32 tmp0 = *(ptrt); //Obtain the t
			// Use the t to obtain four projection values using 1 add/sub per projection value
			ptr[0][offset] = *(ptr[0]) - tmp0;
			ptr[1][offset] = tmp0 - *(ptr[2]);
			ptr[2][offset] = *(ptr[1]) - tmp0;
			ptr[3][offset] = tmp0 - *(ptr[3]);
			ptrt++;
			ptr[0]++;
			ptr[1]++;
			ptr[2]++;
			ptr[3]++;
		} 
		ptr[0] += (BLOCK_SIZE_IMG>>1);
		ptr[1] += (BLOCK_SIZE_IMG>>1);
		ptr[2] += (BLOCK_SIZE_IMG>>1);
		ptr[3] += (BLOCK_SIZE_IMG>>1);
		ptrt += (BLOCK_SIZE_IMG>>1) ;
		col = maxCols;	
		row++;
	}
}

__inline void WHTInOneColG4(GCKSetup *setup, Matrix **prevImageProj, Matrix * tProj, int startRow, int startCol)
{//obtain 4 projection values in one column
//	Matrix *Proj1, *Proj0;
//	Matrix *Proj2;
//	Matrix *Proj3;
	register int32 *ptr0, *ptr1, *ptr2, *ptr3;
	register int32 *ptrt;
//	register int32 *ptrPoff0, *ptrPoff1, *ptrPoff2, *ptrPoff3;
	register int col;
//	register int offset4, offset1, offset2, offset3, offset31;
	int row;
	const int offset = BLOCK_SIZE_IMG>>2;
	const int32 size1 = sizeof(int32)*(BLOCK_SIZE_IMG>>1);
	int32 size2;
//	int i;
	int strideCur;
	int32 sign = startRow & 4;
	u_int16 maxCols;
	u_int16 maxRows;
	maxCols = setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1;
	strideCur = maxCols*offset;
	if (0 != sign)
	{
		ptr0 = &matVal(prevImageProj[FreqOrder[startRow+3][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
		ptr1 = &matVal(prevImageProj[FreqOrder[startRow+2][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
		ptr2 = &matVal(prevImageProj[FreqOrder[startRow+1][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
		ptr3 = &matVal(prevImageProj[FreqOrder[startRow][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
	}
	else
	{
		ptr0 = &matVal(prevImageProj[FreqOrder[startRow][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
		ptr1 = &matVal(prevImageProj[FreqOrder[startRow+1][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
		ptr2 = &matVal(prevImageProj[FreqOrder[startRow+2][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
		ptr3 = &matVal(prevImageProj[FreqOrder[startRow+3][startCol]], (BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);
	}
	size2 = sizeof(int32)*offset*maxCols;
/*	memset(ptr0, 0, size2);
	memset(ptr1, 0, size2);
	memset(ptr2, 0, size2);
	memset(ptr3, 0, size2);*/
	ptrt = &matVal(tProj,(BLOCK_SIZE_IMG>>1)-offset,BOUNDARY_SIZE_IMG);

	maxRows = setup->Img_Height_With_Boundary-setup->Block_size_pat+1-offset;

	row = (BLOCK_SIZE_IMG>>1)-offset;
	col = BOUNDARY_SIZE_IMG;	

	while (row<maxRows)
	{
		while (col<maxCols) {
			const int32 tmp0 = *(ptrt);
			ptr0[strideCur] = *(ptr0) - tmp0;
			ptr1[strideCur] = tmp0 - *ptr2;
			ptr2[strideCur] = *(ptr1) - tmp0;
			ptr3[strideCur] = tmp0 - *(ptr3);
			ptrt++;
			ptr0++;
			ptr1++;
			ptr2++;
			ptr3++;
			col++;
		} 
		ptr0 += BOUNDARY_SIZE_IMG;
		ptr1 += BOUNDARY_SIZE_IMG;
		ptr2 += BOUNDARY_SIZE_IMG;
		ptr3 += BOUNDARY_SIZE_IMG;
		ptrt += BOUNDARY_SIZE_IMG;
		col = BOUNDARY_SIZE_IMG;
		row++;
	}
}

float GetEnergy(Image *source)
{
	u_int16 row, col;
	u_int16 rows = source->rows;
	u_int16 cols = source->cols;
	float Energy=0;
	

	for (row=0; row<rows; row++) 
		for (col=0; col<cols; col++)
			Energy += imVal(source,row,col)*imVal(source,row,col);
	return Energy;

}



/******************************************************************************
 * Notifies the setup on the current image and projects it.					  *
 ******************************************************************************/
int  tot_time=0;
extern int32 FreqGroup[64][64];
//------------ Compute KHT for pattern  ------------
void setPatternKHT(GCKSetup *setup, Image **image) {
	int32 curBaseNum, PatIdx, PatStartIdx;
	int curProjValue;
	u_int32  prevBaseNum, byRow, curVecNum, prevVecNum;
	int32 sign, offset;
	
	PatIdx = 0;
	copyImageWithBoundary(image[PatIdx], setup->curImage, setup->Boundary_Size_Pat);
	PatStartIdx = PatIdx*(MAX_BASES+MAX_BASES/4);
	SatSum(setup->curImage->pixels, setup->Pat_Width_With_Boundary, setup->Pat_Height_With_Boundary, &matVal(setup->tmpProjPat,0,0));
	projDCBySAT(setup, setup->curImageProj[0], setup->tmpProjPat, BLOCK_SIZE_IMG, BLOCK_SIZE_IMG 
		,setup->Pat_Height_With_Boundary-BLOCK_SIZE_IMG+1, setup->Pat_Height_With_Boundary+BLOCK_SIZE_IMG-1);

	projDCBySATBy2(setup->curImageProj[MAX_BASES], setup->tmpProjPat, BLOCK_SIZE_IMG/4, BLOCK_SIZE_IMG 
		,setup->Pat_Height_With_Boundary-(BLOCK_SIZE_IMG/4)+1, setup->Pat_Height_With_Boundary+BLOCK_SIZE_IMG-1);
/*	projWHDC_Pattern(setup, setup->curImage, setup->curImageProj[0], setup->colsProj);*/
	curProjValue = matVal(setup->curImageProj[0], setup->Boundary_Size_Pat, setup->Boundary_Size_Pat);
	PatternWHTCoef[PatIdx][0] = curProjValue;
	
	// calculate the other projections
	curBaseNum = 1;
	calcGCKOffset(&offset, &sign, setup->baseVectors, 7, 0);
	setup->ProjExtraH = 0;
	while ( (curBaseNum < setup->Bases_Num) && (curBaseNum < 4) ) {

		prevBaseNum = matVal(setup->baseVectorsOrder, curBaseNum, 2);

		if (matVal(setup->baseVectorsOrder,curBaseNum,0) == matVal(setup->baseVectorsOrder,prevBaseNum,0)) {
			byRow = 0;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,1);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,1);
		}
		else  {
			byRow = 1;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,0);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,0);
		}

		calcGCKOffset(&offset, &sign, setup->baseVectors, curVecNum, prevVecNum);
	
		if (byRow)
			singleWHProjByRow_Pattern(setup, setup->curImageProj[prevBaseNum], setup->curImageProj[curBaseNum],
							  offset, sign);
		else
			singleWHProjByCol_Pattern(setup, setup->curImageProj[prevBaseNum], setup->curImageProj[curBaseNum],
							  offset, sign);
		curProjValue = matVal(setup->curImageProj[curBaseNum], setup->Boundary_Size_Pat, setup->Boundary_Size_Pat);
		PatternWHTCoef[PatIdx][curBaseNum] = curProjValue;
#if SHOW_MY_STATS
		printf("compute Proj. No. %d\n", curBaseNum);
#endif
		curBaseNum++;
	}
	setup->ProjExtraH = setup->Block_size_pat - setup->Block_size_pat/4;

	while (curBaseNum < setup->Bases_Num) {

		prevBaseNum = matVal(setup->baseVectorsOrder, curBaseNum, 2);
//		printf("prev1: %d\n", prevBaseNum);

		if (matVal(setup->baseVectorsOrder,curBaseNum,0) == matVal(setup->baseVectorsOrder,prevBaseNum,0)) {
			byRow = 0;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,1);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,1);
		}
		else  {
			byRow = 1;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,0);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,0);
		}

		//
		if (byRow)
		{
			curVecNum >>=2;
			prevVecNum >>=2;
		}

		calcGCKOffset(&offset, &sign, setup->baseVectors, curVecNum, prevVecNum);

		if (byRow)
			offset >>= 2;
		if ( (16 == curBaseNum) || (4 == curBaseNum) )
			prevBaseNum = MAX_BASES;
		if ( 64 == curBaseNum)
			prevBaseNum = 16;
//		printf("compute Proj. No. %d, prev: %d\n", curBaseNum, prevBaseNum);
	
		if (byRow)
			singleWHProjByRow_Pattern(setup, setup->curImageProj[prevBaseNum], setup->curImageProj[curBaseNum],
							  offset, sign);
		else
			singleWHProjByCol_Pattern(setup, setup->curImageProj[prevBaseNum], setup->curImageProj[curBaseNum],
							  offset, sign);
		curProjValue = matVal(setup->curImageProj[curBaseNum], setup->Boundary_Size_Pat, setup->Boundary_Size_Pat);
		PatternWHTCoef[PatIdx][curBaseNum] = curProjValue;
		curBaseNum++;
		if ( (curBaseNum&15) == 1)
			curBaseNum += 3;
		if ( (curBaseNum&15) == 7)
			curBaseNum += 9;
	}

	for (curBaseNum=0; curBaseNum < setup->Bases_Num; curBaseNum++)
	{
		curProjValue = matVal(setup->curImageProj[curBaseNum], setup->Boundary_Size_Pat, setup->Boundary_Size_Pat);
		PatternWHTCoef[PatIdx][curBaseNum] = curProjValue;
//		printf("Proj val: %d in Proj No.: %d\n", curBaseNum, curProjValue);
	}
	
}

void setPatternKHT8(GCKSetup *setup, Image **image) {
	int32 curBaseNum, PatIdx, PatStartIdx;
	int curProjValue;
	u_int32  prevBaseNum, byRow, curVecNum, prevVecNum;
	int32 sign, offset;
	float Engergy, ProjValueSqr;
	
#if SHOW_MY_STATS
		printf("KHT...\n\n");
#endif
	PatIdx = 0;
	copyImageWithBoundary(image[PatIdx], setup->curImage, setup->Boundary_Size_Pat);
	Engergy = GetEnergy(image[PatIdx]);
//	setup->EnergyPercent[0] = 0;
	PatStartIdx = PatIdx*(MAX_BASES+MAX_BASES/4);
	SatSum(setup->curImage->pixels, setup->Pat_Width_With_Boundary, setup->Pat_Height_With_Boundary, &matVal(setup->tmpProjPat,0,0));
	projDCBySAT(setup, setup->curImageProj[0], setup->tmpProjPat, BLOCK_SIZE_IMG, BLOCK_SIZE_IMG 
		,setup->Pat_Height_With_Boundary-BLOCK_SIZE_IMG+1, setup->Pat_Height_With_Boundary+BLOCK_SIZE_IMG-1);

/*	projWHDC_Pattern(setup, setup->curImage, setup->curImageProj[0], setup->colsProj);*/
	curProjValue = matVal(setup->curImageProj[0], setup->Boundary_Size_Pat, setup->Boundary_Size_Pat);
	PatternWHTCoef[PatIdx][0] = curProjValue;
	ProjValueSqr = curProjValue;
	setup->EnergyPercent[0] = ProjValueSqr*ProjValueSqr;
	
	// calculate the other projections
	curBaseNum = 1;
	calcGCKOffset(&offset, &sign, setup->baseVectors, 7, 0);
	setup->ProjExtraH = 0;
	while ( (curBaseNum < setup->Bases_Num) && (curBaseNum < 4) ) {

		prevBaseNum = matVal(setup->baseVectorsOrder, curBaseNum, 2);

		if (matVal(setup->baseVectorsOrder,curBaseNum,0) == matVal(setup->baseVectorsOrder,prevBaseNum,0)) {
			byRow = 0;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,1);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,1);
		}
		else  {
			byRow = 1;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,0);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,0);
		}

		calcGCKOffset(&offset, &sign, setup->baseVectors, curVecNum, prevVecNum);
	
		if (byRow)
			singleWHProjByRow_Pattern(setup, setup->curImageProj[prevBaseNum], setup->curImageProj[curBaseNum],
							  offset, sign);
		else
			singleWHProjByCol_Pattern(setup, setup->curImageProj[prevBaseNum], setup->curImageProj[curBaseNum],
							  offset, sign);
		curProjValue = matVal(setup->curImageProj[curBaseNum], setup->Boundary_Size_Pat, setup->Boundary_Size_Pat);
		PatternWHTCoef[PatIdx][curBaseNum] = curProjValue;
		ProjValueSqr = curProjValue;
		setup->EnergyPercent[curBaseNum] = ProjValueSqr*ProjValueSqr + setup->EnergyPercent[curBaseNum-1];
#if SHOW_MY_STATS
		printf("compute Proj. No. %d\n", curBaseNum);
#endif
		curBaseNum++;
	}

	projDCBySATBy2(setup->curImageProj[0], setup->tmpProjPat, BLOCK_SIZE_IMG/8, BLOCK_SIZE_IMG 
		,setup->Pat_Height_With_Boundary-(BLOCK_SIZE_IMG/8)+1, setup->Pat_Height_With_Boundary+BLOCK_SIZE_IMG-1);
	setup->ProjExtraH = setup->Block_size_pat - setup->Block_size_pat/8;

	while (curBaseNum < setup->Bases_Num) {
#if SHOW_MY_STATS
		printf("Cur: %d  ", curBaseNum);
#endif

		prevBaseNum = matVal(setup->baseVectorsOrder, curBaseNum, 2);
#if SHOW_MY_STATS
		printf("prev1: %d\n", prevBaseNum);
#endif

		if (matVal(setup->baseVectorsOrder,curBaseNum,0) == matVal(setup->baseVectorsOrder,prevBaseNum,0)) {
			byRow = 0;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,1);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,1);
		}
		else  {
			byRow = 1;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,0);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,0);
		}

		//
		if (byRow)
		{
			curVecNum >>=3;
			prevVecNum >>=3;
		}

		calcGCKOffset(&offset, &sign, setup->baseVectors, curVecNum, prevVecNum);

		if (byRow)
			offset >>= 3;
		if ( (64 == curBaseNum) || (4 == curBaseNum) )
			prevBaseNum = 0;
#if SHOW_MY_STATS
		printf("compute Proj. No. %d, prev: %d\n", curBaseNum, prevBaseNum);
#endif
	
		if (byRow)
			singleWHProjByRow_Pattern(setup, setup->curImageProj[prevBaseNum], setup->curImageProj[curBaseNum],
							  offset, sign);
		else
			singleWHProjByCol_Pattern(setup, setup->curImageProj[prevBaseNum], setup->curImageProj[curBaseNum],
							  offset, sign);
#if SHOW_MY_STATS
		printf("singleWHProj finished \n  ", curBaseNum);
#endif
		curProjValue = matVal(setup->curImageProj[curBaseNum], setup->Boundary_Size_Pat, setup->Boundary_Size_Pat);
#if SHOW_MY_STATS
		printf("curProjValue: %d \n  ", curProjValue);
#endif
		PatternWHTCoef[PatIdx][curBaseNum] = curProjValue;
		curBaseNum++;
		if ( (curBaseNum&15) == 1)
			curBaseNum += 3;
		if ( (curBaseNum&15) == 7)
			curBaseNum += 25;
	}

	for (curBaseNum=4; curBaseNum < setup->Bases_Num; curBaseNum++)
	{
		curProjValue = matVal(setup->curImageProj[curBaseNum], setup->Boundary_Size_Pat, setup->Boundary_Size_Pat);
		PatternWHTCoef[PatIdx][curBaseNum] = curProjValue;
		ProjValueSqr = curProjValue;
//		setup->EnergyPercent += ProjValueSqr*ProjValueSqr;
		setup->EnergyPercent[curBaseNum] = ProjValueSqr*ProjValueSqr + setup->EnergyPercent[curBaseNum-1];
		setup->EnergyPercent[curBaseNum-1] /= Engergy*BLOCK_SIZE_IMG*BLOCK_SIZE_IMG;
//		printf("Proj val: %d in Proj No.: %d\n", curBaseNum, curProjValue);
	}
//	setup->EnergyPercent = setup->EnergyPercent/Engergy/BLOCK_SIZE_IMG/BLOCK_SIZE_IMG;
	setup->EnergyPercent[curBaseNum-1] /= Engergy*BLOCK_SIZE_IMG*BLOCK_SIZE_IMG;
	for (curBaseNum=0; curBaseNum < 4; curBaseNum++)
	{
		int val1, val2;
		val1 = matVal(setup->curImageProj[0], setup->Boundary_Size_Pat+2*curBaseNum*BLOCK_SIZE_IMG/8, setup->Boundary_Size_Pat);
		val2 = matVal(setup->curImageProj[0], setup->Boundary_Size_Pat+(2*curBaseNum+1)*BLOCK_SIZE_IMG/8, setup->Boundary_Size_Pat);
		curProjValue = val1 - val2;
		PatternWHTCoef[PatIdx][16+curBaseNum] = curProjValue;
	}
}

//------------ Compute GCK for pattern  ------------
void setPatternGCK(GCKSetup *setup, Image **image) {
	int32 curBaseNum, PatIdx, PatStartIdx;
	int curProjValue;
	u_int32  prevBaseNum, byRow, curVecNum, prevVecNum;
	int32 sign, offset;
	float Engergy, ProjValueSqr;
	
	PatIdx = 0;
	copyImageWithBoundary(image[PatIdx], setup->curImage, setup->Boundary_Size_Pat);
	Engergy = GetEnergy(image[PatIdx]);
//	setup->EnergyPercent = 0;

	PatStartIdx = PatIdx*(MAX_BASES+MAX_BASES/4);
	projWHDC_Pattern(setup, setup->curImage, setup->curImageProj[0], setup->colsProj);
	curProjValue = matVal(setup->curImageProj[0], setup->Boundary_Size_Pat, setup->Boundary_Size_Pat);
	PatternWHTCoef[PatIdx][0] = curProjValue;
	ProjValueSqr = curProjValue;
	setup->EnergyPercent[0] = ProjValueSqr*ProjValueSqr;
	
	// calculate the other projections
	curBaseNum = 1;
	while (curBaseNum < setup->Bases_Num) {

		prevBaseNum = matVal(setup->baseVectorsOrder, curBaseNum, 2);

		if (matVal(setup->baseVectorsOrder,curBaseNum,0) == matVal(setup->baseVectorsOrder,prevBaseNum,0)) {
			byRow = 0;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,1);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,1);
		}
		else  {
			byRow = 1;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,0);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,0);
		}

		calcGCKOffset(&offset, &sign, setup->baseVectors, curVecNum, prevVecNum);
		offset >>= (SCALE-1);
	
		if (byRow)
			singleWHProjByRow_Pattern(setup, setup->curImageProj[prevBaseNum], setup->curImageProj[curBaseNum],
							  offset, sign);
		else
			singleWHProjByCol_Pattern(setup, setup->curImageProj[prevBaseNum], setup->curImageProj[curBaseNum],
							  offset, sign);
		curProjValue = matVal(setup->curImageProj[curBaseNum], setup->Boundary_Size_Pat, setup->Boundary_Size_Pat);
		PatternWHTCoef[PatIdx][curBaseNum] = curProjValue;
		ProjValueSqr = curProjValue;
		setup->EnergyPercent[curBaseNum] = ProjValueSqr*ProjValueSqr + setup->EnergyPercent[curBaseNum-1];
		setup->EnergyPercent[curBaseNum-1] /= Engergy*BLOCK_SIZE_IMG*BLOCK_SIZE_IMG;
//		setup->EnergyPercent += ProjValueSqr*ProjValueSqr;
		curBaseNum++;
	}
	setup->EnergyPercent[curBaseNum-1] /= Engergy*BLOCK_SIZE_IMG*BLOCK_SIZE_IMG;
//	setup->EnergyPercent = setup->EnergyPercent/Engergy/BLOCK_SIZE_IMG/BLOCK_SIZE_IMG;
	
}

void setIncImagePureGCK(GCKSetup *setup, int BaseStart, int BaseEnd) {

	int32 curBaseNum, prevBaseNum, byRow, curVecNum, prevVecNum, offset;
	int32 sign;
	//------------ For image  ------------
	// calculate the projections other than dc
//	projWHDC(setup, setup->prevImage, setup->prevImageProj[0], setup->colsProj);
	curBaseNum = BaseStart;
	while (curBaseNum < BaseEnd) 
	{

		prevBaseNum = matVal(setup->baseVectorsOrder, curBaseNum, 2);

		if (matVal(setup->baseVectorsOrder,curBaseNum,0) == matVal(setup->baseVectorsOrder,prevBaseNum,0)) {
			byRow = 0;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,1);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,1);
		}
		else  {
			byRow = 1;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,0);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,0);
		}

		calcGCKOffset(&offset, &sign, setup->baseVectors, curVecNum, prevVecNum);
		if (byRow)
			singleWHProjByRow(setup, setup->prevImageProj[prevBaseNum], setup->prevImageProj[curBaseNum],
							  offset, sign);
		else
			singleWHProjByCol(setup, setup->prevImageProj[prevBaseNum], setup->prevImageProj[curBaseNum],
							  offset, sign);
			curBaseNum++;
	}
}

void setIncImageGCKOY(GCKSetup *setup, int BaseStart, int BaseEnd) {

	int32 offset;
	int32 sign;
	int col, row;
	int ColBy4;
	int curIdx, prevIdx;
	row = matVal(setup->baseVectorsOrder,BaseStart,0);
	col = matVal(setup->baseVectorsOrder,BaseStart,1)>>2;
	ColBy4 = col<<2;
	curIdx = MAX_BASES+row+col;
	prevIdx = curIdx-1;
	// Use GCK to obtain t
	if ( (row+col) != 0)
	{
		if ( row != 0)
		{
			offset = MtxOffset[row];
			sign = (matVal(setup->baseVectors, row-1, offset) ==  -1);
			singleWHProjByRow(setup, setup->prevImageProj[prevIdx], setup->prevImageProj[curIdx],
				offset, sign);
		}
		else 
		{
			offset = MtxOffset[col];
			sign = (matVal(setup->baseVectors, col-1, offset) ==  -1);	
			offset = offset>>2;			
			singleWHProjByCol(setup, setup->prevImageProj[prevIdx], setup->prevImageProj[curIdx],
				offset, sign);
		}
	}//end of if ( (row1+col1) != 0)
	// Use t to obtain 4 projection values
	WHTInOneRowG4(setup, setup->prevImageProj, setup->prevImageProj[curIdx], row, ColBy4);
}

__inline void KHTByRow(GCKSetup *setup, Matrix * tProj, int startRow, int startCol, int numInGroup, int offset)
{
//	static char ReferIdx[4] = {0, 2, 1, 3};
	Matrix *Proj0, *currentProj;
	Matrix *Proj1;
	Matrix *Proj2;
	Matrix *Proj3;
	int32 *p0, *p1, *p2, *p3;
//	int tmp0, tmp1, tmp2, tmp3, tmp4;//for debugging
	int row, col, currentOrder;
	u_int16 maxCols = setup->ImgProj_Width;
	u_int16 maxRows = setup->ImgProj_Height+setup->ProjExtraH;
	int Order0, Order1, Order2, Order3;
	u_int16 leftBoundarySize = (u_int16)(sizeof(int32)*offset);
	int i, Delta;
	int sign = startCol & 4;
	Order0 = FreqOrder[startRow][startCol];
	Order1 = FreqOrder[startRow][startCol+1];
	Order2 = FreqOrder[startRow][startCol+2];
	Order3 = FreqOrder[startRow][startCol+3];
		Proj0 = setup->prevImageProj[Order0];
		Proj1 = setup->prevImageProj[Order1];
		Proj2 = setup->prevImageProj[Order2];
		Proj3 = setup->prevImageProj[Order3];
	for (i = numInGroup-1; i>0; i--)
	{
		currentOrder = FreqOrder[startRow][startCol+i];
		currentProj = setup->prevImageProj[currentOrder];
		memset(&matVal(currentProj,0,0), 0, sizeof(int32)*offset*currentProj->cols);
		for (row=0; row<currentProj->rows; row++)
			memset(&matVal(currentProj,row,0), 0, leftBoundarySize);
	}
	if ( 0 == sign)
	{
		if (numInGroup > 3)
		{
			for (row=0; row < maxRows; row++)
			{
				p0 = &matVal(Proj0,row,0);
				p1 = &matVal(Proj1,row,0);
				p2 = &matVal(Proj2,row,0);
				p3 = &matVal(Proj3,row,0);
				for (col=0; col < maxCols-offset; col++)
				{
					Delta = *p0 - p0[offset];
					p1[offset] = Delta - *p2;
					p2[offset] = *p1 - Delta;
					p3[offset] = Delta - *p3;
					p0++;
					p1++;
					p2++;
					p3++;
				}
			}
		}
		else
		{
			for (row=0; row < maxRows; row++)
			{
				p0 = &matVal(Proj0,row,0);
				p1 = &matVal(Proj1,row,0);
				p2 = &matVal(Proj2,row,0);
				for (col=0; col < maxCols-offset; col++)
				{
					Delta = *p0 - p0[offset];
					p1[offset] = Delta - *p2;
					p2[offset] = *p1 - Delta;
					p0++;
					p1++;
					p2++;
				}
			}
		}
	}
	else
	{
		if (numInGroup > 3)
			for (row=0; row < maxRows; row++)
			{
				p0 = &matVal(Proj0,row,0);
				p1 = &matVal(Proj1,row,0);
				p2 = &matVal(Proj2,row,0);
				p3 = &matVal(Proj3,row,0);
				for (col=0; col < maxCols-offset; col++)
				{
					Delta = *p0 + p0[offset];
					p1[offset] = *p2 - Delta;
					p2[offset] = Delta - *p1;
					p3[offset] = *p3 -  Delta;
					p0++;
					p1++;
					p2++;
					p3++;
				}
			}
		if (numInGroup <= 3)
			for (row=0; row < maxRows; row++)
			{
				p0 = &matVal(Proj0,row,0);
				p1 = &matVal(Proj1,row,0);
				p2 = &matVal(Proj2,row,0);
				for (col=0; col < maxCols-offset; col++)
				{
					Delta = *p0 + p0[offset];
					p1[offset] = *p2 - Delta;
					p2[offset] = Delta - *p1;
				}
					p0++;
					p1++;
					p2++;
			}
	}

}

//static char ReferIdx[4] = {0, 2, 1, 3};
__inline void KHTByRow4(GCKSetup *setup, Matrix * tProj, int startRow, int startCol, int offset)
{
	int32 *p0, *p1, *p2, *p3;
	int row, col, currentOrder;
	u_int16 maxCols = setup->ImgProj_Width;
	u_int16 maxRows = setup->ImgProj_Height+setup->ProjExtraH;
	int Order0, Order1, Order2, Order3;
	int32 Cols = setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1;
//	int i, Delta;
	int sign = startCol & 4;
	p0 = &matVal(setup->prevImageProj[FreqOrder[startRow][startCol]],0,0);
	p1 = &matVal(setup->prevImageProj[FreqOrder[startRow][startCol+1]],0,0);
	p2 = &matVal(setup->prevImageProj[FreqOrder[startRow][startCol+2]],0,0);
	p3 = &matVal(setup->prevImageProj[FreqOrder[startRow][startCol+3]],0,0);
	maxCols-= offset;
	if (0 == sign)
	{
			for (row=0; row < maxRows; row++)
			{
				for (col=0; col < maxCols; col++)
				{
					int pos1 = (row)*Cols+col;
//					int pos2 = pos1+offset;
					int Delta = p0[pos1] - p0[pos1+offset];
					p1[pos1+offset] = Delta - p2[pos1];
					p2[pos1+offset] = p1[pos1] - Delta;
					p3[pos1+offset] = Delta - p3[pos1];
				}
			}
	}
	else
	{
			for (row=0; row < maxRows; row++)
			{
				for (col=0; col < maxCols; col++)
				{
					int pos1 = (row)*Cols+col;
//					int pos2 = pos1+offset;
					int Delta = p0[pos1] + p0[pos1+offset];
					p1[pos1+offset] = p2[pos1] - Delta;
					p2[pos1+offset] = Delta - p1[pos1];
					p3[pos1+offset] = p3[pos1] -  Delta;
				}
			}
	}

}

__inline void KHTByCol4(GCKSetup *setup, Matrix * tProj, int startRow, int startCol, int offset)
{
	int32 *p0, *p1, *p2, *p3;
	int row, col, currentOrder, strideOffset;
	u_int16 maxCols = setup->ImgProj_Width;
	u_int16 maxRows = setup->ImgProj_Height+setup->ProjExtraH;
//	int i, Delta;
	int sign = startRow & 4;
	int32 Cols = setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1;
	strideOffset = offset;
	p0 = &matVal(setup->prevImageProj[FreqOrder[startRow][startCol]],0,0);
	p1 = &matVal(setup->prevImageProj[FreqOrder[startRow+1][startCol]],0,0);
	p2 = &matVal(setup->prevImageProj[FreqOrder[startRow+2][startCol]],0,0);
	p3 = &matVal(setup->prevImageProj[FreqOrder[startRow+3][startCol]],0,0);
	if (0 == sign)
	{
			for (row=0; row < maxRows; row++)
			{
				for (col=0; col < maxCols; col++)
				{
					int pos1 = (row)*Cols+col;
//					int pos2 = pos1+strideOffset;
					int Delta = p0[pos1] - p0[pos1+strideOffset];
//					if ((row==40)&&(col==48))
//						printf("Stop here!\n");
					p1[pos1+strideOffset] = Delta - p2[pos1];
					p2[pos1+strideOffset] = p1[pos1] - Delta;
					p3[pos1+strideOffset] = Delta - p3[pos1];
				}
			}
	}
	else
	{
			for (row=0; row < maxRows; row++)
			{
				for (col=0; col < maxCols; col++)
				{
					int pos1 = (row)*Cols+col;
//					int pos2 = pos1+strideOffset;
					int Delta = p0[pos1] + p0[pos1+strideOffset];
					p1[pos1+strideOffset] = p2[pos1] - Delta;
					p2[pos1+strideOffset] = Delta - p1[pos1];
					p3[pos1+strideOffset] = p3[pos1] -  Delta;
				}
			}
	}



}

__inline void KHTByCol(GCKSetup *setup, Matrix * tProj, int startRow, int startCol, int numInGroup, int offset)
{
//	static char ReferIdx[4] = {0, 2, 1, 3};
	Matrix *Proj0, *currentProj;
	Matrix *Proj1;
	Matrix *Proj2;
	Matrix *Proj3;
	int32 *p0, *p1, *p2, *p3;
//	int tmp0, tmp1, tmp2, tmp3, tmp4;//for debugging
	int row, col, currentOrder, strideOffset;
	u_int16 maxCols = setup->ImgProj_Width;
	u_int16 maxRows = setup->ImgProj_Height+setup->ProjExtraH;
	int Order0, Order1, Order2, Order3;
	u_int16 leftBoundarySize = (u_int16)(sizeof(int32)*offset);
	int i, Delta;
	int sign = startRow & 4;
	Order0 = FreqOrder[startRow][startCol];
	Order1 = FreqOrder[startRow+1][startCol];
	Order2 = FreqOrder[startRow+2][startCol];
	Order3 = FreqOrder[startRow+3][startCol];
		Proj0 = setup->prevImageProj[Order0];
		Proj1 = setup->prevImageProj[Order1];
		Proj2 = setup->prevImageProj[Order2];
		Proj3 = setup->prevImageProj[Order3];
	for (i = numInGroup-1; i>0; i--)
	{
		currentOrder = FreqOrder[startRow][startCol+i];
		currentProj = setup->prevImageProj[currentOrder];
		memset(&matVal(currentProj,0,0), 0, sizeof(int32)*offset*currentProj->cols);
		for (row=0; row<currentProj->rows; row++)
			memset(&matVal(currentProj,row,0), 0, leftBoundarySize);
	}
	strideOffset = &matVal(Proj0,offset,0) - &matVal(Proj0,0,0);
	if ( 0 == sign)
	{
		if (numInGroup > 3)
		{
			for (row=0; row < maxRows-offset; row++)
			{
				p0 = &matVal(Proj0,row,0);
				p1 = &matVal(Proj1,row,0);
				p2 = &matVal(Proj2,row,0);
				p3 = &matVal(Proj3,row,0);
				for (col=0; col < maxCols; col++)
				{
					Delta = *p0 - p0[strideOffset];
					p1[strideOffset] = Delta - *p2;
					p2[strideOffset] = *p1 - Delta;
					p3[strideOffset] = Delta - *p3;
					p0++;
					p1++;
					p2++;
					p3++;
				}
			}
		}
		else
		{
			for (row=0; row < maxRows-offset; row++)
			{
				p0 = &matVal(Proj0,row,0);
				p1 = &matVal(Proj1,row,0);
				p2 = &matVal(Proj2,row,0);
				for (col=0; col < maxCols; col++)
				{
					Delta = *p0 - p0[strideOffset];
					p1[strideOffset] = Delta - *p2;
					p2[strideOffset] = *p1 - Delta;
					p0++;
					p1++;
					p2++;
				}
			}
		}
	}
	else
	{
		if (numInGroup > 3)
			for (row=0; row < maxRows-offset; row++)
			{
				p0 = &matVal(Proj0,row,0);
				p1 = &matVal(Proj1,row,0);
				p2 = &matVal(Proj2,row,0);
				p3 = &matVal(Proj3,row,0);
				for (col=0; col < maxCols; col++)
				{
					Delta = *p0 + p0[strideOffset];
					p1[strideOffset] = *p2 - Delta;
					p2[strideOffset] = Delta - *p1;
					p3[strideOffset] = *p3 -  Delta;
					p0++;
					p1++;
					p2++;
					p3++;
				}
			}
		if (numInGroup <= 3)
			for (row=0; row < maxRows-offset; row++)
			{
				p0 = &matVal(Proj0,row,0);
				p1 = &matVal(Proj1,row,0);
				p2 = &matVal(Proj2,row,0);
				for (col=0; col < maxCols; col++)
				{
					Delta = *p0 + p0[strideOffset];
					p1[strideOffset] = *p2 - Delta;
					p2[strideOffset] = Delta - *p1;
				}
					p0++;
					p1++;
					p2++;
			}
	}


}

int setIncImageKHT(GCKSetup *setup, int BaseStart, int BaseEnd, int W) {

	int col, row;
	int ColBy4;
	int curIdx, prevIdx;
	int ColMod4;
	row = matVal(setup->baseVectorsOrder,BaseStart,0);
	col = matVal(setup->baseVectorsOrder,BaseStart,1);
	ColMod4 = col&3;
	ColBy4 = (col>>2)<<2;
	curIdx = MAX_BASES+row+col;
	prevIdx = curIdx-1;
#if SHOW_MY_STATS
	printf("compute Proj. No. %d\n", BaseStart);
#endif
	if (BaseStart == 0)
	{
		KHTByCol4(setup, setup->prevImageProj[0], row, ColBy4, BLOCK_SIZE_IMG>>2);
//		KHTByRow4(setup, setup->prevImageProj[0], row, ColBy4, &matVal(setup->prevImageProj[0],BLOCK_SIZE_IMG>>2,0) - &matVal(setup->prevImageProj[0],0,0) );
		setup->OPs += 4*W;// Projection computed
		return 4;
	}
	if (BaseStart == 4)
	{//supersede the memory in proj. No. 0 by another dc component
		setup->ProjExtraH = BLOCK_SIZE_IMG - (BLOCK_SIZE_IMG>>2);
		projDCBySATBy2(setup->prevImageProj[0], setup->tmpProj, BLOCK_SIZE_IMG/4, BLOCK_SIZE_IMG,
		setup->ImgProj_Height+setup->ProjExtraH, setup->ImgProj_Width);
		KHTByRow4(setup, setup->prevImageProj[0], row, ColBy4, BLOCK_SIZE_IMG>>2);
		setup->OPs += 4*W;// Projection computed
		return 12;
	}

	if ( (col&3) ==0 )
	{
		// compute 16*x+0/1/2/3, where x = 1 2 3 4 5
			int32 curBaseNum, prevBaseNum, byRow, curVecNum, prevVecNum, offset, sign;
			curBaseNum = BaseStart;

			prevBaseNum = matVal(setup->baseVectorsOrder, curBaseNum, 2);

			if (matVal(setup->baseVectorsOrder,curBaseNum,0) == matVal(setup->baseVectorsOrder,prevBaseNum,0)) {
				byRow = 0;
				curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,1);
				prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,1);
			}
			else  {
				byRow = 1;
				curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,0);
				prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,0);
			}

			if (byRow)
			{
				curVecNum >>= 2;
				prevVecNum >>= 2;
			}

			calcGCKOffset(&offset, &sign, setup->baseVectors, curVecNum, prevVecNum);
			if (byRow)
			{
				offset >>= 2;
			}
			if (curBaseNum == 16) 
				prevBaseNum = 0;		
			if ( 64 == curBaseNum)
				prevBaseNum = 16;
			

			if (byRow)
				singleWHProjByRow(setup, setup->prevImageProj[prevBaseNum], setup->prevImageProj[curBaseNum],
								  offset, sign);
			else
				singleWHProjByCol(setup, setup->prevImageProj[prevBaseNum], setup->prevImageProj[curBaseNum],
								  offset, sign);

//			setIncImagePureGCK(setup, BaseStart, BaseStart+1);
		
//		KHTByCol(setup, setup->prevImageProj[0], row, ColBy4, 4, BLOCK_SIZE_IMG>>2);
		setup->OPs += 2*W;// Projection computed

		return 4;
	}
	else
	{
		KHTByRow4(setup, setup->prevImageProj[0], row, ColBy4, BLOCK_SIZE_IMG>>2);
		setup->OPs += 4*W;// Projection computed
		return 12;
	}

}

int setIncImageKHT8(GCKSetup *setup, int BaseStart, int BaseEnd, int W) {

	int col, row;
	int ColBy4;
	int curIdx, prevIdx;
	int ColMod4;
	row = matVal(setup->baseVectorsOrder,BaseStart,0);
	col = matVal(setup->baseVectorsOrder,BaseStart,1);
	ColMod4 = col&3;
	ColBy4 = (col>>2)<<2;
	curIdx = MAX_BASES+row+col;
	prevIdx = curIdx-1;
#if SHOW_MY_STATS
	printf("compute Proj. No. %d\n", BaseStart);
#endif
	if (BaseStart == 0)
	{
		KHTByCol4(setup, setup->prevImageProj[0], row, ColBy4, &matVal(setup->prevImageProj[0],BLOCK_SIZE_IMG>>2,0) - &matVal(setup->prevImageProj[0],0,0));
//		KHTByRow4(setup, setup->prevImageProj[0], row, ColBy4, &matVal(setup->prevImageProj[0],BLOCK_SIZE_IMG>>2,0) - &matVal(setup->prevImageProj[0],0,0) );
		setup->OPs += 4*W;// Projection computed
		return 4;
	}
	if (BaseStart == 4)
	{//supersede the memory in proj. No. 0 by another dc component
		setup->ProjExtraH = BLOCK_SIZE_IMG - (BLOCK_SIZE_IMG>>3);
		projDCBySATBy2(setup->prevImageProj[0], setup->tmpProj, BLOCK_SIZE_IMG/8, BLOCK_SIZE_IMG,
			setup->ImgProj_Height+setup->ProjExtraH, setup->ImgProj_Width);
		KHTByRow4(setup, setup->prevImageProj[0], row, ColBy4, BLOCK_SIZE_IMG>>2);
		setup->OPs += 4*W;// Projection computed
		return 28;
	}
	if (BaseStart == 16)
	{
		HaarFromDC(setup->prevImageProj[16], setup->prevImageProj[0], BLOCK_SIZE_IMG/8, BLOCK_SIZE_IMG, 1, 
			setup->ImgProj_Height+setup->ProjExtraH-setup->Block_size_pat/8, setup->ImgProj_Width);
		return 0;
	}

	if ( (col&3) ==0 )
	{
		// compute 16*x+0/1/2/3, where x = 1 2 3 4 5
			int32 curBaseNum, prevBaseNum, byRow, curVecNum, prevVecNum, offset, sign;
			curBaseNum = BaseStart;

			prevBaseNum = matVal(setup->baseVectorsOrder, curBaseNum, 2);

			if (matVal(setup->baseVectorsOrder,curBaseNum,0) == matVal(setup->baseVectorsOrder,prevBaseNum,0)) {
				byRow = 0;
				curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,1);
				prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,1);
			}
			else  {
				byRow = 1;
				curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,0);
				prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,0);
			}

			if (byRow)
			{
				curVecNum >>= 2;
				prevVecNum >>= 2;
			}

			calcGCKOffset(&offset, &sign, setup->baseVectors, curVecNum, prevVecNum);
			if (byRow)
			{
				offset >>= 2;
			}
			if (curBaseNum == 16) 
				prevBaseNum = 0;		
			if ( 64 == curBaseNum)
				prevBaseNum = 0;
			

			if (byRow)
				singleWHProjByRow(setup, setup->prevImageProj[prevBaseNum], setup->prevImageProj[curBaseNum],
								  offset, sign);
			else
				singleWHProjByCol(setup, setup->prevImageProj[prevBaseNum], setup->prevImageProj[curBaseNum],
								  offset, sign);

//			setIncImagePureGCK(setup, BaseStart, BaseStart+1);
		
//		KHTByCol(setup, setup->prevImageProj[0], row, ColBy4, 4, BLOCK_SIZE_IMG>>2);

		setup->OPs += 2*W;// Projection computed
		return 4;
	}
	else
	{
		KHTByRow4(setup, setup->prevImageProj[0], row, ColBy4, BLOCK_SIZE_IMG>>2);
		setup->OPs += 4*W;// Projection computed
		return 28;
	}

}

void setBoundaryZerosProjs(GCKSetup *setup, Matrix **prvImgProj, basisT BaseStart, basisT BaseEnd)
{
	basisT i;
	u_int32 j;
 	Matrix *proj;
 for (i=BaseStart; i<BaseEnd; i++)
  {
	  const int offset = BLOCK_SIZE_IMG>>1;
	  const int32 size1 = sizeof(int32)*offset;
	  const cols = (setup->Img_Width_With_Boundary-BLOCK_SIZE_IMG + 1);
	  const int32 size2 = size1*cols;
	  int32 *p;
	  proj = prvImgProj[i];
	  memset(&matVal(proj,0,0), 0, size2);
	  p = &matVal(proj,offset,0);
	  for (j=offset; j<setup->Img_Height_With_Boundary-setup->Block_size_pat+1; j++, p+=cols)
		  memset(p, 0, size1);		  
  }
}



/*******************************************************************************
 * Calculates the current projection of the image based on previous projection *
 * by columns using GCK (2 operations per pixel).							   *
 ******************************************************************************/ 
__inline void singleWHProjByColDbg(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign) {

	u_int16 row, col;
	u_int16 maxCols, maxRows;
	u_int16 rows = currentProj->rows;
	u_int16 leftBoundarySize = (u_int16)(sizeof(int32)*offset);

	maxCols = (u_int16)(setup->ImgProj_Width-offset);
	maxRows = (u_int16)(setup->ImgProj_Height);

	// fill boundary with zeros
	memset(currentProj->cellValues, 0, sizeof(int32)*(offset)*currentProj->cols);
	for (row=0; row<rows; row++)
		memset(&matVal(currentProj,row,0), 0, leftBoundarySize);
		
	// calculate non-boundary with 2 operations per pixel
	if (sign == 1)
		for (row=0; row < maxRows; row++)
			for (col=0; col < maxCols; col++)
				matVal(currentProj,row,col+offset) =
                    matVal(currentProj,row,col) - matVal(prevProj,row,col+offset) - matVal(prevProj,row,col);
	else
		for (row=0; row < maxRows; row++)
			for (col=0; col < maxCols; col++)
                matVal(currentProj,row,col+offset) =
					-matVal(currentProj,row,col) + matVal(prevProj,row,col) - matVal(prevProj,row,col+offset);
}

__inline void singleWHProjByRowDbg(GCKSetup *setup, Matrix *prevProj, Matrix *currentProj, int32 offset, int32 sign) {

	u_int16 row, col;
	u_int16 maxCols, maxRows;
	u_int16 rows = currentProj->rows;
	u_int16 leftBoundarySize = (u_int16)(sizeof(int32)*offset);

	maxCols = (u_int16)(setup->ImgProj_Width);
	maxRows = (u_int16)(setup->ImgProj_Height-offset);

	// fill boundary with zeros
	memset(currentProj->cellValues, 0, sizeof(int32)*offset*currentProj->cols);
	for (row=0; row<rows; row++)
		memset(&matVal(currentProj,row,0), 0, leftBoundarySize);

	// calculate non-boundary with 2 operations per pixel
	if (sign == 1)
		for (col=0; col < maxCols; col++)
			for (row=0; row < maxRows; row++)
				matVal(currentProj,row+offset,col) =
                    matVal(currentProj,row,col) - matVal(prevProj,row+offset,col) - matVal(prevProj,row,col);
	else
		for (col=0; col < maxCols; col++)
			for (row=0; row < maxRows; row++)
					matVal(currentProj,row+offset,col) =
						-matVal(currentProj,row,col) + matVal(prevProj,row,col) - matVal(prevProj,row+offset,col);
}

//Used for debugging
void setIncImagePureGCKDbg(GCKSetup *setup, int BaseStart, int BaseEnd) {

	int32 curBaseNum, prevBaseNum, byRow, curVecNum, prevVecNum, offset;
	int32 sign;



	//------------ For image  ------------
	// calculate the projections other than dc
	curBaseNum = BaseStart;
	while (curBaseNum < BaseEnd) {

		prevBaseNum = matVal(setup->baseVectorsOrder, curBaseNum, 2);

		if (matVal(setup->baseVectorsOrder,curBaseNum,0) == matVal(setup->baseVectorsOrder,prevBaseNum,0)) {
			byRow = 0;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,1);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,1);
		}
		else  {
			byRow = 1;
			curVecNum = matVal(setup->baseVectorsOrder,curBaseNum,0);
			prevVecNum = matVal(setup->baseVectorsOrder,prevBaseNum,0);
		}

		calcGCKOffset(&offset, &sign, setup->baseVectors, curVecNum, prevVecNum);
		if (byRow)
			singleWHProjByRowDbg(setup, setup->curImageProj2[prevBaseNum], setup->curImageProj2[curBaseNum],
							  offset, sign);
		else
			singleWHProjByColDbg(setup, setup->curImageProj2[prevBaseNum], setup->curImageProj2[curBaseNum],
							  offset, sign);
			curBaseNum++;
	}
}

/*****************************************************************************
 * Performs motion estimation on the given setup. After the execution of     *
 * this function, the resulting motion vector are available in the setup     *
 * motionVecs field in the setup.                       				     *
 *****************************************************************************/ 
int32 matchesOffset[1280*960];
distanceT matchesDist[1280*960];
extern u_int32 SqrDiff[2*MAX_DIFF+1];
void ComputeOffset(Matrix *basesVectors)
{
	int32 *pCur;
	int32 stride, curVecNum;
	register int32 rows = matRows(basesVectors);
	register u_int8 i;
	for (curVecNum = 1; curVecNum < BLOCK_SIZE_IMG; curVecNum++) 
	{
	 pCur = &matVal(basesVectors, curVecNum, 0);
	 stride = &matVal(basesVectors, curVecNum-1, 0) - pCur;
	 for (i=0; (i<rows) && (*pCur== pCur[stride]); i++)
		 pCur++;

		MtxOffset[curVecNum] = i;
	}
}
u_int8 computed[1024];


void motionEstimationGCKLP(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases) {

//	u_int16 halfSearchRange = SEARCH_RANGE / 2;
//	int16 psrXPixel1, psrYPixel1;	// practical coordinates of search range for this block
//	int16 x,y;												// (only inside image boundaries)
	u_int16 maxValidX = setup->Img_Width_With_Boundary - BLOCK_SIZE_IMG;	// max valid coordinates for the
	u_int16 maxValidY = setup->Img_Height_With_Boundary - BLOCK_SIZE_IMG;	// upper left corner of candidate blocks

	int32 curBaseNum;
	int32 *sourcePtr, *initsourcePtr;
	distanceT *destPtr , *initDestPtr, *matchesDistPtr;
	u_int16 sourceDif;
	u_int16 destDif, initDestDif;
	u_int16 cols;
	u_int16 numOfRows, initNumOfRows;
	u_int16 initNumOfCols;
	int32 startBase;
	u_int8 *sourcePtrUint8;
	int32 suspectedCount, suspectedTotal, Count2;

	Matrix_Dist *distMat = setup->distances;
	u_int32 distMatSize = matSize(distMat) * sizeof(distanceT);
	MatchQueue *bestMatches = setup->bestMatches;

	int32 i, bestSadIndex = 0;
	u_int32 ssd;
	u_int32 threshold = setup->Threshold*setup->Block_size_pat*setup->Block_size_pat;

	const int32 PatIdx = 0;
	int32 BasesComputed;
	int32 W;
	Matrix *prevImageProj;
		distanceT thresholdDistT;
#ifdef MY_DEBUG
	int32 CompareReturn;
#endif
/*
	//for counting time
  int tmp_time;
  time_t ltime1;
  time_t ltime2;
#ifdef WIN32
  struct _timeb tstruct1;
  struct _timeb tstruct2;
#else
  struct timeb tstruct1;
  struct timeb tstruct2;
#endif
	//for counting time
*/
	// loop all current image blocks


	// calculate bound on distance for all candidate blocks in search range
	if (WANT_DC) 
		startBase = 0;
	else
		startBase = 1;
	matchesDistPtr = matchesDist;
	// switch between current and previous image
	copyImageWithBoundary(pImage, setup->prevImage, BOUNDARY_SIZE_IMG);
	
	memset(computed, 0, setup->Bases_Num);		// zero distance matrix


	BasesComputed=1;

	ComputeOffset(setup->baseVectors);
/*		
#ifdef WIN32
		_ftime (&tstruct1);           // start time ms
#else
		ftime (&tstruct1);
#endif
		time (&ltime1);               // start time s

		setIncImagePureGCK(setup, 1, MaxBases);

		time (&ltime2);               // end time sec
#ifdef WIN32
		_ftime (&tstruct2);           // end time ms
#else
		ftime (&tstruct2);            // end time ms
#endif

		tmp_time = (ltime2 * 1000 + tstruct2.millitm) - (ltime1 * 1000 + tstruct1.millitm);  tot_time += tmp_time;
	BasesComputed=MaxBases;		
*/
#if SHOW_MY_STATS	
		printf("Warning: collecting stats...\n");
#endif
	projWHDC(setup, setup->prevImage, setup->prevImageProj[0], setup->colsProj);
	BasesComputed=1;

	initNumOfRows = setup->Img_Heihgt - BLOCK_SIZE_IMG + 1; 
	initNumOfCols = setup->Img_Width - BLOCK_SIZE_IMG + 1;
	initDestPtr = distMat->cellValues;
	initDestDif = matCols(distMat) - initNumOfCols;
	memset(distMat->cellValues, 0, distMatSize);	// make distance matrix zeros
	sourceDif = matCols(setup->prevImageProj[0]) - initNumOfCols;
	destDif = initDestDif;
	suspectedTotal = suspectedCount = W = initNumOfCols*initNumOfRows;
	setup->OPs = W*4;//BoxTech
//	Count1 = suspectedCount * PERCENT1 / 100;
	Count2 = (int) (suspectedCount * setup->Percent);
	setup->ImgProj_Width = initNumOfCols + BOUNDARY_SIZE_IMG;
	setup->ImgProj_Height = initNumOfRows + BOUNDARY_SIZE_IMG;
	for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++) {
//		int ttt;
		distanceT tmp;
		int32 curProjValue;
		int32 FlagBreak = 0;
		int32 xpos, ypos;
		suspectedCount = 0;
//		curImageProj = setup->curImageProj[curBaseNum];
		prevImageProj = setup->prevImageProj[curBaseNum];
		curProjValue = PatternWHTCoef[PatIdx][curBaseNum];

//		numOfCols = initNumOfCols; 
		initsourcePtr = prevImageProj->cellValues + matCols(prevImageProj) * BOUNDARY_SIZE_IMG + BOUNDARY_SIZE_IMG;
		sourcePtr = initsourcePtr;

		setup->OPs += suspectedTotal * 3;

		if (curBaseNum == startBase)
		{
			int itmp;
			destPtr = initDestPtr;
			numOfRows = initNumOfRows; 
			while (numOfRows--) {
				cols = initNumOfCols;
				while (cols--) {
					itmp = curProjValue - *sourcePtr;
					if ( (u_int32) abs(itmp) < threshold)
					{
						tmp = (distanceT)itmp;
						tmp = tmp*tmp;
						*destPtr += tmp;
						matchesDistPtr[suspectedCount] = *destPtr;
						matchesOffset[suspectedCount++] = sourcePtr - initsourcePtr;
					}
					sourcePtr++;
					destPtr++;
				}						
				sourcePtr += sourceDif;
				destPtr += destDif;
			}
			thresholdDistT = (distanceT) threshold;
			thresholdDistT *= thresholdDistT;
		}
		else
		{
			for (i = 0; i<suspectedTotal; i++)
			{
//		ypos = matchesOffset[i] / matCols(prevImageProj);
//		xpos = matchesOffset[i] - matCols(prevImageProj) * ypos;
				sourcePtr = initsourcePtr + matchesOffset[i];
				tmp = (distanceT) (curProjValue - *sourcePtr);
				tmp = tmp*tmp;
				matchesDistPtr[i] += tmp;
				if (matchesDistPtr[i] < thresholdDistT)
				{
					matchesDistPtr[suspectedCount] = matchesDistPtr[i];
					matchesOffset[suspectedCount++] = matchesOffset[i];
				} 
			}
		}
#if SHOW_MY_STATS	
		printf("suspectedTotal: %d for %d projections, Ratios: %f\n", suspectedCount, curBaseNum, (float)suspectedCount/suspectedTotal);
#endif
		suspectedTotal = suspectedCount;
		FlagBreak = FlagBreak ||(suspectedTotal < Count2);
		if (FlagBreak) 
		{
			curBaseNum++;
			break;
		}
		// compute projection values when more are needed
		if ( (BasesComputed - curBaseNum ==  1) && (BasesComputed<setup->Bases_Num) )
		{
			setIncImagePureGCK(setup, BasesComputed, BasesComputed+1);
			BasesComputed++;
		}
		
	}//for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++)
//	threshold = threshold/BLOCK_SIZE2;
//	threshold = threshold/BLOCK_SIZE2;
	suspectedCount = 0;
			threshold = (int) (thresholdDistT/(setup->Block_size_pat*setup->Block_size_pat));
	sourcePtrUint8 = imPixels(setup->curImage) + matCols(setup->curImage) * setup->Boundary_Size_Pat + setup->Boundary_Size_Pat;
	sourceDif = imCols(setup->curImage) - BLOCK_SIZE_IMG;
	prevImageProj = setup->prevImageProj[0];
	destDif = imCols(setup->prevImage) - BLOCK_SIZE_IMG;
	i = 0;
	setup->CandRemained = suspectedTotal;
	setup->OPs += (curBaseNum-1)*2*W;// Projection computed
#if COUNT_SSDOPS
// 	setup->OPs = 3*suspectedTotal * BLOCK_SIZE_IMG*BLOCK_SIZE_IMG;
 	setup->OPs += 3*(double)suspectedTotal * BLOCK_SIZE_IMG*BLOCK_SIZE_IMG;
#endif
	while (i<suspectedTotal)
	{
		int xpos, ypos;
		int offsetNow = matchesOffset[i];// + initNumOfCols;
		i++;
		ypos = offsetNow / matCols(prevImageProj);
		xpos = offsetNow - matCols(prevImageProj) * ypos;
//		xpos = offsetNow % matCols(setup->prevImageProj[0]);
		ssd = calcSSD(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
		if (ssd < threshold)
		{
			setup->match[suspectedCount] = ssd;
			setup->xmatch[suspectedCount] = ypos;
			setup->ymatch[suspectedCount] = xpos;
			suspectedCount++;
		}
	}
	setup->count = suspectedCount;
	setup->BasesComputed = curBaseNum;

#ifdef MY_DEBUG
	projWHDCDbg(setup, setup->prevImage, setup->curImageProj2[0], setup->colsProj);
	setIncImagePureGCKDbg(setup, 1, BasesComputed);
	for (curBaseNum=0; curBaseNum < MaxBases; curBaseNum++) {
		CompareReturn = Compare(setup, setup->curImageProj2[curBaseNum], setup->prevImageProj[curBaseNum]);
		if (CompareReturn!=0) printf("error in computing base No.: %d!!\n", curBaseNum);
	}
#endif
}


void motionEstimationGCKNewLP(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases) {

	u_int16 maxValidX = setup->Img_Width_With_Boundary - BLOCK_SIZE_IMG;	// max valid coordinates for the
	u_int16 maxValidY = setup->Img_Height_With_Boundary - BLOCK_SIZE_IMG;	// upper left corner of candidate blocks

	u_int8 curBaseNum;
	int32 *sourcePtr, *initsourcePtr;
	distanceT *destPtr , *initDestPtr, *matchesDistPtr;
	u_int16 sourceDif;
	u_int16 destDif, initDestDif;
	u_int16 cols;
	u_int16 numOfRows, initNumOfRows;
	u_int16 initNumOfCols;
	int32 startBase;
	u_int8 *sourcePtrUint8;
	int32 suspectedCount, suspectedTotal, Count2;

	Matrix_Dist *distMat = setup->distances;
	u_int32 distMatSize = matSize(distMat) * sizeof(distanceT);
	MatchQueue *bestMatches = setup->bestMatches;

	int32 i, bestSadIndex = 0;
	u_int32 ssd;
	u_int32 threshold = setup->Threshold*setup->Block_size_pat*setup->Block_size_pat;
		distanceT thresholdDistT;

	const int32 PatIdx = 0;
	int32 BasesComputed;
	Matrix *prevImageProj;
#ifdef MY_DEBUG
	int32 CompareReturn;
#endif
/*
	//for counting time
  int tmp_time;
  time_t ltime1;
  time_t ltime2;
#ifdef WIN32
  struct _timeb tstruct1;
  struct _timeb tstruct2;
#else
  struct timeb tstruct1;
  struct timeb tstruct2;
#endif
	//for counting time
*/
	// loop all current image blocks


	// calculate bound on distance for all candidate blocks in search range
	matchesDistPtr = matchesDist;
	if (WANT_DC) 
		startBase = 0;
	else
		startBase = 1;
	// switch between current and previous image
#if SHOW_MY_STATS	
		printf("Warning: collecting stats...\n");
#endif
	copyImageWithBoundary(pImage, setup->prevImage, BOUNDARY_SIZE_IMG);
	
	memset(computed, 0, setup->Bases_Num);		// zero distance matrix


	BasesComputed=1;


	CalcImageDiff2(setup, setup->prevImage, setup->diffImage);
	projDiffWHDC(setup, setup->diffImage, setup->prevImageProj[MAX_BASES], setup->colsProj, BLOCK_SIZE_IMG, BLOCK_SIZE_IMG>>2);
	setIncImageGCKOY(setup, 0, 3);
	BasesComputed=4;

	initNumOfRows = setup->Img_Heihgt - BLOCK_SIZE_IMG + 1; 
	initNumOfCols = setup->Img_Width - BLOCK_SIZE_IMG + 1;
	initDestPtr = distMat->cellValues;
	initDestDif = matCols(distMat) - initNumOfCols;
	memset(distMat->cellValues, 0, distMatSize);	// make distance matrix zeros
	sourceDif = matCols(setup->prevImageProj[0]) - initNumOfCols;
	destDif = initDestDif;
	suspectedTotal = suspectedCount = initNumOfCols*initNumOfRows;
//	Count1 = suspectedCount * PERCENT1 / 100;
	Count2 = (int) (suspectedCount * setup->Percent);

	//for each basis vector
	for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++) {
		distanceT tmp;
		int32 curProjValue, *pOffset;
		int32 FlagBreak = 0;
		distanceT *pDist; 
		suspectedCount = 0;
		prevImageProj = setup->prevImageProj[curBaseNum];
		curProjValue = PatternWHTCoef[PatIdx][curBaseNum];

		initsourcePtr = prevImageProj->cellValues + matCols(prevImageProj) * BOUNDARY_SIZE_IMG + BOUNDARY_SIZE_IMG;
		sourcePtr = initsourcePtr;

		// At first time, try all of the canditate points
		pDist = matchesDistPtr;
		pOffset = matchesOffset;
		if (curBaseNum == startBase)
		{
			int itmp;
			destPtr = initDestPtr;
			numOfRows = initNumOfRows; 
			while (numOfRows--) {
				cols = initNumOfCols;
				while (cols--) {
					itmp = curProjValue - *sourcePtr;
					if ( (u_int32) abs(itmp) < threshold)
					{
						tmp = (distanceT) itmp;
						tmp = tmp*tmp;
						*destPtr += tmp;
						*pDist = *destPtr;
						*pOffset = sourcePtr - initsourcePtr;
//						matchesDistPtr[suspectedCount] = *destPtr;
//						matchesOffset[suspectedCount++] = sourcePtr - initsourcePtr;
						pDist++;
						pOffset++;
					}
					sourcePtr++;
					destPtr++;
				}						
				sourcePtr += sourceDif;
				destPtr += destDif;
			}
			suspectedCount = pDist - matchesDistPtr;
			thresholdDistT = (distanceT) threshold;
			thresholdDistT *= thresholdDistT;
		}
		else
		// Later on, try canditate points that are not rejected before
		{
			for (i = 0; i<suspectedTotal; i++)
			{
				sourcePtr = initsourcePtr + pOffset[i];
				tmp = (distanceT) (curProjValue - *sourcePtr);
				tmp = tmp*tmp;
				matchesDistPtr[i] += tmp;
				if (matchesDistPtr[i] < thresholdDistT)
				{
					matchesDistPtr[suspectedCount] = matchesDistPtr[i];
					pOffset[suspectedCount++] = pOffset[i];
				} 
			}
		}
#if SHOW_MY_STATS	
		printf("suspectedTotal: %d for %d projections, Ratios: %f\n", suspectedCount, curBaseNum, (float)suspectedCount/suspectedTotal);
#endif
		suspectedTotal = suspectedCount;
		FlagBreak = FlagBreak ||(suspectedTotal < Count2);
		//To see if we should jump to directly computing the Euclidean distance
		if (FlagBreak) 
			break;
		// compute projection values when more are needed
		if ( (BasesComputed - curBaseNum ==  1) && (BasesComputed<setup->Bases_Num) )
		{
			setIncImageGCKOY(setup, BasesComputed, BasesComputed+4);
			BasesComputed+=4;
		}		
	}//for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++)
	suspectedCount = 0;
	sourcePtrUint8 = imPixels(setup->curImage) + matCols(setup->curImage) * setup->Boundary_Size_Pat + setup->Boundary_Size_Pat;
	sourceDif = imCols(setup->curImage) - BLOCK_SIZE_IMG;
	prevImageProj = setup->prevImageProj[0];
	destDif = imCols(setup->prevImage) - BLOCK_SIZE_IMG;
	i = 0;
			threshold = (int) (thresholdDistT/(setup->Block_size_pat*setup->Block_size_pat));
	setup->CandRemained = suspectedTotal;
	while (i<suspectedTotal)
	{
		int xpos, ypos;
		int offsetNow = matchesOffset[i];// + initNumOfCols;
		i++;
		ypos = offsetNow / matCols(prevImageProj);
		xpos = offsetNow - matCols(prevImageProj) * ypos;
//		xpos = offsetNow % matCols(setup->prevImageProj[0]);
		ssd = calcSSD(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
		if (ssd < threshold)
		{
			setup->match[suspectedCount] = ssd;
			setup->xmatch[suspectedCount] = ypos;
			setup->ymatch[suspectedCount] = xpos;
			suspectedCount++;
		}
	}
	setup->count = suspectedCount;
	setup->BasesComputed = curBaseNum;
#ifdef MY_DEBUG
	projWHDCDbg(setup, setup->prevImage, setup->curImageProj2[0], setup->colsProj);
	setIncImagePureGCKDbg(setup, 1, BasesComputed);
	for (curBaseNum=0; curBaseNum < MaxBases; curBaseNum++) {
		CompareReturn = Compare(setup, setup->curImageProj2[curBaseNum], setup->prevImageProj[curBaseNum]);
		if (CompareReturn!=0) printf("error in computing base No.: %d!!\n", curBaseNum);
	}
#endif

}
/*
void SatSum(unsigned char *Image, int ImageWidth, int ImageHeight, int *ResultImage){

int i, j;
int temp;

ResultImage[0] = Image[0];
for(i=1; i<ImageWidth; i++)
	ResultImage[i] = Image[i] + ResultImage[i-1];
	
for(j=1; j<ImageHeight; j++){
	temp = Image[j*ImageWidth];
	ResultImage[j*ImageWidth] = temp + ResultImage[(j-1)*ImageWidth];
	
	for(i=1; i<ImageWidth; i++){
		temp += Image[j*ImageWidth+i];
		ResultImage[j*ImageWidth+i] = temp + ResultImage[(j-1)*ImageWidth+i];
	}
}
}*/


void motionEstimationKHT(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases) {

	u_int16 maxValidX = setup->Img_Width_With_Boundary - BLOCK_SIZE_IMG;	// max valid coordinates for the
	u_int16 maxValidY = setup->Img_Height_With_Boundary - BLOCK_SIZE_IMG;	// upper left corner of candidate blocks

	u_int8 curBaseNum;
	int32 *sourcePtr, *initsourcePtr;
	distanceT *destPtr , *initDestPtr, *matchesDistPtr;
	u_int16 sourceDif;
	u_int16 destDif, initDestDif;
	u_int16 cols;
	u_int16 numOfRows, initNumOfRows;
	u_int16 initNumOfCols;
	int32 startBase;
	u_int8 *sourcePtrUint8;
	int32 suspectedCount, suspectedTotal, Count2;

	Matrix_Dist *distMat = setup->distances;
	u_int32 distMatSize = matSize(distMat) * sizeof(distanceT);
	MatchQueue *bestMatches = setup->bestMatches;

	int32 i, bestSadIndex = 0;
	u_int32 ssd;
	u_int32 threshold = setup->Threshold*setup->Block_size_pat*setup->Block_size_pat;
		distanceT thresholdDistT;

	const int32 PatIdx = 0;
	int32 BasesComputed;
	int32 W;
	Matrix *prevImageProj;
#ifdef MY_DEBUG
	int32 CompareReturn;
#endif
/*
	//for counting time
  int tmp_time;
  time_t ltime1;
  time_t ltime2;
#ifdef WIN32
  struct _timeb tstruct1;
  struct _timeb tstruct2;
#else
  struct timeb tstruct1;
  struct timeb tstruct2;
#endif
	//for counting time
*/
	// loop all current image blocks


	// calculate bound on distance for all candidate blocks in search range
	matchesDistPtr = matchesDist;
	if (WANT_DC) 
		startBase = 0;
	else
		startBase = 1;
	// switch between current and previous image
#if SHOW_MY_STATS	
		printf("Warning: collecting stats...\n");
#endif
	copyImageWithBoundary(pImage, setup->prevImage, BOUNDARY_SIZE_IMG);
	
	memset(computed, 0, setup->Bases_Num);		// zero distance matrix


	BasesComputed=1;

	SatSum(setup->prevImage->pixels, setup->Img_Width_With_Boundary, setup->Img_Height_With_Boundary, &matVal(setup->tmpProj,0,0));
	projDCBySAT(setup, setup->prevImageProj[0], setup->tmpProj, BLOCK_SIZE_IMG, BLOCK_SIZE_IMG,
		setup->ImgProj_Height, setup->ImgProj_Width);
	setup->ProjExtraH = 0;
//	projWHDC(setup, setup->prevImage, setup->prevImageProj[0], setup->colsProj);
//	KHTByCol(setup, setup->prevImageProj[0], 0, 0, 4, BLOCK_SIZE_IMG>>2);
	BasesComputed=1;

	initNumOfRows = setup->Img_Heihgt - BLOCK_SIZE_IMG + 1; 
	initNumOfCols = setup->Img_Width - BLOCK_SIZE_IMG + 1;
	initDestPtr = distMat->cellValues;
	initDestDif = matCols(distMat) - initNumOfCols;
	memset(distMat->cellValues, 0, distMatSize);	// make distance matrix zeros
	sourceDif = matCols(setup->prevImageProj[0]) - initNumOfCols;
	destDif = initDestDif;
	suspectedTotal = suspectedCount = W = initNumOfCols*initNumOfRows;
//	Count1 = suspectedCount * PERCENT1 / 100;
	Count2 = (int) (suspectedCount * setup->Percent);
	setup->OPs = W*4;//BoxTech

	//for each basis vector
	for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++) {
		distanceT tmp;
		int32 curProjValue, *pOffset;
		int32 FlagBreak = 0;
		distanceT *pDist; 
		suspectedCount = 0;
		prevImageProj = setup->prevImageProj[curBaseNum];
		curProjValue = PatternWHTCoef[PatIdx][curBaseNum];

		initsourcePtr = &matVal(prevImageProj,0,0) + matCols(prevImageProj) * BOUNDARY_SIZE_IMG + BOUNDARY_SIZE_IMG;
		sourcePtr = initsourcePtr;

		// At first time, try all of the canditate points
		pDist = matchesDistPtr;
		pOffset = matchesOffset;
		setup->OPs += suspectedTotal * 3;
		if (curBaseNum == startBase)
		{
			int itmp;
			destPtr = initDestPtr;
			numOfRows = initNumOfRows; 
			while (numOfRows--) {
				cols = initNumOfCols;
				while (cols--) {
					itmp = curProjValue - *sourcePtr;
					if ( (u_int32) abs(itmp) < threshold)
					{
						tmp = (distanceT) itmp;
						tmp = tmp*tmp;
						*destPtr += tmp;
						*pDist = *destPtr;
						*pOffset = sourcePtr - initsourcePtr;
//						matchesDistPtr[suspectedCount] = *destPtr;
//						matchesOffset[suspectedCount++] = sourcePtr - initsourcePtr;
						pDist++;
						pOffset++;
					}
					sourcePtr++;
					destPtr++;
				}						
				sourcePtr += sourceDif;
				destPtr += destDif;
			}
			suspectedCount = pDist - matchesDistPtr;
			thresholdDistT = (distanceT) threshold;
			thresholdDistT *= thresholdDistT;
		}
		else
		// Later on, try canditate points that are not rejected before
		{
			for (i = 0; i<suspectedTotal; i++)
			{
				sourcePtr = initsourcePtr + pOffset[i];
				tmp = (distanceT) (curProjValue - *sourcePtr);
				tmp = tmp*tmp;
				matchesDistPtr[i] += tmp;
				if (matchesDistPtr[i] < thresholdDistT)
				{
					matchesDistPtr[suspectedCount] = matchesDistPtr[i];
					pOffset[suspectedCount++] = pOffset[i];
				} 
			}
		}
#if SHOW_MY_STATS	
		printf("suspectedTotal: %d for %d projections, Ratios: %f\n", suspectedCount, curBaseNum, (float)suspectedCount/suspectedTotal);
#endif
		suspectedTotal = suspectedCount;
		FlagBreak = FlagBreak ||(suspectedTotal < Count2);
		//To see if we should jump to directly computing the Euclidean distance
		if (FlagBreak) 
			break;
		// compute projection values when more are needed
		if ( (BasesComputed - curBaseNum ==  1) && (BasesComputed<setup->Bases_Num) )
		{
			if (curBaseNum == 0)
				BasesComputed = 0;
			BasesComputed += setIncImageKHT(setup, BasesComputed, BasesComputed+4, W);
//			+=4;
		}		
	}//for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++)
	suspectedCount = 0;
	sourcePtrUint8 = imPixels(setup->curImage) + matCols(setup->curImage) * setup->Boundary_Size_Pat + setup->Boundary_Size_Pat;
	sourceDif = imCols(setup->curImage) - BLOCK_SIZE_IMG;
	prevImageProj = setup->prevImageProj[0];
	destDif = imCols(setup->prevImage) - BLOCK_SIZE_IMG;
	i = 0;
	setup->OPs += 3*suspectedTotal * BLOCK_SIZE_IMG*BLOCK_SIZE_IMG;// actual distance
	threshold = (int) (thresholdDistT/(setup->Block_size_pat*setup->Block_size_pat));
	while (i<suspectedTotal)
	{
		int xpos, ypos;
		int offsetNow = matchesOffset[i];// + initNumOfCols;
		i++;
		ypos = offsetNow / matCols(prevImageProj);
		xpos = offsetNow - matCols(prevImageProj) * ypos;
//		xpos = offsetNow % matCols(setup->prevImageProj[0]);
		ssd = calcSSD(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
		if (ssd < threshold)
		{
			setup->match[suspectedCount] = ssd;
			setup->xmatch[suspectedCount] = ypos;
			setup->ymatch[suspectedCount] = xpos;
			suspectedCount++;
		}
	}
	setup->count = suspectedCount;
	setup->BasesComputed = curBaseNum;
}
int32 matchesCol[1280*960];
int32 matchesRow[1280*960];

void motionEstimationKHT8(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases) {

	u_int16 maxValidX = setup->Img_Width_With_Boundary - BLOCK_SIZE_IMG;	// max valid coordinates for the
	u_int16 maxValidY = setup->Img_Height_With_Boundary - BLOCK_SIZE_IMG;	// upper left corner of candidate blocks

	u_int8 curBaseNum;
	int32 *sourcePtr, *initsourcePtr;
	distanceT *destPtr , *initDestPtr, *matchesDistPtr;
	u_int16 sourceDif;
	u_int16 destDif, initDestDif;
	u_int16 cols;
	u_int16 numOfRows, initNumOfRows;
	u_int16 initNumOfCols;
	int32 startBase;
	u_int8 *sourcePtrUint8;
	int32 suspectedCount, suspectedTotal, Count2;
	int32 *pmatchesCol = matchesCol;
	int32 *pmatchesRow = matchesRow;
	int row, col;

	Matrix_Dist *distMat = setup->distances;
	u_int32 distMatSize = matSize(distMat) * sizeof(distanceT);
	MatchQueue *bestMatches = setup->bestMatches;

	int32 i, bestSadIndex = 0;
	u_int32 ssd;
	u_int32 threshold = setup->Threshold*setup->Block_size_pat*setup->Block_size_pat;
		distanceT thresholdDistT;
	int32 W;
		int32 InitMaxRowProj, InitMaxColProj;

	const int32 PatIdx = 0;
	int32 BasesComputed;
	Matrix *prevImageProj;
#ifdef MY_DEBUG
	int32 CompareReturn;
#endif
/*
	//for counting time
  int tmp_time;
  time_t ltime1;
  time_t ltime2;
#ifdef WIN32
  struct _timeb tstruct1;
  struct _timeb tstruct2;
#else
  struct timeb tstruct1;
  struct timeb tstruct2;
#endif
	//for counting time
*/
	// loop all current image blocks


	// calculate bound on distance for all candidate blocks in search range
	matchesDistPtr = matchesDist;
	if (WANT_DC) 
		startBase = 0;
	else
		startBase = 1;
	// switch between current and previous image
#if SHOW_MY_STATS	
		printf("Warning: collecting stats...\n");
#endif
	copyImageWithBoundary(pImage, setup->prevImage, BOUNDARY_SIZE_IMG);
	
	memset(computed, 0, setup->Bases_Num);		// zero distance matrix


	BasesComputed=1;

	SatSum(setup->prevImage->pixels, setup->Img_Width_With_Boundary, setup->Img_Height_With_Boundary, &matVal(setup->tmpProj,0,0));
	projDCBySAT(setup, setup->prevImageProj[0], setup->tmpProj, BLOCK_SIZE_IMG, BLOCK_SIZE_IMG,
		setup->ImgProj_Height, setup->ImgProj_Width);
	setup->ProjExtraH = 0;
//	projWHDC(setup, setup->prevImage, setup->prevImageProj[0], setup->colsProj);
//	KHTByCol(setup, setup->prevImageProj[0], 0, 0, 4, BLOCK_SIZE_IMG>>2);
	BasesComputed=1;

	initNumOfRows = setup->Img_Heihgt - BLOCK_SIZE_IMG + 1; 
	initNumOfCols = setup->Img_Width - BLOCK_SIZE_IMG + 1;
	initDestPtr = distMat->cellValues;
	initDestDif = matCols(distMat) - initNumOfCols;
	memset(distMat->cellValues, 0, distMatSize);	// make distance matrix zeros
	sourceDif = matCols(setup->prevImageProj[0]) - initNumOfCols;
	destDif = initDestDif;
	suspectedTotal = suspectedCount = W = initNumOfCols*initNumOfRows;
//	Count1 = suspectedCount * PERCENT1 / 100;
	setup->OPs = W*4;//BoxTech
	Count2 = (int) (suspectedCount * setup->Percent);

	InitMaxRowProj = initNumOfRows;
	InitMaxColProj = initNumOfCols;

	//for each basis vector
	for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++) {
		distanceT tmp;
		int32 curProjValue, *pOffset;
		int32 FlagBreak = 0;
		int32 MaxRowProj, MaxColProj;
		distanceT *pDist; 
		suspectedCount = 0;
		prevImageProj = setup->prevImageProj[curBaseNum];
		curProjValue = PatternWHTCoef[PatIdx][curBaseNum];

		initsourcePtr = &matVal(prevImageProj,0,0) + matCols(prevImageProj) * BOUNDARY_SIZE_IMG + BOUNDARY_SIZE_IMG;
		sourcePtr = initsourcePtr;

		setup->OPs += suspectedTotal * 3;
//		if (curBaseNum==37)
//			printf("stop here!\n");

		// At first time, try all of the canditate points
		pDist = matchesDistPtr;
		pOffset = matchesOffset;
		if (curBaseNum == startBase)
		{
			int itmp;
			destPtr = initDestPtr;
//			numOfRows = initNumOfRows; 
			MaxRowProj = MaxColProj = 0;
			suspectedCount = 0;
			for (row=0; row<initNumOfRows; row++) {
				for (col=0; col<initNumOfCols; col++) {
					itmp = curProjValue - *sourcePtr;
					if ( (u_int32) abs(itmp) < threshold)
					{
						tmp = (distanceT) itmp;
						tmp = tmp*tmp;
						*destPtr += tmp;
						*pDist = *destPtr;
						*pOffset = sourcePtr - initsourcePtr;
//						matchesDistPtr[suspectedCount] = *destPtr;
//						matchesOffset[suspectedCount++] = sourcePtr - initsourcePtr;
						pmatchesCol[suspectedCount] = col;
						pmatchesRow[suspectedCount] = row;

						if (col>MaxColProj) MaxColProj = col;
						if (row>MaxRowProj) MaxRowProj = row;

						suspectedCount++;
						pDist++;
						pOffset++;
					}
					sourcePtr++;
					destPtr++;
				}						
				sourcePtr += sourceDif;
				destPtr += destDif;
			}

			suspectedCount = pDist - matchesDistPtr;
			thresholdDistT = (distanceT) threshold;
			thresholdDistT *= thresholdDistT;
			
			setup->ImgProj_Width  += MaxColProj-InitMaxColProj+1;
			setup->ImgProj_Height += MaxRowProj-InitMaxRowProj+1;
			InitMaxRowProj = MaxRowProj+1;
			InitMaxColProj = MaxColProj+1;
		}
		else
		// Later on, try canditate points that are not rejected before
		{
			if ( (curBaseNum<4) || ((curBaseNum>=16)&&(curBaseNum<=19)) )
			{
				MaxRowProj = MaxColProj = 0;
				for (i = 0; i<suspectedTotal; i++)
				{
					sourcePtr = initsourcePtr + pOffset[i];
					tmp = (distanceT) (curProjValue - *sourcePtr);
					tmp = tmp*tmp;
					matchesDistPtr[i] += tmp;
					if (matchesDistPtr[i] < thresholdDistT)
					{
						pmatchesCol[suspectedCount] = pmatchesCol[i];
						pmatchesRow[suspectedCount] = pmatchesRow[i];
						if (pmatchesCol[i]>MaxColProj) 
							MaxColProj = pmatchesCol[i];
						if (pmatchesRow[i]>MaxRowProj) 
							MaxRowProj = pmatchesRow[i];
						matchesDistPtr[suspectedCount] = matchesDistPtr[i];
						pOffset[suspectedCount++] = pOffset[i];
					} 
				}
				setup->ImgProj_Width  += MaxColProj-InitMaxColProj+1;
				setup->ImgProj_Height += MaxRowProj-InitMaxRowProj+1;
				InitMaxRowProj = MaxRowProj+1;
				InitMaxColProj = MaxColProj+1;
			}
			else
			{
//				distanceT thresholdDistT2 = thresholdDistT*2;

				MaxRowProj = MaxColProj = 0;
				for (i = 0; i<suspectedTotal; i++)
				{
					sourcePtr = initsourcePtr + pOffset[i];
					tmp = (distanceT) (curProjValue - *sourcePtr);
					tmp = tmp*tmp*2;
					matchesDistPtr[i] += tmp;
					if (matchesDistPtr[i] < thresholdDistT)
					{
						pmatchesCol[suspectedCount] = pmatchesCol[i];
						pmatchesRow[suspectedCount] = pmatchesRow[i];
						matchesDistPtr[suspectedCount] = matchesDistPtr[i];
						pOffset[suspectedCount++] = pOffset[i];
						if (pmatchesCol[i]>MaxColProj) 
							MaxColProj = pmatchesCol[i];
						if (pmatchesRow[i]>MaxRowProj) 
							MaxRowProj = pmatchesRow[i];
					} 
				}
				setup->ImgProj_Width  += MaxColProj-InitMaxColProj+1;
				setup->ImgProj_Height += MaxRowProj-InitMaxRowProj+1;
				InitMaxRowProj = MaxRowProj+1;
				InitMaxColProj = MaxColProj+1;
			}
		}
#if SHOW_MY_STATS	
		printf("suspectedTotal: %d for %d projections, Ratios: %f\n", suspectedCount, curBaseNum, (float)suspectedCount/suspectedTotal);
#endif
		suspectedTotal = suspectedCount;
		FlagBreak = FlagBreak ||(suspectedTotal < Count2);
		//To see if we should jump to directly computing the Euclidean distance
		if (FlagBreak) 
			break;
		if ( (curBaseNum < (setup->Bases_Num-1)) && (curBaseNum==15) ) //Now compute coefficient 16
		{
			setIncImageKHT8(setup, 16, 16+4, W);
		}
		// compute projection values when more are needed
		if  ( (BasesComputed - curBaseNum ==  1) && (BasesComputed<setup->Bases_Num) ) 
		{
			if (curBaseNum == 0)
				BasesComputed = 0;
			BasesComputed += setIncImageKHT8(setup, BasesComputed, BasesComputed+4, W);
//			+=4;
		}		
	}//for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++)
	setup->ImgProj_Width = initNumOfCols + BOUNDARY_SIZE_IMG;
	setup->ImgProj_Height = initNumOfRows + BOUNDARY_SIZE_IMG;

	suspectedCount = 0;
	sourcePtrUint8 = imPixels(setup->curImage) + matCols(setup->curImage) * setup->Boundary_Size_Pat + setup->Boundary_Size_Pat;
	sourceDif = imCols(setup->curImage) - BLOCK_SIZE_IMG;
	prevImageProj = setup->prevImageProj[0];
	destDif = imCols(setup->prevImage) - BLOCK_SIZE_IMG;
	i = 0;
	threshold = (int) (thresholdDistT/(setup->Block_size_pat*setup->Block_size_pat));
	setup->CandRemained = suspectedTotal;

//	setup->OPs += (curBaseNum-1)*4*W/3/8;// Projection computed
#if COUNT_SSDOPS
// 	setup->OPs = 3*suspectedTotal * BLOCK_SIZE_IMG*BLOCK_SIZE_IMG;
 	setup->OPs += 3*(double)suspectedTotal * BLOCK_SIZE_IMG*BLOCK_SIZE_IMG;
#endif

	while (i<suspectedTotal)
	{
		int xpos, ypos;
/*		int offsetNow = matchesOffset[i];// + initNumOfCols;
		ypos = offsetNow / matCols(prevImageProj);
		xpos = offsetNow - matCols(prevImageProj) * ypos;
		if (ypos!= pmatchesRow[i])
			printf("error y\n");
		if (xpos!= pmatchesCol[i])
			printf("error x\n");*/
		ypos = pmatchesRow[i];
		xpos = pmatchesCol[i];
		i++;
//		xpos = offsetNow % matCols(setup->prevImageProj[0]);
		ssd = calcSSD(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
		if (ssd < threshold)
		{
			setup->match[suspectedCount] = ssd;
			setup->xmatch[suspectedCount] = ypos;
			setup->ymatch[suspectedCount] = xpos;
			suspectedCount++;
		}
	}
	setup->count = suspectedCount;
	setup->BasesComputed = BasesComputed;
}


void motionEstimationKHTLP(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases) {

	u_int16 maxValidX = setup->Img_Width_With_Boundary - BLOCK_SIZE_IMG;	// max valid coordinates for the
	u_int16 maxValidY = setup->Img_Height_With_Boundary - BLOCK_SIZE_IMG;	// upper left corner of candidate blocks

	u_int8 curBaseNum;
	int32 *sourcePtr, *initsourcePtr;
	distanceT *destPtr , *initDestPtr, *matchesDistPtr;
	u_int16 sourceDif;
	u_int16 destDif, initDestDif;
	u_int16 cols;
	u_int16 numOfRows, initNumOfRows;
	u_int16 initNumOfCols;
	int32 startBase;
	u_int8 *sourcePtrUint8;
	int32 suspectedCount, suspectedTotal, Count2;

	Matrix_Dist *distMat = setup->distances;
	u_int32 distMatSize = matSize(distMat) * sizeof(distanceT);
	MatchQueue *bestMatches = setup->bestMatches;

	int32 i, bestSadIndex = 0;
	u_int32 ssd;
	u_int32 threshold = setup->Threshold*setup->Block_size_pat*setup->Block_size_pat;
		distanceT thresholdDistT;

	const int32 PatIdx = 0;
	int32 BasesComputed;
	int32 W;
	Matrix *prevImageProj;
#ifdef MY_DEBUG
	int32 CompareReturn;
#endif
/*
	//for counting time
  int tmp_time;
  time_t ltime1;
  time_t ltime2;
#ifdef WIN32
  struct _timeb tstruct1;
  struct _timeb tstruct2;
#else
  struct timeb tstruct1;
  struct timeb tstruct2;
#endif
	//for counting time
*/
	// loop all current image blocks


	// calculate bound on distance for all candidate blocks in search range
	matchesDistPtr = matchesDist;
	if (WANT_DC) 
		startBase = 0;
	else
		startBase = 1;
	// switch between current and previous image
#if SHOW_MY_STATS	
		printf("Warning: collecting stats...\n");
#endif
	copyImageWithBoundary(pImage, setup->prevImage, BOUNDARY_SIZE_IMG);
	
	memset(computed, 0, setup->Bases_Num);		// zero distance matrix


	BasesComputed=1;

	SatSum(setup->prevImage->pixels, setup->Img_Width_With_Boundary, setup->Img_Height_With_Boundary, &matVal(setup->tmpProj,0,0));
	projDCBySAT(setup, setup->prevImageProj[0], setup->tmpProj, BLOCK_SIZE_IMG, BLOCK_SIZE_IMG,
		setup->ImgProj_Height, setup->ImgProj_Width);
	setup->ProjExtraH = 0;
//	projWHDC(setup, setup->prevImage, setup->prevImageProj[0], setup->colsProj);
//	KHTByCol(setup, setup->prevImageProj[0], 0, 0, 4, BLOCK_SIZE_IMG>>2);
	BasesComputed=1;

	initNumOfRows = setup->Img_Heihgt - BLOCK_SIZE_IMG + 1; 
	initNumOfCols = setup->Img_Width - BLOCK_SIZE_IMG + 1;
	initDestPtr = distMat->cellValues;
	initDestDif = matCols(distMat) - initNumOfCols;
	memset(distMat->cellValues, 0, distMatSize);	// make distance matrix zeros
	sourceDif = matCols(setup->prevImageProj[0]) - initNumOfCols;
	destDif = initDestDif;
	suspectedTotal = suspectedCount = W = initNumOfCols*initNumOfRows;
//	Count1 = suspectedCount * PERCENT1 / 100;
	setup->OPs = W*4;//BoxTech
	Count2 = (int) (suspectedCount * setup->Percent);

	//for each basis vector
	for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++) {
		distanceT tmp;
		int32 curProjValue, *pOffset;
		int32 FlagBreak = 0;
		distanceT *pDist; 
		suspectedCount = 0;
		prevImageProj = setup->prevImageProj[curBaseNum];
		curProjValue = PatternWHTCoef[PatIdx][curBaseNum];

		initsourcePtr = &matVal(prevImageProj,0,0) + matCols(prevImageProj) * BOUNDARY_SIZE_IMG + BOUNDARY_SIZE_IMG;
		sourcePtr = initsourcePtr;
		setup->OPs += suspectedTotal * 3;

		// At first time, try all of the canditate points
		pDist = matchesDistPtr;
		pOffset = matchesOffset;
		if (curBaseNum == startBase)
		{
			int itmp;
			destPtr = initDestPtr;
			numOfRows = initNumOfRows; 
			while (numOfRows--) {
				cols = initNumOfCols;
				while (cols--) {
					itmp = curProjValue - *sourcePtr;
					if ( (u_int32) abs(itmp) < threshold)
					{
						tmp = (distanceT) itmp;
						tmp = tmp*tmp;
						*destPtr += tmp;
						*pDist = *destPtr;
						*pOffset = sourcePtr - initsourcePtr;
//						matchesDistPtr[suspectedCount] = *destPtr;
//						matchesOffset[suspectedCount++] = sourcePtr - initsourcePtr;
						pDist++;
						pOffset++;
					}
					sourcePtr++;
					destPtr++;
				}						
				sourcePtr += sourceDif;
				destPtr += destDif;
			}
			suspectedCount = pDist - matchesDistPtr;
			thresholdDistT = (distanceT) threshold;
			thresholdDistT *= thresholdDistT;
		}
		else
		// Later on, try canditate points that are not rejected before
		{
			for (i = 0; i<suspectedTotal; i++)
			{
				sourcePtr = initsourcePtr + pOffset[i];
				tmp = (distanceT) (curProjValue - *sourcePtr);
				tmp = tmp*tmp;
				matchesDistPtr[i] += tmp;
				if (matchesDistPtr[i] < thresholdDistT)
				{
					matchesDistPtr[suspectedCount] = matchesDistPtr[i];
					pOffset[suspectedCount++] = pOffset[i];
				} 
			}
		}
#if SHOW_MY_STATS	
		printf("suspectedTotal: %d for %d projections, Ratios: %f\n", suspectedCount, curBaseNum, (float)suspectedCount/suspectedTotal);
#endif
		suspectedTotal = suspectedCount;
		FlagBreak = FlagBreak ||(suspectedTotal < Count2);
		//To see if we should jump to directly computing the Euclidean distance
		if (FlagBreak) 
			break;
		// compute projection values when more are needed
		if ( (BasesComputed - curBaseNum ==  1) && (BasesComputed<setup->Bases_Num) )
		{
			if (curBaseNum == 0)
				BasesComputed = 0;
			BasesComputed += setIncImageKHT(setup, BasesComputed, BasesComputed+4, W);
//			+=4;
		}		
	}//for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++)
	suspectedCount = 0;
	sourcePtrUint8 = imPixels(setup->curImage) + matCols(setup->curImage) * setup->Boundary_Size_Pat + setup->Boundary_Size_Pat;
	sourceDif = imCols(setup->curImage) - BLOCK_SIZE_IMG;
	prevImageProj = setup->prevImageProj[0];
	destDif = imCols(setup->prevImage) - BLOCK_SIZE_IMG;
	i = 0;
	threshold = (int) (thresholdDistT/(setup->Block_size_pat*setup->Block_size_pat));
	setup->OPs += 3*(double)suspectedTotal * BLOCK_SIZE_IMG*BLOCK_SIZE_IMG;// actual distance
	while (i<suspectedTotal)
	{
		int xpos, ypos;
		int offsetNow = matchesOffset[i];// + initNumOfCols;
		i++;
		ypos = offsetNow / matCols(prevImageProj);
		xpos = offsetNow - matCols(prevImageProj) * ypos;
//		xpos = offsetNow % matCols(setup->prevImageProj[0]);
		ssd = calcSSD(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
		if (ssd < threshold)
		{
			setup->match[suspectedCount] = ssd;
			setup->xmatch[suspectedCount] = ypos;
			setup->ymatch[suspectedCount] = xpos;
			suspectedCount++;
		}
	}
	setup->count = suspectedCount;
	setup->BasesComputed = BasesComputed;
}

void motionEstimationKHTSP(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases) {

	u_int16 maxValidX = setup->Img_Width_With_Boundary - BLOCK_SIZE_IMG;	// max valid coordinates for the
	u_int16 maxValidY = setup->Img_Height_With_Boundary - BLOCK_SIZE_IMG;	// upper left corner of candidate blocks

	u_int8 curBaseNum;
	int32 *sourcePtr, *initsourcePtr;
	u_int32 *destPtr , *initDestPtr, *matchesDistPtr;
	u_int16 sourceDif;
	u_int16 destDif, initDestDif;
	u_int16 cols;
	u_int16 numOfRows, initNumOfRows;
	u_int16 initNumOfCols;
	int32 startBase;
	u_int8 *sourcePtrUint8;
	int32 suspectedCount, suspectedTotal, Count2;

	Matrix_Dist *distMat = setup->distances;
	u_int32 distMatSize = matSize(distMat) * sizeof(u_int32);
	MatchQueue *bestMatches = setup->bestMatches;

	int32 i, bestSadIndex = 0;
	u_int32 ssd;
	u_int32 threshold = setup->Threshold*setup->Block_size_pat*setup->Block_size_pat;
		u_int32 thresholdDistT;

	const int32 PatIdx = 0;
	int32 BasesComputed;
	Matrix *prevImageProj;
	int32 W;
#ifdef MY_DEBUG
	int32 CompareReturn;
#endif
/*
	//for counting time
  int tmp_time;
  time_t ltime1;
  time_t ltime2;
#ifdef WIN32
  struct _timeb tstruct1;
  struct _timeb tstruct2;
#else
  struct timeb tstruct1;
  struct timeb tstruct2;
#endif
	//for counting time
*/
	// loop all current image blocks


	// calculate bound on distance for all candidate blocks in search range
	matchesDistPtr = matchesDist;
	if (WANT_DC) 
		startBase = 0;
	else
		startBase = 1;
	// switch between current and previous image
#if SHOW_MY_STATS	
		printf("Warning: collecting stats...\n");
#endif
	copyImageWithBoundary(pImage, setup->prevImage, BOUNDARY_SIZE_IMG);
	
	memset(computed, 0, setup->Bases_Num);		// zero distance matrix


	BasesComputed=1;

	SatSum(setup->prevImage->pixels, setup->Img_Width_With_Boundary, setup->Img_Height_With_Boundary, &matVal(setup->tmpProj,0,0));
	projDCBySAT(setup, setup->prevImageProj[0], setup->tmpProj, BLOCK_SIZE_IMG, BLOCK_SIZE_IMG,
		setup->ImgProj_Height, setup->ImgProj_Width);
	setup->ProjExtraH = 0;
//	projWHDC(setup, setup->prevImage, setup->prevImageProj[0], setup->colsProj);
//	KHTByCol(setup, setup->prevImageProj[0], 0, 0, 4, BLOCK_SIZE_IMG>>2);
	BasesComputed=1;

	initNumOfRows = setup->Img_Heihgt - BLOCK_SIZE_IMG + 1; 
	initNumOfCols = setup->Img_Width - BLOCK_SIZE_IMG + 1;
	initDestPtr = distMat->cellValues;
	initDestDif = matCols(distMat) - initNumOfCols;
	memset(distMat->cellValues, 0, distMatSize);	// make distance matrix zeros
	sourceDif = matCols(setup->prevImageProj[0]) - initNumOfCols;
	destDif = initDestDif;
	suspectedTotal = suspectedCount = W = initNumOfCols*initNumOfRows;
//	Count1 = suspectedCount * PERCENT1 / 100;
	setup->OPs = W*4;//BoxTech
	Count2 = (int) (suspectedCount * setup->Percent);

	//for each basis vector
	for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++) {
		u_int32 tmp;
		int32 curProjValue, *pOffset;
		int32 FlagBreak = 0;
		u_int32 *pDist; 
		suspectedCount = 0;
		prevImageProj = setup->prevImageProj[curBaseNum];
		curProjValue = PatternWHTCoef[PatIdx][curBaseNum];

		initsourcePtr = &matVal(prevImageProj,0,0) + matCols(prevImageProj) * BOUNDARY_SIZE_IMG + BOUNDARY_SIZE_IMG;
		sourcePtr = initsourcePtr;

		// At first time, try all of the canditate points
		pDist = matchesDistPtr;
		pOffset = matchesOffset;

		setup->OPs += suspectedTotal * 3;

		if (curBaseNum == startBase)
		{
			int itmp;
			destPtr = initDestPtr;
			numOfRows = initNumOfRows; 
			while (numOfRows--) {
				cols = initNumOfCols;
				while (cols--) {
					itmp = curProjValue - *sourcePtr;
					if ( (u_int32) abs(itmp) < threshold)
					{
						tmp = (u_int32) itmp;
						tmp = tmp*tmp;
						*destPtr += tmp;
						*pDist = *destPtr;
						*pOffset = sourcePtr - initsourcePtr;
//						matchesDistPtr[suspectedCount] = *destPtr;
//						matchesOffset[suspectedCount++] = sourcePtr - initsourcePtr;
						pDist++;
						pOffset++;
					}
					sourcePtr++;
					destPtr++;
				}						
				sourcePtr += sourceDif;
				destPtr += destDif;
			}
			suspectedCount = pDist - matchesDistPtr;
			thresholdDistT = (u_int32) threshold;
			thresholdDistT *= thresholdDistT;
		}
		else
		// Later on, try canditate points that are not rejected before
		{
			for (i = 0; i<suspectedTotal; i++)
			{
				sourcePtr = initsourcePtr + pOffset[i];
				tmp = (u_int32) (curProjValue - *sourcePtr);
				tmp = tmp*tmp;
				matchesDistPtr[i] += tmp;
				if (matchesDistPtr[i] < thresholdDistT)
				{
					matchesDistPtr[suspectedCount] = matchesDistPtr[i];
					pOffset[suspectedCount++] = pOffset[i];
				} 
			}
		}
#if SHOW_MY_STATS	
		printf("suspectedTotal: %d for %d projections, Ratios: %f\n", suspectedCount, curBaseNum, (float)suspectedCount/suspectedTotal);
#endif
		suspectedTotal = suspectedCount;
		FlagBreak = FlagBreak ||(suspectedTotal < Count2);
		//To see if we should jump to directly computing the Euclidean distance
		if (FlagBreak) 
			break;
		// compute projection values when more are needed
		if ( (BasesComputed - curBaseNum ==  1) && (BasesComputed<setup->Bases_Num) )
		{
			if (curBaseNum == 0)
				BasesComputed = 0;
			BasesComputed += setIncImageKHT(setup, BasesComputed, BasesComputed+4, W);
//			+=4;
		}		
	}//for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++)
	suspectedCount = 0;
	sourcePtrUint8 = imPixels(setup->curImage) + matCols(setup->curImage) * setup->Boundary_Size_Pat + setup->Boundary_Size_Pat;
	sourceDif = imCols(setup->curImage) - BLOCK_SIZE_IMG;
	prevImageProj = setup->prevImageProj[0];
	destDif = imCols(setup->prevImage) - BLOCK_SIZE_IMG;
	i = 0;
	threshold = (int) (thresholdDistT/(setup->Block_size_pat*setup->Block_size_pat));
	setup->OPs += 3*(double)suspectedTotal * BLOCK_SIZE_IMG*BLOCK_SIZE_IMG;// actual distance
	while (i<suspectedTotal)
	{
		int xpos, ypos;
		int offsetNow = matchesOffset[i];// + initNumOfCols;
		i++;
		ypos = offsetNow / matCols(prevImageProj);
		xpos = offsetNow - matCols(prevImageProj) * ypos;
//		xpos = offsetNow % matCols(setup->prevImageProj[0]);
		ssd = calcSSD(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
		if (ssd < threshold)
		{
			setup->match[suspectedCount] = ssd;
			setup->xmatch[suspectedCount] = ypos;
			setup->ymatch[suspectedCount] = xpos;
			suspectedCount++;
		}
	}
	setup->count = suspectedCount;
	setup->BasesComputed = BasesComputed;
}

void motionEstimationGCKSP(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases) {

//	u_int16 halfSearchRange = SEARCH_RANGE / 2;
//	int16 psrXPixel1, psrYPixel1;	// practical coordinates of search range for this block
//	int16 x,y;												// (only inside image boundaries)
	u_int16 maxValidX = setup->Img_Width_With_Boundary - BLOCK_SIZE_IMG;	// max valid coordinates for the
	u_int16 maxValidY = setup->Img_Height_With_Boundary - BLOCK_SIZE_IMG;	// upper left corner of candidate blocks

	int32 curBaseNum;
	int32 *sourcePtr, *initsourcePtr;
	u_int32 *destPtr , *initDestPtr, *matchesDistPtr;
	u_int16 sourceDif;
	u_int16 destDif, initDestDif;
	u_int16 cols;
	u_int16 numOfRows, initNumOfRows;
	u_int16 initNumOfCols;
	int32 startBase;
	u_int32 thresholdDistT;
	u_int8 *sourcePtrUint8;
	int32 suspectedCount, suspectedTotal, Count2;

	Matrix_Dist *distMat = setup->distances;
	u_int32 distMatSize = matSize(distMat) * sizeof(int32);
	MatchQueue *bestMatches = setup->bestMatches;

	int32 i, bestSadIndex = 0;
	u_int32 ssd;
	u_int32 threshold = setup->Threshold*setup->Block_size_pat*setup->Block_size_pat;
	int32 W;

	const int32 PatIdx = 0;
	int32 BasesComputed;
	Matrix *prevImageProj;
#ifdef MY_DEBUG
	int32 CompareReturn;
#endif
/*
	//for counting time
  int tmp_time;
  time_t ltime1;
  time_t ltime2;
#ifdef WIN32
  struct _timeb tstruct1;
  struct _timeb tstruct2;
#else
  struct timeb tstruct1;
  struct timeb tstruct2;
#endif
	//for counting time
*/
	// loop all current image blocks

	matchesDistPtr = (u_int32*) matchesDist;

	// calculate bound on distance for all candidate blocks in search range
	if (WANT_DC) 
		startBase = 0;
	else
		startBase = 1;
	// switch between current and previous image
	copyImageWithBoundary(pImage, setup->prevImage, BOUNDARY_SIZE_IMG);
	
	memset(computed, 0, setup->Bases_Num);		// zero distance matrix


	BasesComputed=1;

	ComputeOffset(setup->baseVectors);
/*		
#ifdef WIN32
		_ftime (&tstruct1);           // start time ms
#else
		ftime (&tstruct1);
#endif
		time (&ltime1);               // start time s

		setIncImagePureGCK(setup, 1, MaxBases);

		time (&ltime2);               // end time sec
#ifdef WIN32
		_ftime (&tstruct2);           // end time ms
#else
		ftime (&tstruct2);            // end time ms
#endif

		tmp_time = (ltime2 * 1000 + tstruct2.millitm) - (ltime1 * 1000 + tstruct1.millitm);  tot_time += tmp_time;
	BasesComputed=MaxBases;		
*/
#if SHOW_MY_STATS	
		printf("Warning: collecting stats...\n");
#endif
	projWHDC(setup, setup->prevImage, setup->prevImageProj[0], setup->colsProj);
	BasesComputed=1;

	initNumOfRows = setup->Img_Heihgt - BLOCK_SIZE_IMG + 1; 
	initNumOfCols = setup->Img_Width - BLOCK_SIZE_IMG + 1;
	initDestPtr = (u_int32*) distMat->cellValues;
	initDestDif = matCols(distMat) - initNumOfCols;
	memset(distMat->cellValues, 0, distMatSize);	// make distance matrix zeros
	sourceDif = matCols(setup->prevImageProj[0]) - initNumOfCols;
	destDif = initDestDif;
	suspectedTotal = suspectedCount = W = initNumOfCols*initNumOfRows;
	setup->OPs = W*4;//BoxTech
//	Count1 = suspectedCount * PERCENT1 / 100;
	Count2 = (int) (suspectedCount * setup->Percent);
	setup->ImgProj_Width = initNumOfCols + BOUNDARY_SIZE_IMG;
	setup->ImgProj_Height = initNumOfRows + BOUNDARY_SIZE_IMG;
	for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++) {
//		int ttt;
		u_int32 tmp;
		int32 curProjValue;
		int32 FlagBreak = 0;
		suspectedCount = 0;
//		curImageProj = setup->curImageProj[curBaseNum];
		prevImageProj = setup->prevImageProj[curBaseNum];
		curProjValue = PatternWHTCoef[PatIdx][curBaseNum];

//		numOfCols = initNumOfCols; 
		initsourcePtr = prevImageProj->cellValues + matCols(prevImageProj) * BOUNDARY_SIZE_IMG + BOUNDARY_SIZE_IMG;
		sourcePtr = initsourcePtr;

		setup->OPs += suspectedTotal * 3;

		if (curBaseNum == startBase)
		{
			int itmp;
			destPtr = initDestPtr;
			numOfRows = initNumOfRows; 
			while (numOfRows--) {
				cols = initNumOfCols;
				while (cols--) {
					itmp = curProjValue - *sourcePtr;
					tmp = abs(itmp);
					if ( tmp < threshold)
					{
						tmp = (int32) tmp >> setup->LogSize;
						tmp = tmp*tmp;
						*destPtr = tmp;
						matchesDistPtr[suspectedCount] = *destPtr;
						matchesOffset[suspectedCount++] = sourcePtr - initsourcePtr;
					}
					sourcePtr++;
					destPtr++;
				}						
				sourcePtr += sourceDif;
				destPtr += destDif;
			}
			thresholdDistT = (int32) threshold;
			thresholdDistT >>= setup->LogSize;
			thresholdDistT *= thresholdDistT;
		}
		else
		{
			for (i = 0; i<suspectedTotal; i++)
			{
				sourcePtr = initsourcePtr + matchesOffset[i];
				tmp = abs(curProjValue - *sourcePtr);
				if (tmp > threshold) continue;
				tmp >>= setup->LogSize;
				tmp = tmp*tmp;
				matchesDistPtr[i] += tmp;
				if (matchesDistPtr[i] < thresholdDistT)
				{
					matchesDistPtr[suspectedCount] = matchesDistPtr[i];
					matchesOffset[suspectedCount++] = matchesOffset[i];
				} 
			}
		}
#if SHOW_MY_STATS	
		printf("suspectedTotal: %d for %d projections, Ratios: %f\n", suspectedCount, curBaseNum, (float)suspectedCount/suspectedTotal);
#endif
		suspectedTotal = suspectedCount;
		FlagBreak = FlagBreak ||(suspectedTotal < Count2);
		if (FlagBreak) 
		{
			curBaseNum++;
			break;
		}
		// compute projection values when more are needed
		if ( (BasesComputed - curBaseNum ==  1) && (BasesComputed<setup->Bases_Num) )
		{
			setIncImagePureGCK(setup, BasesComputed, BasesComputed+1);
			BasesComputed++;
		}
		
	}//for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++)
//	threshold = threshold/BLOCK_SIZE2;
//	threshold = threshold/BLOCK_SIZE2;
//			threshold = (int) (thresholdDistT/(setup->Block_size_pat*setup->Block_size_pat));
	threshold *= setup->Threshold;
	suspectedCount = 0;
	sourcePtrUint8 = imPixels(setup->curImage) + matCols(setup->curImage) * setup->Boundary_Size_Pat + setup->Boundary_Size_Pat;
	sourceDif = imCols(setup->curImage) - BLOCK_SIZE_IMG;
	prevImageProj = setup->prevImageProj[0];
	destDif = imCols(setup->prevImage) - BLOCK_SIZE_IMG;
	i = 0;
	setup->CandRemained = suspectedTotal;
	setup->OPs += (curBaseNum-1)*2*W;// Projection computed
#if COUNT_SSDOPS
// 	setup->OPs = 3*suspectedTotal * BLOCK_SIZE_IMG*BLOCK_SIZE_IMG;
 	setup->OPs += 3*(double)suspectedTotal * BLOCK_SIZE_IMG*BLOCK_SIZE_IMG;
#endif
	while (i<suspectedTotal)
	{
		int xpos, ypos;
		int offsetNow = matchesOffset[i];// + initNumOfCols;
		i++;
		ypos = offsetNow / matCols(prevImageProj);
		xpos = offsetNow - matCols(prevImageProj) * ypos;
//		xpos = offsetNow % matCols(setup->prevImageProj[0]);
		ssd = calcSSD(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
		if (ssd < threshold)
		{
			setup->match[suspectedCount] = ssd;
			setup->xmatch[suspectedCount] = ypos;
			setup->ymatch[suspectedCount] = xpos;
			suspectedCount++;
		}
	}
	setup->count = suspectedCount;
	setup->BasesComputed = curBaseNum;

#ifdef MY_DEBUG
	projWHDCDbg(setup, setup->prevImage, setup->curImageProj2[0], setup->colsProj);
	setIncImagePureGCKDbg(setup, 1, BasesComputed);
	for (curBaseNum=0; curBaseNum < MaxBases; curBaseNum++) {
		CompareReturn = Compare(setup, setup->curImageProj2[curBaseNum], setup->prevImageProj[curBaseNum]);
		if (CompareReturn!=0) printf("error in computing base No.: %d!!\n", curBaseNum);
	}
#endif

}


void motionEstimationGCKNewSP(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases) {

	u_int16 maxValidX = setup->Img_Width_With_Boundary - BLOCK_SIZE_IMG;	// max valid coordinates for the
	u_int16 maxValidY = setup->Img_Height_With_Boundary - BLOCK_SIZE_IMG;	// upper left corner of candidate blocks

	u_int8 curBaseNum;
	int32 *sourcePtr, *initsourcePtr;
	u_int32 *destPtr , *initDestPtr, *matchesDistPtr;
	u_int16 sourceDif;
	u_int16 destDif, initDestDif;
	u_int16 cols;
	u_int16 numOfRows, initNumOfRows;
	u_int16 initNumOfCols;
	int32 startBase;
	u_int8 *sourcePtrUint8;
	int32 suspectedCount, suspectedTotal, Count2;

	Matrix_Dist *distMat = setup->distances;
	u_int32 distMatSize = matSize(distMat) * sizeof(int32);
	MatchQueue *bestMatches = setup->bestMatches;

	int32 i, bestSadIndex = 0;
	u_int32 ssd;
	u_int32 threshold = setup->Threshold*setup->Block_size_pat*setup->Block_size_pat;
		u_int32 thresholdDistT;

	const int32 PatIdx = 0;
	int32 BasesComputed;
	Matrix *prevImageProj;
#ifdef MY_DEBUG
	int32 CompareReturn;
#endif
/*
	//for counting time
  int tmp_time;
  time_t ltime1;
  time_t ltime2;
#ifdef WIN32
  struct _timeb tstruct1;
  struct _timeb tstruct2;
#else
  struct timeb tstruct1;
  struct timeb tstruct2;
#endif
	//for counting time
*/
	// loop all current image blocks


	matchesDistPtr = (u_int32*) matchesDist;
	// calculate bound on distance for all candidate blocks in search range
	if (WANT_DC) 
		startBase = 0;
	else
		startBase = 1;
	// switch between current and previous image
#if SHOW_MY_STATS	
		printf("Warning: collecting stats...\n");
#endif
	copyImageWithBoundary(pImage, setup->prevImage, BOUNDARY_SIZE_IMG);
	
	memset(computed, 0, setup->Bases_Num);		// zero distance matrix


	BasesComputed=1;


	CalcImageDiff2(setup, setup->prevImage, setup->diffImage);
	projDiffWHDC(setup, setup->diffImage, setup->prevImageProj[MAX_BASES], setup->colsProj, BLOCK_SIZE_IMG, BLOCK_SIZE_IMG>>2);
	setIncImageGCKOY(setup, 0, 3);
	BasesComputed=4;

	initNumOfRows = setup->Img_Heihgt - BLOCK_SIZE_IMG + 1; 
	initNumOfCols = setup->Img_Width - BLOCK_SIZE_IMG + 1;
	initDestPtr = (u_int32*) distMat->cellValues;
	initDestDif = matCols(distMat) - initNumOfCols;
	memset(distMat->cellValues, 0, distMatSize);	// make distance matrix zeros
	sourceDif = matCols(setup->prevImageProj[0]) - initNumOfCols;
	destDif = initDestDif;
	suspectedTotal = suspectedCount = initNumOfCols*initNumOfRows;
//	Count1 = suspectedCount * PERCENT1 / 100;
	Count2 = (int) (suspectedCount * setup->Percent);

	//for each basis vector
	for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++) {
		int32 tmp;
		int32 curProjValue;
		int32 FlagBreak = 0;
		suspectedCount = 0;
		prevImageProj = setup->prevImageProj[curBaseNum];
		curProjValue = PatternWHTCoef[PatIdx][curBaseNum];

		initsourcePtr = prevImageProj->cellValues + matCols(prevImageProj) * BOUNDARY_SIZE_IMG + BOUNDARY_SIZE_IMG;
		sourcePtr = initsourcePtr;

		// At first time, try all of the canditate points
		if (curBaseNum == startBase)
		{
			u_int32 itmp;
			destPtr = initDestPtr;
			numOfRows = initNumOfRows; 
			while (numOfRows--) {
				cols = initNumOfCols;
				while (cols--) {
					itmp = abs(curProjValue - *sourcePtr);
					if (  itmp < threshold)
					{
						tmp = (int32) itmp >> setup->LogSize;
						tmp = tmp*tmp;
						*destPtr += tmp;
						matchesDistPtr[suspectedCount] = *destPtr ;
						matchesOffset[suspectedCount++] = sourcePtr - initsourcePtr;
					}
					sourcePtr++;
					destPtr++;
				}						
				sourcePtr += sourceDif;
				destPtr += destDif;
			}
			thresholdDistT = (int32) threshold;
			thresholdDistT >>= setup->LogSize; //thresholdDistT /= (setup->Block_size_pat*setup->Block_size_pat);
			thresholdDistT *= thresholdDistT;
		}
		else
		// Later on, try canditate points that are not rejected before
		{
			for (i = 0; i<suspectedTotal; i++)
			{
				sourcePtr = initsourcePtr + matchesOffset[i];
				tmp = abs (curProjValue - *sourcePtr);
//				if (tmp > threshold) continue;
				tmp >>= setup->LogSize; //tmp /= (setup->Block_size_pat*setup->Block_size_pat);
				tmp = tmp*tmp;
				matchesDistPtr[i] += tmp;
				if (matchesDistPtr[i] < thresholdDistT)
				{
					matchesDistPtr[suspectedCount] = matchesDistPtr[i];
					matchesOffset[suspectedCount++] = matchesOffset[i];
				} 
			}
		}
#if SHOW_MY_STATS	
		printf("suspectedTotal: %d for %d projections, Ratios: %f\n", suspectedCount, curBaseNum, (float)suspectedCount/suspectedTotal);
#endif
		suspectedTotal = suspectedCount;
		FlagBreak = FlagBreak ||(suspectedTotal < Count2);
		//To see if we should jump to directly computing the Euclidean distance
		if (FlagBreak) 
			break;
		// compute projection values when more are needed
		if ( (BasesComputed - curBaseNum ==  1) && (BasesComputed<setup->Bases_Num) )
		{
			setIncImageGCKOY(setup, BasesComputed, BasesComputed+4);
			BasesComputed+=4;
		}		
	}//for (curBaseNum = startBase; curBaseNum < setup->Bases_Num; curBaseNum++)
	suspectedCount = 0;
	sourcePtrUint8 = imPixels(setup->curImage) + matCols(setup->curImage) * setup->Boundary_Size_Pat + setup->Boundary_Size_Pat;
	sourceDif = imCols(setup->curImage) - BLOCK_SIZE_IMG;
	prevImageProj = setup->prevImageProj[0];
	destDif = imCols(setup->prevImage) - BLOCK_SIZE_IMG;
	i = 0;
//	threshold = (int) (thresholdDistT/(setup->Block_size_pat*setup->Block_size_pat));
	threshold *= setup->Threshold;
	setup->CandRemained = suspectedTotal;
	while (i<suspectedTotal)
	{
		int xpos, ypos;
		int offsetNow = matchesOffset[i];// + initNumOfCols;
		i++;
		ypos = offsetNow / matCols(prevImageProj);
		xpos = offsetNow - matCols(prevImageProj) * ypos;
//		xpos = offsetNow % matCols(setup->prevImageProj[0]);
		ssd = calcSSD(sourcePtrUint8, sourceDif, &imVal(setup->prevImage, ypos+setup->Boundary_Size_Pat, xpos+setup->Boundary_Size_Pat), destDif, BLOCK_SIZE_IMG);
		if (ssd < threshold)
		{
			setup->match[suspectedCount] = ssd;
			setup->xmatch[suspectedCount] = ypos;
			setup->ymatch[suspectedCount] = xpos;
			suspectedCount++;
		}
	}
	setup->count = suspectedCount;
	setup->BasesComputed = curBaseNum;
#ifdef MY_DEBUG
	projWHDCDbg(setup, setup->prevImage, setup->curImageProj2[0], setup->colsProj);
	setIncImagePureGCKDbg(setup, 1, BasesComputed);
	for (curBaseNum=0; curBaseNum < MaxBases; curBaseNum++) {
		CompareReturn = Compare(setup, setup->curImageProj2[curBaseNum], setup->prevImageProj[curBaseNum]);
		if (CompareReturn!=0) printf("error in computing base No.: %d!!\n", curBaseNum);
	}
#endif

}
/*****************************************************************************
 * Inserts new match to the queue. If distance is larger than all distances  *
 * in the queue, do nothing. Otherwise, replace the largest distance match   *
 * with this match.                                                          *
 *****************************************************************************/
__inline void insertMatch(MatchQueue *matchQueue, u_int16 y, u_int16 x, u_int32 distance) {

	static u_int8 i;
	static MatchNode *match;
	static u_int32 dist;

	// if distance >= largest distance in the queue, do nothing
	if (distance >= matchQueue->largestDist)
		return;
	
	// replace the largest distance match with current match
	match = &(matchQueue->matches[matchQueue->largestIndex]);
	match->x = x;
	match->y = y;
	match->distance = matchQueue->largestDist = distance;
	
	// re-calculate the largest distance match
	for(i=0; i<MATCHES_FOR_SAD; i++) {
		dist = matchDistance(matchQueue, i);
		if (dist > matchQueue->largestDist) {
			matchQueue->largestDist = dist;
			matchQueue->largestIndex = i;
		}
	}
}

#pragma inline_recursion(off)
#pragma inline_depth()
