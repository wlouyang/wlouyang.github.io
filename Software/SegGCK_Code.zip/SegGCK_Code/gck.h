/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        gck.h                                                        *
 *                                                                           *
 * description: Functions for performing motion estimation using 2D Gray     *
 *              Code Kernels and the Walsh-Hadamard transform.               *
 *****************************************************************************/

#ifndef _gck_h_
#define _gck_h_

#include "matrix.h"
#include "match.h"

u_int8 computed[1024];


///////////////////////////////// DATA TYPES ////////////////////////////////
typedef signed _int32 basisT;
// A setup for motion estimation. Contains motion estimation required data.
// The resulting motion vectors are updated in the motionVecs field.
typedef struct {
	Matrix **prevImageProj;	  // array of previous image projections
	Image *curImage;		  // current image
	Diff_Image *diffImage;		  // difference image x(i1,i2) - x(i1-k, i2)
	Image *prevImage;		  // previous image
	Matrix *baseVectors;	  // rows of this matrix are the base vectors
	Matrix *baseVectorsOrder; // order of base vectors for performing projections (index in the baseVectors matrix)
	Matrix **curImageProj;	  // array of current image projections
	Matrix **curImageProj2;	  // array of current image projections
//	motionVec motionVecs[BLOCKS_IN_A_COL][BLOCKS_IN_A_ROW];  // resulting motion vectors

	// temporary fields
	Matrix *colsProj;			// used in DC calculation
	Matrix *tmpProj;			// used in DC calculation
	Matrix *tmpProjPat;			// used in DC calculation
	Matrix_Dist *distances;			// distances from candidates in search range
	MatchQueue *bestMatches;	// best matches so far
	int32 Idx[128][128]; //usef for storing order information for snake or IF, maximum is 128 now
	int32 tIdx[128][128]; //usef for storing order information for snake or IF, maximum is 128 now
	coordT Img_Heihgt; // number of rows in the source image
	coordT Img_Width; // number of cols in the source image
	coordT Block_size_img; // number of rows (and cols) in the pattern image
	coordT Block_size_pat; // number of rows (and cols) in the pattern image
	coordT Boundary_Size_Img;
	coordT Boundary_Size_Pat;
	coordT Img_Width_With_Boundary;
	coordT Img_Height_With_Boundary;
	coordT Pat_Width_With_Boundary;
	coordT Pat_Height_With_Boundary;
	coordT PatProj_Width;
	coordT PatProj_Height;
	coordT ImgProj_Width;
	coordT ImgProj_Height;
	int ProjExtraH;
	int Bases_Num;	// number of supported WH basis
	int BasesComputed;
	float CandRemained;
	int count;
	int match[MAX_MATCH];
	int xmatch[MAX_MATCH];
	int ymatch[MAX_MATCH];
	int Threshold;
	int LogSize;
	float Percent; //The percentage where GCK stops and the direct SSD is used
	float EnergyPercent[MAX_BASES]; //The percentage of energy where GCK stops and the direct SSD is used
	double OPs;
} GCKSetup;


/////////////////////// PROTOTYPES OF PUBLIC FUNCTIONS //////////////////////

GCKSetup *createGCKSetup();
void destroyGCKSetup(GCKSetup *setup);
void createWHBases(GCKSetup *setup);
void setImageGCK(GCKSetup *setup, int BaseStart, int BaseEnd, u_int8 *computed);
void setPatternGCK(GCKSetup *setup, Image **image);
void motionEstimationGCKSP(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases);
void motionEstimationGCKNewSP(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases);
void motionEstimationGCKLP(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases);
void motionEstimationGCKNewLP(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases);
u_int32 SqrDiff[2*MAX_DIFF+1];
void ComputeOffset(Matrix *basesVectors);




#endif