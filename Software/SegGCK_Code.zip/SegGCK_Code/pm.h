

//NUMBER OF POSSIBLE INSTANCES OF THE PATTERN
//#define MAX_MATCH 10000
//max number of parameter N
//#define MAX_BOUNDS 16
#include "defs.h"


//FULL-SEARCH algorithms
//Finds templates below a certain threshold
int SsdTh(information *info);
//Finds the SSD global minimum
int SsdBest(information *info);
//Counts the number of matches below a trheshold
int SsdCountNMatch(information *info);

//LRP algorithm
int SsdLrpBF(information *info);
int SsdLrpSAT(information *info);

//IDA algorithm
int Ida(information *info);

