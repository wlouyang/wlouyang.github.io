/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        match.h                                                      *
 *                                                                           *
 * description: Utility for handling a queue of best matches for a block.	 *
 *****************************************************************************/	


#ifndef _match_h_
#define _match_h_

#include "defs.h"


///////////////////////////////// DATA TYPES ////////////////////////////////

// A match between a block and a candidate block
typedef struct MatchNode_t {
	u_int16 x, y;			// the location of the match in the source image
	u_int32 distance;		// the Euclidean distance between the pattern and the match
} MatchNode;


// A queue of matches between a block and a MATCHES_FOR_SAD candidates blocks
typedef struct MatchQueue_t {
	MatchNode matches[MATCHES_FOR_SAD];		// an array of MatchNodes of size MATCHES_FOR_SAD
	u_int32 largestDist;					// largest distance in the queue
	u_int8 largestIndex;					// index of the matches with largest distance in the queue
} MatchQueue;


// motion vector
typedef struct motionVec_t {
  int16 x;
  int16 y;
} motionVec;


/////////////////////////////////// MACROS //////////////////////////////////

#define matchX(matchQueue, nodeNum)			(matchQueue->matches[nodeNum].x)
#define matchY(matchQueue, nodeNum)			(matchQueue->matches[nodeNum].y)
#define matchDistance(matchQueue, nodeNum)	(matchQueue->matches[nodeNum].distance)


/////////////////////// PROTOTYPES OF PUBLIC FUNCTIONS //////////////////////

MatchQueue *allocMatchQueue();
void initMatchQueue(MatchQueue *matchQueue);
void destroyMatchQueue (MatchQueue *matchQueue);

//This function was moved to gck.c in order to make it inline function, so it will be more efficient
//void insertMatch (MatchQueue *matchQueue, u_int16 y, u_int16 x, u_int16 distance);

#endif