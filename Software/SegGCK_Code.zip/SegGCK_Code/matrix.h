/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        matrix.h                                                     *
 *                                                                           *
 * description: Utility functions for handling 2-D matrices with 32-bit      *
 *              values. These functions are not general but specific to the  *  
 *              GCK project.                                                 *
 *****************************************************************************/

#ifndef _matrix_h_
#define _matrix_h_

#include "defs.h"
#include "image.h"

//////////////////////////////////// DATA TYPES ///////////////////////////////////////

typedef struct {
	int32 *cellValues;
	int32 **rowsPtr;
	u_int16 rows, cols;
	u_int32 size;
} Matrix;

typedef struct {
	u_int16 rows, cols;
	u_int32 size;
	distanceT *cellValues;
	distanceT **rowsPtr;
} Matrix_Dist;

/////////////////////////////////////// CONSTANTS ///////////////////////////////////

#define PLUS 1		// represents the plus sign
#define MINUS -1	// represents the minus sign

//////////////////////////////////////// MACROS //////////////////////////////////////

#define matCols(matrix)			(matrix->cols)
#define matRows(matrix)			(matrix->rows)
#define matSize(matrix)			(matrix->size)
#define matValues(matrix)		(matrix->cellValues)
#define matValD(matrix, i)		(matrix->cellValues[i])
#define matVal(matrix, y, x)	(matrix->rowsPtr[y][x])
#define matValPtr(mat)      (mat->cellValues)


/////////////////////// PROTOTYPES OF PUBLIC FUNCTIONS /////////////////////////////

Matrix_Dist *allocMatrix_Dist(coordT rows, coordT cols);
Matrix *allocMatrix(coordT rows, coordT cols);
void destroyMatrix(Matrix *mat);
void destroyMatrixDist(Matrix_Dist *mat);
void fillMatrix(Matrix *mat, int32 cellValue);
void divMatrixByConst(Matrix *mat, int32 constant);
void absMatrix(Matrix *mat);
void addConstToMatrix(Matrix *mat, int32 constant);
Matrix *sumRowsMatrix(Matrix *mat);
Matrix *conv2Matrix(Matrix *mat, Matrix *mask);
void copyMatrixSegment(Matrix *source, Matrix *dest,
					   u_int16 sourceStartRow, u_int16 destStartRow, u_int16 numOfRows,
					   u_int16 sourceStartCol, u_int16 destStartCol, u_int16 numOfCols, int32 sign);
Matrix* copyRowsByIndex (Matrix *src, Matrix* OI);

__inline distanceT findMatrixDistance(Matrix *mat, coordT startRow, coordT startCol, Matrix *win) {
	cellValueT *matPtr = matValPtr(mat) + startRow * matCols(mat) + startCol,
		   *winPtr = matValPtr(win);
	coordT rows = matRows(win), cols = matCols(win), col;
	coordT colsDif = matCols(mat) - cols;
	distanceT result = 0;
	while (rows--) {
		col = cols;
		while (col--) {
			distanceT dif = (distanceT) (*(matPtr++) - *(winPtr++));
			result += dif * dif;
		}

		matPtr += colsDif;
	}

	return result;
}

#endif