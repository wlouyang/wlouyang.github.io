/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        image.c                                                      *
 *                                                                           *
 * description: Utility functions for handling 8-bit graylevel images.       *
 *****************************************************************************/

#include <stdlib.h>
#include <memory.h>
#include "defs.h"
#include "image.h"


///////////////////////////////// FUNCTIONS /////////////////////////////////


/*****************************************************************************
 * Allocates and returns an uninitialized Image of the given size.           *
 *****************************************************************************/
Image *allocImage(coordT rows, coordT cols) {

	u_int8 *pixels;

	pixels = (u_int8 *)malloc(rows * cols * sizeof(u_int8));
	if (!pixels)
		exitWithError("ERROR in allocImage: can't allocate pixels array.");

	return(reallocImage(pixels, rows, cols));
}


/*****************************************************************************
 * Creates and returns an Image of the given size, with the given pixels     *
 * array (no pixels allocation is performed).                                *
 *****************************************************************************/
Image *reallocImage(u_int8 *pixels, coordT rows, coordT cols) {

	Image *image;
	u_int16 row;
	u_int8 *ptr = pixels;

	image = (Image *)malloc(sizeof(Image));
	if (!image)
		exitWithError("ERROR in reallocImage: can't allocate image.");

	imRows(image) = rows;
	imCols(image) = cols;
	imSize(image) = rows * cols;
	imPixels(image) = pixels;

	image->rowsPtr = (u_int8 **)malloc(rows * sizeof(ptr));
	if (!image->rowsPtr)
		exitWithError("ERROR in reallocImage: can't allocate pixels rows mapping.");

	for (row = 0; row < rows ; row++) {
		image->rowsPtr[row] = ptr;
		ptr += cols;
	}

	return(image);
}

void reallocImage2(Image * image, u_int8 *pixels, coordT rows, coordT cols) {

//	Image *image;
	u_int16 row;
	u_int8 *ptr = pixels;

//	image = (Image *)malloc(sizeof(Image));
	if (!image)
		exitWithError("ERROR in reallocImage2: image is NULL.");

	imRows(image) = rows;
	imCols(image) = cols;
	imSize(image) = rows * cols;
	imPixels(image) = pixels;

	for (row = 0; row < rows ; row++) {
		image->rowsPtr[row] = ptr;
		ptr += cols;
	}

//	return(image);
}


Diff_Image *reallocDiffImage(int16 *pixels, coordT rows, coordT cols) {

	Diff_Image *image;
	u_int16 row;
	int16 *ptr = pixels;

	image = (Diff_Image *)malloc(sizeof(Diff_Image));
	if (!image)
		exitWithError("ERROR in reallocImage: can't allocate image.");

	imRows(image) = rows;
	imCols(image) = cols;
	imSize(image) = rows * cols;
	imPixels(image) = pixels;

	image->rowsPtr = (int16 **)malloc(rows * sizeof(ptr));
	if (!image->rowsPtr)
		exitWithError("ERROR in reallocImage: can't allocate pixels rows mapping.");

	for (row = 0; row < rows ; row++) {
		image->rowsPtr[row] = ptr;
		ptr += cols;
	}

	return(image);
}

Image *createImage(pixelT *pixels, coordT rows, coordT cols)
{
	Image *image;
	u_int8 *ptr = pixels;

	image = (Image *)malloc(sizeof(Image));
	if (!image)
		exitWithError("ERROR in allocImage: can't allocate image.");

	image->rowsPtr = (u_int8 **)malloc(rows * sizeof(ptr));
	if (!image->rowsPtr)
		exitWithError("ERROR in createImage: can't allocate pixels rows mapping.");

	imRows(image) = rows;
	imCols(image) = cols;
	pixelsPtr(image) = pixels;
	return(image);
}

void destroyWHImage(Image *image) {
	free(pixelsPtr(image));
	free(image);
}

Diff_Image *allocDiffImage(coordT rows, coordT cols) {

	int16 *pixels;

	pixels = (int16 *)malloc(rows * cols * sizeof(int16));
	if (!pixels)
		exitWithError("ERROR in allocImage: can't allocate pixels array.");

	return(reallocDiffImage(pixels, rows, cols));
}

/*****************************************************************************
 * Destroys the given Image.                                                 *
 *****************************************************************************/
void destroyImage(Image *image) {
	free(image->pixels);
	free(image->rowsPtr);
	free(image);
}
void destroyDiffImage(Diff_Image *image) {
	free(image->pixels);
	free(image->rowsPtr);
	free(image);
}


/*****************************************************************************
 * Copies source pixels to dest pixels.                                      *
 *****************************************************************************/
void copyImage(Image *source, Image *dest) {

	u_int16 rows = source->rows;
	u_int16 cols = source->cols;

	memcpy(&imVal(dest,0,0), &imVal(source,0,0), rows*cols);
}


/*****************************************************************************
 * Copies source pixels to dest pixels, assuming that dest image size has    *
 * a boundary to the top and to the left  .                                  *
 *****************************************************************************/
void copyImageWithBoundary(Image *source, Image *dest, int boundSize) {

	u_int16 row;
	u_int16 rows = source->rows;
	u_int16 cols = source->cols;

	memset(dest->pixels, 0, boundSize*dest->cols);
	for (row=0; row<rows; row++) {
		memset(&imVal(dest,row+boundSize,0), 0, boundSize);
		memcpy(&imVal(dest,row+boundSize,boundSize), &imVal(source,row,0), cols);
	}
}
