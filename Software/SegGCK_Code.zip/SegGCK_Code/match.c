/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        match.c                                                      *
 *                                                                           *
 * description: Utility for handling a queue of best matches for a block.	 *
 *****************************************************************************/					     
 
#include <stdlib.h>
#include <limits.h>
#include "defs.h"
#include "match.h"


///////////////////////////////// FUNCTIONS /////////////////////////////////

/*****************************************************************************
 * Allocates a matches queue.		                                         *
 *****************************************************************************/
MatchQueue *allocMatchQueue() {

	MatchQueue *result = (MatchQueue *)malloc(sizeof(MatchQueue));
	if (!result)
		exitWithError("ERROR in allocMatchQueue: can't allocate setup.");

	result->largestDist = ULONG_MAX;
	result->largestIndex = 0;

	return result;
}


/*****************************************************************************
 * Initializes a matches queue by assigning infinity to all its distances    *
 *****************************************************************************/
void initMatchQueue(MatchQueue *matchQueue) {

	u_int8 i;

	matchQueue->largestDist = ULONG_MAX;
	matchQueue->largestIndex = 0;

	for (i=0; i < MATCHES_FOR_SAD; i++)
		matchDistance(matchQueue, i) = ULONG_MAX;
}


/*****************************************************************************
 * Inserts new match to the queue. If distance is larger than all distances  *
 * in the queue, do nothing. Otherwise, replace the largest distance match   *
 * with this match.                                                          *
 *****************************************************************************/
/*void insertMatch(MatchQueue *matchQueue, u_int16 y, u_int16 x, u_int16 distance) {

	This function was moved to gck.c in order to make it inline function, so it will be more efficient.
}*/


/*****************************************************************************
 * Destroys the given match queue.									         *
 *****************************************************************************/
void destroyMatchQueue(MatchQueue *matchQueue) {

	free(matchQueue);
}
