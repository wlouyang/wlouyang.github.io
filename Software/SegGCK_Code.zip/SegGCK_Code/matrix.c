/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        matrix.c                                                     *
 *                                                                           *
 * description: Utility functions for handling 2-D matrices with 32-bit      *
 *              values. These functions are not general but specific to the  *  
 *              GCK project.                                                 *
 *****************************************************************************/

#include <stdlib.h>
#include <limits.h>
#include <memory.h>
#include <stdio.h>
#include "defs.h"
#include "matrix.h"


///////////////////////////////// FUNCTIONS /////////////////////////////////

/*****************************************************************************
 * Allocates and returns an uninitialized Matrix of the given size.          *
 *****************************************************************************/
Matrix *allocMatrix(coordT rows, coordT cols)
{
	Matrix *mat;
	int32 *ptr;
	u_int16 row;

	mat = (Matrix *)malloc(sizeof(Matrix));
	if (!mat)
		exitWithError("ERROR in allocMatrix: can't allocate matrix.");

	mat->cellValues = ptr = (int32 *)malloc(rows * cols * sizeof(int32));
	if (!mat->cellValues)
		exitWithError("ERROR in allocMatrix: can't allocate cellValues array.");

	mat->rows = rows;
	mat->cols = cols;
	mat->size = rows * cols;
	mat->rowsPtr = (int32 **)malloc(rows * sizeof(ptr));
	if (!mat->rowsPtr)
		exitWithError("ERROR in allocMatrix: can't allocate cellValues rows mapping.");

	for (row = 0; row < rows ; row++) {
		mat->rowsPtr[row] = ptr;
		ptr += cols;
	}

	return(mat);
}

Matrix_Dist *allocMatrix_Dist(coordT rows, coordT cols)
{
	Matrix_Dist *mat;
	distanceT *ptr;
	u_int16 row;

	mat = (Matrix_Dist *)malloc(sizeof(Matrix_Dist));
	if (!mat)
		exitWithError("ERROR in allocMatrix: can't allocate matrix.");

	mat->cellValues = ptr = (distanceT *)malloc(rows * cols * sizeof(distanceT));
	if (!mat->cellValues)
		exitWithError("ERROR in allocMatrix: can't allocate cellValues array.");

	mat->rows = rows;
	mat->cols = cols;
	mat->size = rows * cols;
	mat->rowsPtr = (distanceT **)malloc(rows * sizeof(ptr));
	if (!mat->rowsPtr)
		exitWithError("ERROR in allocMatrix: can't allocate cellValues rows mapping.");

	for (row = 0; row < rows ; row++) {
		mat->rowsPtr[row] = ptr;
		ptr += cols;
	}

	return(mat);
}



/*****************************************************************************
 * Destroys the given matrix.                                                *
 *****************************************************************************/
void destroyMatrix(Matrix *mat) {
	free(mat->cellValues);
	free(mat->rowsPtr);
	free(mat);
}

void destroyMatrixDist(Matrix_Dist *mat) {
	free(mat->cellValues);
	free(mat->rowsPtr);
	free(mat);
}

/*****************************************************************************
 * Fills the given matrix with the given cellValue.                          *
 *****************************************************************************/
void fillMatrix(Matrix *mat, int32 cellValue) {
	int32 *ptr = mat->cellValues;
	u_int32 i = matSize(mat);

	while (i--) 
		*(ptr++) = cellValue;
}

Matrix * imageToMatrix(Image *image) {
	Matrix *mat = allocMatrix(imRows(image), imCols(image));
	pixelT *pixels = pixelsPtr(image);
	cellValueT *ptr = mat->cellValues;
	matrixSizeT i = matSize(mat);

	while (i--) 
 		*(ptr++) = *(pixels++);

	return mat;
}

/*****************************************************************************
 * Sums the rows of the given matrix and returns the result vector  	     *
 *****************************************************************************/
Matrix *sumRowsMatrix(Matrix *mat) {

	Matrix *result = allocMatrix(matRows(mat),1);
	int32 *ptr = mat->cellValues; 
	u_int16 i = matCols(mat);
	int32 sum;
	u_int16 j;

	for (j=0;j < matRows(mat);j++) {
		i = matCols(mat);
		sum = 0;
		while (i--) 
			sum += *(ptr++);
		matVal(result,j,0) = sum;
	}
	return result;
}


/*****************************************************************************
 * Divides each cell value of the given matrix by the given constant.        *
 *****************************************************************************/
void divMatrixByConst(Matrix *mat, int32 constant) {
	int32 *ptr = mat->cellValues; 
	u_int32 i = matSize(mat);

	while (i--) 
		*(ptr++) /= constant;
}



/*****************************************************************************
 * Updates each cell value of the given matrix with its abs value.           *
 *****************************************************************************/
void absMatrix(Matrix *mat) {
	int32 *ptr = mat->cellValues; 
	u_int32 i = matSize(mat);

	while (i--) { 
		*(ptr) = abs(*(ptr));
		ptr++;
	}
	return;
}


/*****************************************************************************
 * Adds the given constant to each cell value of the given matrix.           *
 *****************************************************************************/
void addConstToMatrix(Matrix *mat, int32 constant) {
	int32 *ptr = mat->cellValues; 
	u_int32 i = matSize(mat);

	while (i--) 
		*(ptr++) += constant;
}


/*****************************************************************************
 * Convolutes the given matrix with the given mask and returns the result in *
 * a new matrix.The procedure is the same as function conv2 in Matlab		 *
 *  The new matrix will be of the size:										 *
 * (rows(mat) + rows(mask) - 1, cols(mat) + cols(mask) - 1).                 *
 *****************************************************************************/
Matrix *conv2Matrix(Matrix *mat, Matrix *mask) {
	int32 maskRowsDif = matRows(mask) - 1;
	int32 maskColsDif = matCols(mask) - 1;
	int32 i,j,n,m;
	Matrix *dest = allocMatrix((u_int16)(matRows(mat) + maskRowsDif), (u_int16)(matCols(mat) + maskColsDif));	
	fillMatrix(dest,0);

	for (i=0;i<matRows(mask);i++)
		for (j=0;j<matCols(mask);j++)
			for (m=0;m<matRows(mat);m++)
				for (n=0;n<matCols(mat);n++)
					matVal(dest,(i+m),(j+n)) += matVal(mask,i,j)*matVal(mat,m,n);

	return dest;	
}


/*****************************************************************************
 * Copies a window in the source matrix into a window in the dest matrix.    *
 *****************************************************************************/
void copyMatrixSegment(Matrix *source, Matrix *dest,
					   u_int16 sourceStartRow, u_int16 destStartRow, u_int16 numOfRows,
					   u_int16 sourceStartCol, u_int16 destStartCol, u_int16 numOfCols, int32 sign) {

	int32 *sourcePtr = source->cellValues + matCols(source) * sourceStartRow + sourceStartCol;
	int32 *destPtr = dest->cellValues + matCols(dest) * destStartRow + destStartCol;
	u_int16 sourceDif = matCols(source) - numOfCols;
	u_int16 destDif = matCols(dest) - numOfCols;
	u_int16 cols;

	while (numOfRows--) {
		cols = numOfCols;
		while (cols--)
			*(destPtr++) = sign * (*(sourcePtr++));

		sourcePtr += sourceDif;
		destPtr += destDif;
	}
}


/*****************************************************************************
 * Copies rows of the source matrix into the dest matrix due to IndexOrder   *
 * vector                                                                    *
 *****************************************************************************/
Matrix* copyRowsByIndex (Matrix *src, Matrix* OI)
{ 	
	Matrix *result = allocMatrix(matRows(src), matCols(src));
	u_int16 i;

	for (i=0; i<matRows(src); i++)
		copyMatrixSegment(src,result, i, (u_int16)matVal(OI,i,0), 1, 0, 0, (u_int16)matCols(src), PLUS);
	
	return result;
}
