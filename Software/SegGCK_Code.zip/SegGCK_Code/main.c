/*****************************************************************************
 *           Real Time Motion Estimation Using Gray Code Kernels             *
 *****************************************************************************
 * file:        main.c                                                       *
 *                                                                           *
 * description: main function												 *
 *																			 *
 * version:																	 *
 *	  1.0 - 14/2/06															 *
 *			Fully working and efficient                                      *
 *    1.1 - 14/2/06															 *
 *          Added efficient boundary calculation                             *
 *    1.2 - 9/5/06															 *
 *			Added Full-Search and Diamond-Search as a reference              *
 *    1.3 - 19/5/06															 *
 *			Added increasing frequency order as the default projection order *
 *    1.31 - 16/2/07														 *
 *			Fixed a bug related to the boundary calculation                  *
 *    1.4 - 1/6/07															 *
 *			Added logging of output motion vectors to a file                 *
 *			Fixed a bug where motion vectors were saved in inverted          *
 *          direction                                                        *
 *																			 *
 *****************************************************************************/

// For this program to run quickly, the following compiler options should be set
// (Visual Studio .NET 2005):
//	 Debug Information Format: Disabled
//	 Optimization: Maximum Speed (/O2)
//	 Inline Function Exstension: Any Suitable (/Ob2)

#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <stdio.h>
#include <io.h>
#include "defs.h"
#include "fs.h"
#include "gck.h"
#include "wh.h"

#include <time.h>
#include <sys/types.h>
#include <sys/timeb.h>


/******************************************************************************
 * Read one video frame from a YUV file.                                      *
 ******************************************************************************/
int readYUV(u_int8 *luma, u_int8 *chroma, u_int32 frameSize, FILE *fp) {
	
	if (fread(luma, sizeof(u_int8), frameSize, fp) != frameSize)
		return -1;

	if (fread(chroma, sizeof(u_int8), frameSize/2, fp) != (u_int16)(frameSize/2))
		return -1;

	return 0;
}

__inline int readImg3(u_int8 *luma, u_int32 frameSize, FILE *fp) {
	if (fread(luma, sizeof(u_int8), frameSize, fp) != frameSize)
		return -1;
	return 0;
}

/******************************************************************************
 * Main function - execution starts here.                                     *
 ******************************************************************************/
void ConstructSqrTable()
{ 
	int i;
	u_int16 tmp;
	for (i = 0; i<2*MAX_DIFF+1; i++)
	{
		tmp = absDiff[i];
		SqrDiff[i] = tmp * tmp;
	}
}

extern int32 BasesInOneCol[128];
extern int32 BasesInOneRow[128];

int SsdCountNMatch(information *info){

unsigned char *Image=info->Image;
unsigned char *Template=info->Template;
int ImageWidth=info->ImageWidth;
int ImageHeight=info->ImageHeight;
int TemplateWidth=info->TemplateWidth;
int TemplateHeight=info->TemplateHeight;

 int i,j;
 int x,y;

 int SSD=0;
 int temp;
 int count = 0;
  int SSD_MIN = info->SsdThreshold; 

 for (y=0;y<(ImageHeight-TemplateHeight);y++){
	 for (x=0;x<(ImageWidth-TemplateWidth);x++){

		 SSD=0;
		 
		 for (i=0;i<TemplateHeight;i++){
			 for (j=0;j<TemplateWidth;j++){
				 temp = Image[(y+i)*ImageWidth+(x+j)] - Template[i*TemplateWidth+j];
				 SSD = SSD + (temp*temp);
			 }
		 }
		 
		 if (SSD<SSD_MIN ) {
			 count++;
		 }
	 }
 }
 
 info->count = count; 
 return 0;
}

int BasesMtx[5][7]=
{{0, 0, 0,  0, 0, 0, 0},
{ 16, 16, 16, 16, 32,  0, 0}, //Bases for S1
{ 16, 32, 32, 48, 48,  0, 0}, //Bases for S2
{ 16, 32, 32, 48, 64,  0, 0}, //Bases for S3
{ 32, 96,128,128,128,128, 0}  //Bases for S4
};
/*
int BasesMtx[5][7]=
{{0, 0, 0,  0, 0, 0, 0},
{ 16, 32, 64, 96, 96,0, 0}, //Bases for S1
{ 16, 48,64,96, 96,0, 0}, //Bases for S2
{ 32, 64,96,96, 96,0, 0}, //Bases for S3
{ 32,64,96,96, 96,0, 0}  //Bases for S4
};*/





/*
int BasesMtx[5][7]=
{{0, 0, 0,  0, 0, 0, 0},
{ 8, 8, 8, 24, 48,0, 0}, //Bases for S1
{ 5, 32,32,48, 64,0, 0}, //Bases for S2
{ 8, 48,48,64, 96,0, 0}, //Bases for S3
{ 16,64,96,96, 96,0, 0}  //Bases for S4
};*/
/*int BasesMtx[5][7]=
{{0, 0, 0,  0, 0, 0, 0},
{ 8, 8, 8, 16, 32,0, 0}, //Bases for S1
{ 5, 32,32,32, 32,0, 0}, //Bases for S2
{ 8, 48,48,48, 48,0, 0}, //Bases for S3
{ 16,48,48,48, 48,0, 0}  //Bases for S4
};*/
float PercentMtx[4] = {(float)0.02, (float)0.02, (float)0.002, (float)0.0005};

extern int  tot_time;
information info; 
information info1;
// 30 images, 10 templates, 7 noise levels, 6 algorithms
int SSD_Threshold[7][30][10];
coordT Coordinates[30][10][2];
void Obtain_Coordinates(int ImgSizeIdx);
int SizeNum[5] = {0, 1, 2, 3, 4};
#define MAX_IMG_HEIGHT 960
#define MAX_IMG_WIDTH 1280
double OPs[10];
int main(void) {

	u_int8 *frameLuma = (u_int8 *)malloc(MAX_IMG_HEIGHT * MAX_IMG_WIDTH * sizeof (u_int8));
//	u_int8 *frameChroma = (u_int8 *)malloc(MAX_IMG_HEIGHT * MAX_IMG_WIDTH/2 * sizeof(u_int8)); // temporarily hold chrominance values
	u_int8 **PatLuma;
	u_int8 **PatChroma; // temporarily hold chrominance values
	char *COORD_FILE_NAME;
	Image **pPattern;
	Image *pImage;
	Image *source, *pattern;
	int loop;
//	FSSetup  *fsSetup = NULL;
	GCKSetup *gckSetup = NULL;
	GCKSetup *gckWSetup = NULL;
	GCKSetup *gckHSetup = NULL;
	WHSetup *whSetup = NULL;
	char Pat_filename[80];
	char Img_filename[80];
	char Cod_filename[80];
	char *(AlgoDescriptor[10]);
	int curBaseNum;
	int ImageNumIdx, PatNumIdx;
	int NoiseIdx, ImgSizeIdx, TemplateSizeIdx;
	int AlgChoice;

	#ifndef PROFILING_MODE

		int ch;
		double seconds;
	
	#endif
//		int i, j;

	#ifdef LOGGING_MODE

		char log_filename[80];
		FILE *log_file;
		char width[5];
		char height[5];
		char frames[5];
		char q[3];
		char m[3];
		motionVec mv;
		
	#endif


	// initializations
	FILE *video_file;
	FILE *pattern_file;

#ifdef WIN32
  struct _timeb tstruct1;
  struct _timeb tstruct2;
#else
  struct timeb tstruct1;
  struct timeb tstruct2;
#endif
  int  tot_time2=0;
  float totTime[10];
  float totPercent[10];
  float totTimeSqr[10];
  float TotalBases[10];
  float TotalCands[10];
  int tmp_time;
  time_t ltime1;
  time_t ltime2;

  FILE *stream;

  AlgoDescriptor[0] = "Exhaust";
  AlgoDescriptor[1] = "LRP_SAT";
  AlgoDescriptor[2] = "LRP_BOX";
  AlgoDescriptor[3] = "IDA_FED";
  AlgoDescriptor[4] = "PK__HEL";
  AlgoDescriptor[5] = "GCK_HEL";
  AlgoDescriptor[6] = "SEG_KHT";
	
  stream = freopen(LOG_FILE_NAME, "w", stderr );

	for (AlgChoice = 0; AlgChoice<10; AlgChoice++)
	{
		totTime[AlgChoice] = 0;
		totTimeSqr[AlgChoice] = 0;
		totPercent[AlgChoice] = 0;
		TotalBases[AlgChoice] = 0;
		TotalCands[AlgChoice] = 0;
		OPs[AlgChoice] = 0;
	}

// loop sequence images
	PatLuma = (u_int8 **)malloc(PAT_NUM * sizeof (u_int8*));
//	PatChroma =  (u_int8 **)malloc(PAT_NUM * sizeof (u_int8*));
	pPattern = (Image**) malloc(PAT_NUM * sizeof (Image *));
	ConstructSqrTable();
	PatLuma[0]   = (u_int8 *)malloc(MAX_IMG_HEIGHT * MAX_IMG_WIDTH * sizeof (u_int8));
//	PatChroma[0] = (u_int8 *)malloc(MAX_IMG_HEIGHT * MAX_IMG_WIDTH/2 * sizeof(u_int8));

	pImage = createImage(frameLuma, MAX_IMG_HEIGHT, MAX_IMG_WIDTH);
	pPattern[0] = createImage(PatLuma[0], MAX_IMG_HEIGHT, MAX_IMG_WIDTH);

	loop = 1;
	for (ImgSizeIdx = SIZE_START; ImgSizeIdx < SIZE_START+SIZE_NUM; ImgSizeIdx++)
#ifdef ALL_TEMPLATE_SIZES
#if (SIZE_START==4)
		for (TemplateSizeIdx = 1; TemplateSizeIdx < SizeNum[ImgSizeIdx]; TemplateSizeIdx++)
#else
		for (TemplateSizeIdx = 0; TemplateSizeIdx < SizeNum[ImgSizeIdx]; TemplateSizeIdx++)
#endif
#endif
	{		
		int IMG_WIDTH, IMG_HEIGHT, PAT_WIDTH, PAT_HEIGHT, BLOCK_SIZE_PAT;
		char COORD_FILE_NAME2[100];
		char PAT_FILE_NAME2[100], IMG_FILE_NAME2[100];
		char *PAT_FILE_NAME, *IMG_FILE_NAME;
		int IDA_R, LRP_N, LARGE_PATTERN;
		float	PERCENT_GCK;
		void (*motionEstimationGCK)(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases);  
		void (*motionEstimationGCKNew)(GCKSetup *setup, int curImageNum, int curPatNum, Image *pImage, int MaxBases);  
#ifndef ALL_TEMPLATE_SIZES
		TemplateSizeIdx = ImgSizeIdx - 1;
#endif
		PAT_WIDTH  = 16<<TemplateSizeIdx;				// number of columns in the pattern image
		PAT_HEIGHT = 16<<TemplateSizeIdx;				// number of rows in the pattern image
		BLOCK_SIZE_PAT = 16<<TemplateSizeIdx;
		LRP_N = 4+TemplateSizeIdx;
		IMG_FILE_NAME  = "./Noise_Data2/%d/I%d_%d.bin";

		switch (ImgSizeIdx)
		{
		case S1:
			IMG_WIDTH  = 160;				// number of columns in the source image
			IMG_HEIGHT = 120;				// number of rows in the source image
			PAT_FILE_NAME  = "./Template/160/T_%d/t%d_%d.bin";
			COORD_FILE_NAME  = "./Template/160/T_%d/pattern-coordinates.txt";
			IDA_R = 4;
			LRP_N = 4;
//			PERCENT_GCK = 0.02;
			motionEstimationGCK = motionEstimationGCKSP;
			motionEstimationGCKNew = motionEstimationGCKNewSP;
			break;
		case S2:
			IMG_WIDTH = 320;	
			IMG_HEIGHT = 240;
			PAT_FILE_NAME = "/template/320/T_%d/t%d_%d.bin";
			COORD_FILE_NAME  = "/template/320/T_%d/pattern-coordinates.txt";
			IDA_R = 4;
			motionEstimationGCK = motionEstimationGCKSP;
			motionEstimationGCKNew = motionEstimationGCKNewSP;
			break;
		case S3:
			IMG_WIDTH = 640;
			IMG_HEIGHT = 480;
			PAT_FILE_NAME = "/template/640/T_%d/t%d_%d.bin";
			COORD_FILE_NAME  = "/template/640/T_%d/pattern-coordinates.txt";
			IDA_R = 8;
			LARGE_PATTERN = 1;
//			LRP_N = 6;
//			PERCENT_GCK = 0.002;
			motionEstimationGCK = motionEstimationGCKLP;
			motionEstimationGCKNew = motionEstimationGCKNewLP;
			break;
		case S4:
			IMG_WIDTH = 1280;
			IMG_HEIGHT = 960;
			PAT_FILE_NAME = "/template/1280/T_%d/t%d_%d.bin";
			COORD_FILE_NAME  = "/template/1280/T_%d/pattern-coordinates.txt";
			IDA_R = 8;
			LARGE_PATTERN = 1;
			motionEstimationGCK = motionEstimationGCKLP;
			motionEstimationGCKNew = motionEstimationGCKNewLP;
			break;
		default:
			printf("This size is not supported yet!!!\n");
		}
		sprintf( Cod_filename,    COORD_FILE_NAME, BLOCK_SIZE_PAT);
		Obtain_Coordinates(ImgSizeIdx, Cod_filename);

		PERCENT_GCK = 0.02;

		fprintf(stream,"Image Size %d Template Size: %d\n", 160<<(ImgSizeIdx-1), 16<<TemplateSizeIdx);
		printf("Image Size %d Template Size: %d\n", 160<<(ImgSizeIdx-1), 16<<TemplateSizeIdx);

		gckHSetup = createGCKSetup(CHOICE_HELOR_GCK, IMG_HEIGHT, IMG_WIDTH, BLOCK_SIZE_PAT, MAX_BASES);
		gckHSetup->Percent = 0.02;
//		gckHSetup->Percent = 0.0002;
		gckHSetup->LogSize = LRP_N*2;
		ComputeOffset(gckHSetup->baseVectors);

		gckWSetup = createKHTSetup8(CHOICE_WANLI_GCK, IMG_HEIGHT, IMG_WIDTH, BLOCK_SIZE_PAT, MAX_BASES);
		gckWSetup->Percent = 0.0002;
		gckWSetup->LogSize = LRP_N*2;
		ComputeOffset(gckWSetup->baseVectors);
		

		for (NoiseIdx = NOISE_START; NoiseIdx < NOISE_NUM+NOISE_START; NoiseIdx++)
		{
			int MMD = 10*(NoiseIdx+1);  // The MMD defined by Dr. Federico etc. Used for Noise
//			int MMD = 8*(NoiseIdx+1);  // The MMD defined by Dr. Federico etc. Used for compression
//			int MMD = 5*(NoiseIdx+5);  // The MMD defined by Dr. Federico etc. Used for compression
			int MATCHING_THRESHOLD=(BLOCK_SIZE_PAT*BLOCK_SIZE_PAT*MMD);  // Threshold for GCK and Wanli's paper
			int THRESHOLD=(BLOCK_SIZE_PAT*BLOCK_SIZE_PAT*MMD*MMD);
			int BASES_NUM = (BasesMtx[ImgSizeIdx][NoiseIdx]*sqrt( (double)(BLOCK_SIZE_PAT) * 10 / IMG_WIDTH ) );
//			int BASES_NUM = 50;
			printf("Noise %d:\n", NoiseIdx);
			printf("SSD: %d BASES_NUM: %d\n", THRESHOLD, BASES_NUM);

#if PRINT_IMAGE_NUN
				printf( "processing image:    ");
#endif
				for (ImageNumIdx = 0; ImageNumIdx < IMG_NUM; ImageNumIdx++) 
			{
#if PRINT_IMAGE_NUN
				printf( "\b\b\b %2d", ImageNumIdx);
#endif
			for (PatNumIdx = 0; PatNumIdx < PAT_NUM; PatNumIdx++) 
			{
				int SSD;
				double THRESHOLD_d, MMD_d;
				sprintf( Pat_filename,    PAT_FILE_NAME, BLOCK_SIZE_PAT, ImageNumIdx+1, PatNumIdx );
				reallocImage2(pPattern[0], PatLuma[0], PAT_HEIGHT, PAT_WIDTH);
				if ((pattern_file = fopen(Pat_filename, "rb")) == NULL)	
					exitWithError("Error while opening YUV file: %s .\n", Pat_filename);
				if (readImg3(PatLuma[0], PAT_HEIGHT * PAT_WIDTH, pattern_file))
					exitWithError("Error while reading from YUV file: %s.\n", Pat_filename);

				// read frame
				sprintf( Img_filename,  IMG_FILE_NAME, IMG_WIDTH, ImageNumIdx+1, NoiseIdx);
				if ((video_file = fopen(Img_filename, "rb")) == NULL)
					exitWithError("Error while opening YUV file1.\n");
				fseek( video_file, 0L, SEEK_SET );
				if (readImg3(frameLuma, IMG_HEIGHT * IMG_WIDTH, video_file))
					exitWithError("Error while reading from YUV file.\n");
				reallocImage2(pImage, frameLuma, IMG_HEIGHT, IMG_WIDTH);

//				printf( "processing image %d Pat %d\n", ImageNumIdx, PatNumIdx);
//				printf( "processing image %s Pat %s\n", Img_filename, Pat_filename);

#ifdef ADAPTIVE_SSD
				SSD = Obtain_SSD(frameLuma, PatLuma[0], 
					Coordinates[ImageNumIdx][PatNumIdx][0], Coordinates[ImageNumIdx][PatNumIdx][1], 
					PAT_HEIGHT, PAT_WIDTH, IMG_WIDTH);
//				THRESHOLD_d = SSD*1.1;
				THRESHOLD_d = SSD*1.1 + BLOCK_SIZE_PAT*BLOCK_SIZE_PAT;
				MMD_d  = sqrt(THRESHOLD_d)/BLOCK_SIZE_PAT;
				MMD = ceil(MMD_d);
				if ( (MMD >63) )
				{
//					printf("\nOriginal MMD is: %d  %f\n", MMD, MMD_d);
					MMD = 63; // Control the SSD not to be too large to be meaningless
				}
/*				else if ( ( BLOCK_SIZE_PAT == 16) && (MMD >127) )
				{
					MMD = 127; // Control the SSD not to be too large to be meaningless
				}*/
				THRESHOLD=(BLOCK_SIZE_PAT*BLOCK_SIZE_PAT*MMD*MMD);
#endif
				
				for (AlgChoice = CHOICE_START; AlgChoice<CHOICE_NUM+CHOICE_START; AlgChoice++)
				{
					int i;
					//Read Pattern

//				printf( "processing image %d Pat %d choice %d\n", ImageNumIdx, PatNumIdx, AlgChoice);
					START_COUNT_TIME;
					switch (AlgChoice)
					{
					case CHOICE_EXHAUSTIV:
						info.Image = frameLuma;  //unsigned char array with the image pixels
						info.ImageWidth = IMG_WIDTH; //image width
						info.ImageHeight = IMG_HEIGHT; //image height
						info.Template = PatLuma[0]; //unsigned char array with the template pixels
						info.TemplateWidth = PAT_WIDTH;	//template width
						info.TemplateHeight = PAT_HEIGHT; //template height

						//SETTING THE SSD THRESHOLD
						info.SsdThreshold = THRESHOLD;
						FullSearchTh(&info);
						break;
					case CHOICE_HELOR_GCK:
						gckSetup = gckHSetup;
						gckSetup->Threshold = MMD;
						gckSetup->Bases_Num = 50;
//						gckSetup->Threshold = BLOCK_SIZE_PAT*BLOCK_SIZE_PAT*MMD;
						setPatternGCK(gckSetup, pPattern);
						curBaseNum = 50;
						motionEstimationGCKLP(gckSetup, ImageNumIdx, PatNumIdx, pImage, 50);
//						motionEstimationGCK(gckSetup, ImageNumIdx, PatNumIdx, pImage, 50);
						break;
/*					case CHOICE_WANLI_GCK: This is our approach in TPAMI: Fast algorithm for Walsh Hadamard transform on sliding windows
						gckSetup = gckWSetup;
						gckSetup->Bases_Num = BASES_NUM;
						gckSetup->Threshold = MMD;
						setPatternGCK(gckSetup, pPattern);
						motionEstimationGCKNew(gckSetup, ImageNumIdx, PatNumIdx, pImage, curBaseNum);
						break;*/
					case CHOICE_WANLI_GCK:
//					case CHOICE_WANLI_KHT:
						gckSetup = gckWSetup;
						gckSetup->Bases_Num = BASES_NUM;
						gckSetup->Threshold = MMD;
						setPatternKHT8(gckSetup, pPattern);
						motionEstimationKHT8(gckSetup, ImageNumIdx, PatNumIdx, pImage, curBaseNum);
						break;
					default:
						printf("This algroithm choice is not supported yet!\n");
					}
					END_COUNT_TIME;
					tot_time2 += tmp_time;
					totTime[AlgChoice] += tmp_time;
					totTimeSqr[AlgChoice] += ( ((float)tmp_time) * tmp_time);

// Compare the output to see if it is correct
					if (AlgChoice == CHOICE_START)
					{

						if ( (AlgChoice == CHOICE_HELOR_GCK) || (AlgChoice == CHOICE_WANLI_GCK) )
						{
							for (i = 0; i < gckSetup->count; i++)
							{
								info1.xmatch[ i ]  = gckSetup->xmatch[ i ];
								info1.ymatch[ i ]  = gckSetup->ymatch[ i ];
								info1.match[ i ]   = gckSetup->match[ i ];
							}
						info1.count = gckSetup->count;
						}
/*						else if (AlgChoice == CHOICE_PK_HELOR)
						{
							Match *match;
							match = matches(whSetup);
							for (i = 0; i < numOfMatches(whSetup); i++)
							{
								info1.xmatch[ i ]  = matchY(match);
								info1.ymatch[ i ]  = matchX(match);
								info1.match[ i ]   = matchDistance(match);
							}
							info1.count = numOfMatches(whSetup);
						}*/
						else
						{
							for (i = 0; i < info.count; i++)
							{
								info1.xmatch[ i ]  = info.xmatch[ i ];
								info1.ymatch[ i ]  = info.ymatch[ i ];
								info1.match[ i ]   = info.match[ i ];
							}
						info1.count = info.count;
						}
						if (info1.count == 0)
							printf("\n zero found for Image %d Pat %d\n", ImageNumIdx, PatNumIdx);
					}
					else
					{
						if ( (AlgChoice == CHOICE_HELOR_GCK) || (AlgChoice == CHOICE_WANLI_GCK) )
						{
							if (info1.count != gckSetup->count)
									printf("count different for choice %d\n", AlgChoice);

							for (i = 0; i < gckSetup->count; i++)
							{
								double DistDiff, DistDiffabs;
								if (info1.xmatch[ i ]  != gckSetup->xmatch[ i ])
									printf("xpos is different for choice %d\n", AlgChoice);
								if (info1.ymatch[ i ]  != gckSetup->ymatch[ i ])
									printf("ypos is different for choice %d\n", AlgChoice);
								DistDiff = (double)info1.match[ i ] - gckSetup->match[ i ];
								DistDiffabs = fabs(DistDiff);
								if ( DistDiff > 1)
									printf("Distance is different for choice %d\n", AlgChoice);
							}
						}
						else
						{
							if (info1.count != info.count)
									printf("count different for choice %d\n", AlgChoice);
							for (i = 0; i < info.count; i++)
							{
								if (info1.xmatch[ i ]  != info.xmatch[ i ])
									printf("xpos is different for choice %d\n", AlgChoice);
								if (info1.ymatch[ i ]  != info.ymatch[ i ])
									printf("ypos is different for choice %d\n", AlgChoice);
								if ( fabs(info1.match[ i ] - info.match[ i ]) > 1)
									printf("Distance is different for choice %d\n", AlgChoice);
							}
						}
/*						if (AlgChoice == CHOICE_PK_HELOR)
						{
							Match *match;
							int count;
							count = numOfMatches(whSetup);
							match = matches(whSetup);
							if (info1.count != count)
									printf("count different for choice %d\n", AlgChoice);
							for (i = 0; i < count; i++)
							{
								if (info1.xmatch[ i ]  != matchY(match))
									printf("xpos is different for choice %d\n", AlgChoice);
								if (info1.ymatch[ i ]  != matchX(match))
									printf("ypos is different for choice %d\n", AlgChoice);
//								if ( fabs(info1.match[ i ] - matchDistance(match)) > 1)
//									printf("Distance is different for choice %d\n", AlgChoice);
								match++;
							}
						}*/
					}
/*					if ( (AlgChoice == CHOICE_FEDER_IDA) )
					{
						OPs[AlgChoice] += info.Ops;
					}*/
					if ( (AlgChoice == CHOICE_HELOR_GCK) || (AlgChoice == CHOICE_WANLI_GCK) )
					{
						float MaxCands = (IMG_WIDTH-PAT_WIDTH+1)*(IMG_HEIGHT-PAT_HEIGHT+1);
						TotalBases[AlgChoice] += gckSetup->BasesComputed;
						TotalCands[AlgChoice] += (MaxCands - gckSetup->CandRemained)/MaxCands;
						totPercent[AlgChoice] += gckSetup->EnergyPercent[gckSetup->BasesComputed-1];
						if (AlgChoice == CHOICE_WANLI_GCK)
							totPercent[AlgChoice] = 0;
						OPs[AlgChoice] += gckSetup->OPs;
//						printf("totPercent: %f\n", totPercent[AlgChoice]);
					}

/*					if (whSetup != NULL) 
					{
						destroyWHSetup(whSetup);
						whSetup = NULL;
					}*/


					//Show stats
/*					if ( (AlgChoice == CHOICE_HELOR_GCK) || (AlgChoice == CHOICE_WANLI_GCK) )
					{
						fprintf(stream, "%d found using %d projections: \n", gckSetup->count, gckSetup->BasesComputed);
						if (gckSetup->count < 15)
						{
							int i;
							for (i = 0; i < gckSetup->count; i++)
								fprintf(stream, "Pos x: %d, y: %d  dist: %d\n", gckSetup->xmatch[ i ], gckSetup->ymatch[ i ], gckSetup->match[ i ]);
						}
					}
					else
					{
						fprintf(stream, "%d found\n", info.count);
						if (info.count < 15)
						{
							int i;
							for (i = 0; i < info.count; i++)
								fprintf(stream, "Pos x: %d, y: %d  dist: %d\n", info.xmatch[ i ], info.ymatch[ i ], info.match[ i ]);
						}
					}
*/
					
				} //for choices
				fclose(video_file);
				fclose(pattern_file);
			}
		} //for patterns and images
#if PRINT_IMAGE_NUN
			printf( "\n");
#endif
				fprintf(stream, "Noise Level: %d\n",NoiseIdx);
//			for (AlgChoice = CHOICE_START; AlgChoice<CHOICE_NUM+CHOICE_START; AlgChoice++)
//				fprintf(stream, "%d %s Time %.3f\tAvg.bases: %.3f in %d \tAvg.Counts %.5f\tPercent:%f\n",AlgChoice, AlgoDescriptor[AlgChoice], totTime[AlgChoice]*0.001,  (TotalBases[AlgChoice]) / (IMG_NUM*PAT_NUM), BASES_NUM, TotalCands[AlgChoice] / (IMG_NUM*PAT_NUM), totPercent[AlgChoice] / (IMG_NUM*PAT_NUM));
								
			for (AlgChoice = CHOICE_START; AlgChoice<CHOICE_NUM+CHOICE_START; AlgChoice++)
			{
#if SHOW_STD_VARIANCE
				float Mean, Var, SqrMean;
				fprintf(stream, "%d %s Time %.3f\tAvg.bases: %.3f in %d \tAvg.Counts %.5f\tPercent:%f\tOPs: %.3f ",AlgChoice, AlgoDescriptor[AlgChoice], totTime[AlgChoice]*0.001,  (TotalBases[AlgChoice]) / (IMG_NUM*PAT_NUM), BASES_NUM, TotalCands[AlgChoice] / (IMG_NUM*PAT_NUM), totPercent[AlgChoice] / (IMG_NUM*PAT_NUM), OPs[AlgChoice]/(IMG_NUM*PAT_NUM));
				printf("%d %s Time %.3f\tAvg.bases: %.3f in %d \tAvg.Counts %.5f\tPercent:%f\tOPs: %.3f",AlgChoice, AlgoDescriptor[AlgChoice], totTime[AlgChoice]*0.001,  (TotalBases[AlgChoice]) / (IMG_NUM*PAT_NUM), BASES_NUM, TotalCands[AlgChoice] / (IMG_NUM*PAT_NUM), totPercent[AlgChoice] / (IMG_NUM*PAT_NUM), OPs[AlgChoice]/(IMG_NUM*PAT_NUM));
				Mean = totTime[AlgChoice]*0.001/PAT_NUM/IMG_NUM;
				SqrMean = totTimeSqr[AlgChoice]*0.001*0.001/PAT_NUM/IMG_NUM;
				Var = SqrMean - Mean*Mean;
				fprintf(stream,"Std_Var: %.6f\n", sqrt(Var));
				printf("%.6f\n", sqrt(Var));
#else
				fprintf(stream, "%d %s Time %.3f\tAvg.bases: %.3f in %d \tAvg.Counts %.5f\tPercent:%f\tOPs: %.3f\n",AlgChoice, AlgoDescriptor[AlgChoice], totTime[AlgChoice]*0.001,  (TotalBases[AlgChoice]) / (IMG_NUM*PAT_NUM), BASES_NUM, TotalCands[AlgChoice] / (IMG_NUM*PAT_NUM), totPercent[AlgChoice] / (IMG_NUM*PAT_NUM), OPs[AlgChoice]/(IMG_NUM*PAT_NUM));
				printf("%d %s Time %.3f\tAvg.bases: %.3f in %d \tAvg.Counts %.5f\tPercent:%f\tOPs: %.3f\n",AlgChoice, AlgoDescriptor[AlgChoice], totTime[AlgChoice]*0.001,  (TotalBases[AlgChoice]) / (IMG_NUM*PAT_NUM), BASES_NUM, TotalCands[AlgChoice] / (IMG_NUM*PAT_NUM), totPercent[AlgChoice] / (IMG_NUM*PAT_NUM), OPs[AlgChoice]/(IMG_NUM*PAT_NUM));
#endif
			}
			for (AlgChoice = CHOICE_START; AlgChoice<CHOICE_NUM+CHOICE_START; AlgChoice++)
			{
				totTime[AlgChoice] = 0;
				totTimeSqr[AlgChoice] = 0;
				TotalBases[AlgChoice] = 0;
				TotalCands[AlgChoice] = 0;
				totPercent[AlgChoice] = 0;
				OPs[AlgChoice] = 0;
			}
			
		} //for noise levels
			if (gckHSetup != NULL) 
				destroyGCKSetup(gckHSetup);
			if (gckWSetup != NULL) 
				destroyKHTSetup(gckWSetup);

	}//for sizes

/*	for (AlgChoice = CHOICE_START; AlgChoice<CHOICE_NUM+CHOICE_START; AlgChoice++)
		fprintf(stream, "Choice: %d Time: %.3f \t Average bases: %.3f\n",AlgChoice, totTime[AlgChoice]*0.001,  (TotalBases[AlgChoice]/NOISE_NUM) / (IMG_NUM*PAT_NUM) );
*/		
	fprintf(stream," Total time: %.3f \t Average: %.2f \n",tot_time2*0.001/loop, tot_time2*0.001/loop/IMG_NUM);
	
	// clean up
	destroyImage(pPattern[0]);
	destroyImage(pImage);
//	free(PatChroma);
	free(PatLuma);
//	free(frameLuma);
//	free(frameChroma);


	#ifndef PROFILING_MODE
	
		seconds = (double)clock() / CLOCKS_PER_SEC;
		printf("\nElapsed Time: %5.2f seconds.\n", seconds);
		ch = getchar();
	
	#endif
}

void Obtain_Coordinates(int ImgSizeIdx, char *COORD_FILE_NAME)
{
	FILE *Coord_file;
	int ImageNumIdx, PatNumIdx;

	if ((Coord_file = fopen(COORD_FILE_NAME, "r")) == NULL)
		exitWithError("Error while opening coordinate file.\n");
	for (ImageNumIdx = 0; ImageNumIdx < 30; ImageNumIdx++) 
	{
		char s[50];
		fscanf( Coord_file, "%s\n", s );
		for (PatNumIdx = 0; PatNumIdx < 10; PatNumIdx++) 
		{
			int x, y;
			fscanf( Coord_file, "%d %d\n", &x, &y);
			Coordinates[ImageNumIdx][PatNumIdx][0] = x;
			Coordinates[ImageNumIdx][PatNumIdx][1] = y;
		}
	}
}

int Obtain_SSD(unsigned char *Image, unsigned char *Template, int x, int y, int TemplateHeight, int TemplateWidth, int ImageWidth)
{
	int temp, SSD;
	int i, j;
	SSD = 0;
	for (i=0;i<TemplateHeight;i++){
		for (j=0;j<TemplateWidth;j++){
			temp = Image[(y+i)*ImageWidth+(x+j)] - Template[i*TemplateWidth+j];
			SSD = SSD + (temp*temp);
		}
	}
	return SSD;
}

